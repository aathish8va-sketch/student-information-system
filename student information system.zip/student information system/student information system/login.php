<?php
session_start();
if (isset($_SESSION['user_id'])) {
    if ($_SESSION['role'] == 'admin') header("Location: /Chendhuran_SIS/admin/admin_dashboard.php");
    elseif ($_SESSION['role'] == 'teacher') header("Location: /Chendhuran_SIS/teacher/teacher_dashboard.php");
    else header("Location: /Chendhuran_SIS/student/student_dashboard.php");
    exit;
}
include 'includes/db_connect.php';
$error = '';

    // Generic Error Message for Security
    $error_msg = "Invalid Email or Password";

    // 1. Check Throttling
    if (!isset($_SESSION['login_attempts'])) $_SESSION['login_attempts'] = 0;
    
    if ($_SESSION['login_attempts'] >= 5) {
        if (!isset($_SESSION['lockout_time'])) $_SESSION['lockout_time'] = time() + (15 * 60);
        
        if (time() < $_SESSION['lockout_time']) {
            $remaining = ceil(($_SESSION['lockout_time'] - time()) / 60);
            $error = "Too many failed attempts. Please try again in $remaining minutes.";
        } else {
            $_SESSION['login_attempts'] = 0;
            unset($_SESSION['lockout_time']);
        }
    }

    // 2. Process Login
    if (!$error && $_SERVER["REQUEST_METHOD"] == "POST") {
        if (!verify_csrf_token($_POST['csrf_token'])) {
            die("CSRF Validation Failed");
        }

        $email = trim($_POST['email']);
        $password = $_POST['password'];
        
        $sql = "SELECT user_id, password_hash, role, profile_id, is_active FROM users WHERE email = ?";
        if ($stmt = $conn->prepare($sql)) {
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $stmt->store_result();
            if ($stmt->num_rows == 1) {
                $stmt->bind_result($user_id, $hashed_password, $role, $profile_id, $is_active);
                $stmt->fetch();
                
                // Check if account is active
                if (!$is_active) {
                    $_SESSION['login_attempts']++;
                    $error = "Your account has been debarred. Please contact administration.";
                    log_activity($user_id, 'LOGIN_FAIL', "Debarred user attempted login: $email");
                } elseif (password_verify($password, $hashed_password)) {
                    $_SESSION['user_id'] = $user_id;
                    $_SESSION['role'] = $role;
                    $_SESSION['profile_id'] = $profile_id;
                    $_SESSION['email'] = $email;

                    $name_q = "SELECT name FROM " . ($role == 'student' ? 'students' : ($role == 'teacher' ? 'teachers' : 'users')) . " WHERE " . ($role == 'student' ? 'student_id' : ($role == 'teacher' ? 'teacher_id' : 'user_id')) . " = $profile_id";
                    if ($role == 'admin') {
                        $_SESSION['user_name'] = 'Administrator';
                    } else {
                        $n_res = $conn->query($name_q);
                        if ($n_res && $n_res->num_rows > 0) {
                            $_SESSION['user_name'] = $n_res->fetch_row()[0];
                        } else {
                            $_SESSION['user_name'] = 'User';
                        }
                    }
                    
                    $_SESSION['login_attempts'] = 0;
                    unset($_SESSION['lockout_time']);

                    log_activity($user_id, 'LOGIN', "User logged in successfully.");

                    if ($role == 'admin') header("Location: /Chendhuran_SIS/admin/admin_dashboard.php");
                    elseif ($role == 'teacher') header("Location: /Chendhuran_SIS/teacher/teacher_dashboard.php");
                    else header("Location: /Chendhuran_SIS/student/student_dashboard.php");
                    exit;
                } else {
                    $_SESSION['login_attempts']++;
                    $error = $error_msg;
                    log_activity($user_id, 'LOGIN_FAIL', "Failed login attempt for $email");
                }
            } else {
                $_SESSION['login_attempts']++;
                $error = $error_msg;
            }
        }
    }
$csrf_token = generate_csrf_token();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Chendhuran Polytechnic SIS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .login-box {
            background: white;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
            width: 100%;
            max-width: 420px;
        }
        .login-header {
            text-align: center;
            margin-bottom: 30px;
        }
        .login-header h3 {
            font-weight: 700;
            color: #2d3748;
            margin-bottom: 5px;
        }
        .login-header p {
            color: #718096;
            font-size: 0.9rem;
        }
        .form-control {
            padding: 12px;
            border-radius: 8px;
            border: 2px solid #e2e8f0;
        }
        .form-control:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        .btn-login {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            padding: 12px;
            font-weight: 600;
            border-radius: 8px;
            color: white;
        }
        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.3);
        }
        .footer-info {
            text-align: center;
            margin-top: 25px;
            padding-top: 25px;
            border-top: 1px solid #e2e8f0;
            font-size: 0.85rem;
            color: #718096;
        }
    </style>
</head>
<body>
    <div class="login-box">
        <div class="login-header">
            <h3>Chendhuran Polytechnic College</h3>
            <p>Student Information System</p>
        </div>
        
        <?php if($error): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle me-2"></i><?php echo $error; ?>
            </div>
        <?php endif; ?>
        
        <form method="post">
            <div class="mb-3">
                <label class="form-label fw-semibold">Email</label>
                <input type="email" name="email" class="form-control" placeholder="your@email.com" required autofocus>
            </div>
            
            <div class="mb-4">
                <label class="form-label fw-semibold">Password</label>
                <input type="password" name="password" class="form-control" placeholder="Enter password" required>
            </div>
            
            <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
            
            <button type="submit" class="btn btn-login w-100">
                <i class="fas fa-sign-in-alt me-2"></i>Login
            </button>
        </form>
        
        <div class="footer-info">
            <strong>Chendhuran Polytechnic College</strong><br>
            Pudukkottai - 622 507<br>
            <i class="fas fa-phone"></i> 04333-295666 | <i class="fas fa-envelope"></i> cendhuran@rediffmail.com
        </div>
    </div>
</body>
</html>