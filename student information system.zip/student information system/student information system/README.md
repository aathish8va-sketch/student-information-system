# Chendhuran Polytechnic SIS

**Enterprise Student Information System (v1.0)**

> ⚠️ **IMPORTANT HOSTING NOTICE**
> This application relies on **PHP** and **MySQL**.
> It **CANNOT** be computed on GitHub Pages (which only handles static sites).
> You must deploy this to a PHP-compatible host (e.g., 000webhost, InfinityFree, Heroku).

## 🚀 Quick Start
1. **Download Code**: Clone this repo.
2. **Setup Server**: Use XAMPP (Local) or a Cloud Server with PHP/MySQL.
3. **Database**: 
   - Create a database named `chendhuran_sis`.
   - Import `chendhuran_sis.sql`.
4. **Run**: Access via browser.

## 🔐 Default Credentials
All accounts use password: `123456`

| Role | Email |
| :--- | :--- |
| **Administrator** | `admin@chendhuranpoly.ac.in` |
| **Faculty** | `teacher@chendhuranpoly.ac.in` |
| **Student** | `student@chendhuranpoly.ac.in` |

## 🛠️ Tech Stack
- **Frontend**: Bootstrap 5 (Professional Admin Theme)
- **Backend**: Native PHP 8.0+
- **Database**: MySQL / MariaDB
