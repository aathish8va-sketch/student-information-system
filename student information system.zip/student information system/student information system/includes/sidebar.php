<?php
// includes/sidebar.php - Unified Professional Sidebar
$current_page = basename($_SERVER['PHP_SELF']);
$role = $_SESSION['role'] ?? 'guest';
$role_label = ucfirst($role);

// Badge Counters
$badge_count = 0;
if(isset($conn)) {
    if($role == 'admin') {
        $res = $conn->query("SELECT COUNT(*) FROM grievances WHERE status='Pending'");
        if($res) $badge_count = $res->fetch_row()[0];
    } elseif($role == 'teacher') {
        // Teachers see pending grievances for their department? Or just general link.
        // Let's keep it simple for now or fetch dept specific if needed.
    }
}
?>
<nav id="sidebarMenu" class="admin-sidebar d-md-block collapse">
    <div class="position-sticky pt-4">
        <div class="px-4 mb-5">
            <h5 class="text-white fw-bold mb-0" style="letter-spacing: 1px;">CHENDHURAN</h5>
            <small class="text-white-50" style="font-size: 0.75rem;">POLYTECHNIC COLLEGE</small>
            <div class="mt-2 text-xs text-white-50 text-uppercase border-top border-secondary pt-2">
                <?php echo $role_label; ?> Portal
            </div>
        </div>
        
        <ul class="nav flex-column">
            <!-- ADMIN LINKS -->
            <?php if($role == 'admin'): ?>
                <li class="nav-item mb-1">
                    <a class="nav-link <?php echo ($current_page == 'admin_dashboard.php') ? 'active' : ''; ?>" href="/Chendhuran_SIS/admin/admin_dashboard.php">
                        <i class="fas fa-th-large me-2"></i> Dashboard
                    </a>
                </li>
                <li class="nav-item mb-1">
                    <a class="nav-link <?php echo ($current_page == 'admin_users.php') ? 'active' : ''; ?>" href="/Chendhuran_SIS/admin/admin_users.php">
                        <i class="fas fa-users me-2"></i> User Directory
                    </a>
                </li>
                <li class="nav-item mb-1">
                    <a class="nav-link <?php echo ($current_page == 'admin_placements.php') ? 'active' : ''; ?>" href="/Chendhuran_SIS/admin/admin_placements.php">
                        <i class="fas fa-user-tag me-2"></i> Placements & Roles
                    </a>
                </li>
                <li class="nav-item mb-1">
                    <a class="nav-link <?php echo ($current_page == 'admin_subjects.php') ? 'active' : ''; ?>" href="/Chendhuran_SIS/admin/admin_subjects.php">
                        <i class="fas fa-book me-2"></i> Manage Subjects
                    </a>
                </li>
                <li class="nav-item mb-1">
                    <a class="nav-link <?php echo ($current_page == 'academic_calendar.php') ? 'active' : ''; ?>" href="/Chendhuran_SIS/admin/academic_calendar.php">
                        <i class="fas fa-calendar-alt me-2"></i> Academic Calendar
                    </a>
                </li>


                <li class="nav-item mb-1">
                    <a class="nav-link <?php echo ($current_page == 'admin_reports.php') ? 'active' : ''; ?>" href="/Chendhuran_SIS/admin/admin_reports.php">
                        <i class="fas fa-chart-pie me-2"></i> Analytics
                    </a>
                </li>
                <li class="nav-item mb-1">
                    <a class="nav-link <?php echo ($current_page == 'admin_student_affairs.php') ? 'active' : ''; ?>" href="/Chendhuran_SIS/admin/admin_student_affairs.php">
                        <i class="fas fa-clipboard-list me-2"></i> Student Affairs
                    </a>
                </li>
                <li class="nav-item mb-1">
                    <a class="nav-link <?php echo ($current_page == 'profile.php') ? 'active' : ''; ?>" href="/Chendhuran_SIS/profile.php">
                        <i class="fas fa-user-circle me-2"></i> My Profile
                    </a>
                </li>
            
            <!-- TEACHER LINKS -->
            <?php elseif($role == 'teacher'): ?>
                <li class="nav-item mb-1">
                    <a class="nav-link <?php echo ($current_page == 'teacher_dashboard.php') ? 'active' : ''; ?>" href="/Chendhuran_SIS/teacher/teacher_dashboard.php">
                        <i class="fas fa-th-large me-2"></i> Dashboard
                    </a>
                </li>

                <!-- Academic Section -->
                <div class="mt-3 mb-2 px-3 text-xs text-uppercase text-white-50 fw-bold border-bottom border-secondary pb-1">
                    Academic
                </div>

                <li class="nav-item mb-1">
                    <a class="nav-link <?php echo ($current_page == 'mark_attendance.php') ? 'active' : ''; ?>" href="/Chendhuran_SIS/teacher/mark_attendance.php">
                        <i class="fas fa-calendar-check me-2"></i> Class Attendance
                    </a>
                </li>
                <li class="nav-item mb-1">
                    <a class="nav-link <?php echo ($current_page == 'submit_score.php') ? 'active' : ''; ?>" href="/Chendhuran_SIS/teacher/submit_score.php">
                        <i class="fas fa-edit me-2"></i> Mark Entry
                    </a>
                </li>

                <?php 
                // Fetch teacher role for conditional menu items
                if($role == 'teacher' && isset($conn)) {
                    $t_id = $_SESSION['profile_id'];
                    $t_role_query = $conn->query("SELECT teacher_role FROM teachers WHERE teacher_id = $t_id");
                    $t_role_data = $t_role_query ? $t_role_query->fetch_assoc() : null;
                    $teacher_role = $t_role_data['teacher_role'] ?? 'Teacher';
                    
                    // Show Combined Class Admin Page for Mentor/HOD/Principal
                    if($teacher_role == 'Class Mentor' || $teacher_role == 'HOD' || $teacher_role == 'Principal'):
                ?>
                <li class="nav-item mb-1">
                    <a class="nav-link <?php echo ($current_page == 'class_administration.php') ? 'active' : ''; ?>" href="/Chendhuran_SIS/teacher/class_administration.php">
                        <i class="fas fa-users-cog me-2"></i> Class Administration
                        <?php 
                        // Show pending count badge (Combined Leaves + Grievances)
                        if(isset($conn)) {
                            // LEAVES COUNT
                            $leave_count = 0;
                            // Mentor Pending
                            $leave_count_query = $conn->query("
                                SELECT COUNT(*) FROM leave_requests lr
                                JOIN students s ON lr.student_id = s.student_id
                                WHERE s.class_teacher_id = $t_id AND lr.status = 'Pending'
                            ");
                            $leave_count += $leave_count_query ? $leave_count_query->fetch_row()[0] : 0;
                            
                            // HOD/Principal Pending Logic (Simplified for badge)
                            if($teacher_role == 'HOD' || $teacher_role == 'Principal') {
                                $t_info = $conn->query("SELECT department FROM teachers WHERE teacher_id = $t_id")->fetch_assoc();
                                if($t_info) {
                                    $hod_count = $conn->query("SELECT COUNT(*) FROM leave_requests lr JOIN students s ON lr.student_id = s.student_id WHERE s.department = '{$t_info['department']}' AND lr.status = 'Approved by Mentor'")->fetch_row()[0];
                                    $leave_count += $hod_count;
                                }
                            }
                            if($teacher_role == 'Principal') {
                                $princ_count = $conn->query("SELECT COUNT(*) FROM leave_requests WHERE status = 'Approved by HOD'")->fetch_row()[0];
                                $leave_count += $princ_count;
                            }

                            // GRIEVANCES COUNT
                             // Get Teacher Name for assignment check
                            $my_name_q = $conn->query("SELECT name FROM users WHERE user_id = {$_SESSION['user_id']}");
                            $my_name = $_SESSION['user_name']; // Session usually has it

                            $conditions = ["assigned_to = '$my_name'"];
                            if ($teacher_role == 'HOD') {
                                $dept = $t_info['department'] ?? 'General';
                                $conditions[] = "(assigned_to = 'HOD' AND student_id IN (SELECT student_id FROM students WHERE department='$dept'))";
                            }
                            if ($teacher_role == 'Principal') {
                                $conditions[] = "assigned_to = 'Principal'";
                            }
                            $where_cond = implode(' OR ', $conditions);
                            
                            $g_res = $conn->query("SELECT COUNT(*) FROM grievances WHERE status='Pending' AND ($where_cond)");
                            $g_count = $g_res ? $g_res->fetch_row()[0] : 0;

                            $total_badge = $leave_count + $g_count;
                            
                            if($total_badge > 0):
                        ?>
                            <span class="badge bg-danger ms-2" style="font-size: 0.7rem;"><?php echo $total_badge; ?></span>
                        <?php 
                            endif;
                        }
                        ?>
                    </a>
                </li>
                <?php endif; } ?>

                <li class="nav-item mb-1">
                    <a class="nav-link <?php echo ($current_page == 'submit_behavior.php') ? 'active' : ''; ?>" href="/Chendhuran_SIS/teacher/submit_behavior.php">
                        <i class="fas fa-star me-2"></i> Student Feedback
                    </a>
                </li>
                
                <!-- Personal Section -->
                <div class="mt-3 mb-2 px-3 text-xs text-uppercase text-white-50 fw-bold border-bottom border-secondary pb-1">
                    Personal
                </div>

                <?php if($teacher_role != 'Principal' && $teacher_role != 'HOD'): ?>
                <li class="nav-item mb-1">
                    <a class="nav-link <?php echo ($current_page == 'leave_requests.php') ? 'active' : ''; ?>" href="/Chendhuran_SIS/teacher/leave_requests.php">
                        <i class="fas fa-calendar-alt me-2"></i> My Leaves
                    </a>
                </li>
                <?php endif; ?>
                <?php if($teacher_role != 'Principal' && $teacher_role != 'HOD'): ?>
                <li class="nav-item mb-1">
                    <a class="nav-link <?php echo ($current_page == 'grievances.php') ? 'active' : ''; ?>" href="/Chendhuran_SIS/teacher/grievances.php">
                        <i class="fas fa-bullhorn me-2"></i> Raise Grievance
                    </a>
                </li>
                <?php endif; ?>
                 <li class="nav-item mb-1">
                    <a class="nav-link <?php echo ($current_page == 'profile.php') ? 'active' : ''; ?>" href="/Chendhuran_SIS/profile.php">
                        <i class="fas fa-user-circle me-2"></i> My Profile
                    </a>
                </li>

            <!-- STUDENT LINKS -->
            <?php elseif($role == 'student'): ?>
                <li class="nav-item mb-1">
                    <a class="nav-link <?php echo ($current_page == 'student_dashboard.php') ? 'active' : ''; ?>" href="/Chendhuran_SIS/student/student_dashboard.php">
                        <i class="fas fa-th-large me-2"></i> Dashboard
                    </a>
                </li>
                <li class="nav-item mb-1">
                    <a class="nav-link <?php echo ($current_page == 'transcript.php') ? 'active' : ''; ?>" href="/Chendhuran_SIS/student/transcript.php">
                        <i class="fas fa-graduation-cap me-2"></i> Academic 
                    </a>
                </li>
                <li class="nav-item mb-1">
                    <a class="nav-link <?php echo ($current_page == 'attendance_record.php') ? 'active' : ''; ?>" href="/Chendhuran_SIS/student/attendance_record.php">
                        <i class="fas fa-calendar-check me-2"></i> Attendance
                    </a>
                </li>
                <li class="nav-item mb-1">
                    <a class="nav-link <?php echo ($current_page == 'leave_requests.php') ? 'active' : ''; ?>" href="/Chendhuran_SIS/student/leave_requests.php">
                        <i class="fas fa-calendar-alt me-2"></i> Leave Requests
                    </a>
                </li>
                <li class="nav-item mb-1">
                    <a class="nav-link <?php echo ($current_page == 'grievance_submit.php') ? 'active' : ''; ?>" href="/Chendhuran_SIS/student/grievance_submit.php">
                        <i class="fas fa-exclamation-triangle me-2"></i> Grievances
                    </a>
                </li>
                <li class="nav-item mb-1">
                    <a class="nav-link <?php echo ($current_page == 'student_feedback.php') ? 'active' : ''; ?>" href="/Chendhuran_SIS/student/student_feedback.php">
                        <i class="fas fa-comment-dots me-2"></i> Feedback
                    </a>
                </li>
                <li class="nav-item mb-1">
                    <a class="nav-link <?php echo ($current_page == 'profile.php') ? 'active' : ''; ?>" href="/Chendhuran_SIS/profile.php">
                        <i class="fas fa-user me-2"></i> My Profile
                    </a>
                </li>
            <?php endif; ?>

            <li class="nav-item mt-4">
                <a class="nav-link text-danger" href="/Chendhuran_SIS/logout.php">
                    <i class="fas fa-sign-out-alt me-2"></i> Sign Out
                </a>
            </li>
        </ul>
    </div>
</nav>
