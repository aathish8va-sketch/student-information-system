<?php
// includes/year_helpers.php - Year/Semester Utility Functions

/**
 * Get year (1-3) from semester (1-6)
 */
function get_year_from_semester($sem) {
    return ceil($sem / 2);
}

/**
 * Get formatted year label
 */
function get_year_label($year) {
    $labels = [1 => '1st Year', 2 => '2nd Year', 3 => '3rd Year'];
    return $labels[$year] ?? "{$year}th Year";
}

/**
 * Get semesters for a given year
 * @return array [sem1, sem2]
 */
function get_semesters_for_year($year) {
    return [($year * 2) - 1, $year * 2];
}

/**
 * Get all years with their semesters
 * @return array
 */
function get_all_years() {
    return [
        1 => ['label' => '1st Year', 'semesters' => [1, 2]],
        2 => ['label' => '2nd Year', 'semesters' => [3, 4]],
        3 => ['label' => '3rd Year', 'semesters' => [5, 6]]
    ];
}

/**
 * Format year and semester display
 */
function format_year_semester($sem) {
    $year = get_year_from_semester($sem);
    return get_year_label($year) . " - Sem $sem";
}
?>
