<?php
// db_connect.php - Core Database Connection

// Start Session globally if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Database Credentials
// IMPORTANT: Change these to match your local MySQL configuration
$servername = "localhost";
$username = "root";  // Default XAMPP username
$password = "";      // Default XAMPP password (usually empty)
$dbname = "chendhuran_sis"; // Database name

// Create Connection using mysqli
$conn = new mysqli($servername, $username, $password, $dbname);

// Check Connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set Charset to UTF-8
$conn->set_charset("utf8mb4");

/**
 * Helper function to sanitize input data
 * Usage: $clean = sanitize_input($_POST['data']);
 */
function sanitize_input($data) {
    global $conn;
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $conn->real_escape_string($data);
}

/**
 * Helper function to prevent Cross-Site Scripting (XSS)
 * Usage: echo escape($string);
 */
function escape($string) {
    return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
}

/**
 * Helper function to check login status
 * Usage: check_login(['admin', 'teacher']);
 */
function check_login($allowed_roles = []) {
    if (!isset($_SESSION['user_id'])) {
        header("Location: /Chendhuran_SIS/login.php");
        exit();
    }
    
    if (!empty($allowed_roles) && !in_array($_SESSION['role'], $allowed_roles)) {
        // Access Denied
        header("Location: /Chendhuran_SIS/login.php?error=unauthorized");
        exit();
    }
}

/**
 * Academic Helper: Get Grade Letter from Marks (0-100)
 */
function get_grade($marks) {
    if ($marks >= 85) return 'A+';
    if ($marks >= 75) return 'A';
    if ($marks >= 65) return 'B';
    if ($marks >= 55) return 'C';
    if ($marks >= 50) return 'D';
    return 'F'; // Fail
}

/**
 * Academic Helper: Get Grade Point from Marks (4.0 Scale)
 */
function get_grade_point($marks) {
    if ($marks >= 85) return 4.0;
    if ($marks >= 75) return 3.7;
    if ($marks >= 65) return 3.0;
    if ($marks >= 55) return 2.5;
    if ($marks >= 50) return 2.0;
    return 0.0;
}

/**
 * Security: Generate CSRF Token
 */
function generate_csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Security: Verify CSRF Token
 */
function verify_csrf_token($token) {
    if (isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token)) {
        return true;
    }
    return false;
}

/**
 * Audit: Log User Activity
 */
function log_activity($user_id, $action, $details = null) {
    global $conn;
    $ip = $_SERVER['REMOTE_ADDR'];
    $stmt = $conn->prepare("INSERT INTO audit_logs (user_id, action, details, ip_address) VALUES (?, ?, ?, ?)");
    if ($stmt) {
        $stmt->bind_param("isss", $user_id, $action, $details, $ip);
        $stmt->execute();
        $stmt->close();
    }
}
?>
