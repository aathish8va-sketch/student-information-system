# 📂 Chendhuran SIS - Project Map

This document explains "What is What" in the codebase, categorized by who uses it.

## 🎓 Student Zone
*Files used by Students.*

| File Name | Functional Name | Purpose |
| :--- | :--- | :--- |
| `student_dashboard.php` | **Home / Dashboard** | The main landing page. Shows CGPA, Attendance, Risks, and Charts. |
| `transcript.php` | **My Marks** | View detailed semester-wise mark sheets. |
| `grievance_submit.php` | **Redressal** | Submit complaints or grievances to HODs. |
| `student_feedback.php` | **Feedback** | Submit feedback about subjects/teachers. |
| `profile.php` | **My Profile** | View personal details and change password. |

---

## 👨‍🏫 Teacher Zone
*Files used by Faculty.*

| File Name | Functional Name | Purpose |
| :--- | :--- | :--- |
| `teacher_dashboard.php` | **Home / Dashboard** | Overview of assigned classes and quick stats. |
| `mark_attendance.php` | **Take Attendance** | Interface to mark daily attendance for a class. |
| `submit_score.php` | **Marks Entry** | Enter internal/test marks for students. |
| `grievance_list.php` | **Grievance Inbox** | View and resolve student complaints. |
| `profile.php` | **My Profile** | View personal details and change password. |

---

## 🛡️ Admin Zone
*Files used by Administrators.*

| File Name | Functional Name | Purpose |
| :--- | :--- | :--- |
| `admin_dashboard.php` | **Admin Control Panel** | High-level stats: Total students, teachers, pass %. |
| `admin_users.php` | **User Manager** | Add/Edit/Delete accounts (Students & Teachers). |
| `admin_subjects.php` | **Subject Manager** | Create subjects and assign them to teachers. |
| `admin_reports.php` | **Reports** | Download analytics and academic reports. |
| `admin_audit_logs.php` | **Security Logs** | See who logged in or changed data. |

---

## ⚙️ Core System Files
*Files that make the system work (Backend).*

- `db_connect.php`: **Database Connection** - links PHP to MySQL.
- `login.php`: **Login Page** - The entry point for everyone.
- `sidebar.php`: **Navigation Menu** - The left-side menu bar.
- `navbar.php`: **Top Header** - The top bar with Logo and Logout.
- `seed_data.php`: **Data Gen** - Creates dummy data for testing.
