<?php
// Redirect old path to new path
header("Location: student/student_dashboard.php");
exit();
?>
