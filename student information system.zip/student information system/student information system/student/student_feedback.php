<?php
// student_feedback.php - Structured Feedback System
require_once '../includes/db_connect.php';
check_login(['student']);

$student_id = $_SESSION['profile_id'];
$message = '';
$error = '';

// 1. Get Student's Current Academic Status
$stud = $conn->query("SELECT department, semester FROM students WHERE student_id=$student_id")->fetch_assoc();
$my_dept = $stud['department'];
$my_sem = $stud['semester']; // We will use this integer directly

// 2. FORM HANDLING
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_feedback'])) {
    $feed_type = sanitize_input($_POST['feedback_type']);
    $target_val = sanitize_input($_POST['target_id']); // Can be subject_code or teacher_id
    $rating = intval($_POST['rating']);
    $comments = sanitize_input($_POST['message']);

    // Prepare data based on type
    $subj_code = NULL;
    $teach_id = NULL;

    if ($feed_type == 'Subject') {
        $subj_code = $target_val;
        // Check duplicate
        $check = $conn->query("SELECT feedback_id FROM feedback WHERE student_id=$student_id AND feedback_type='Subject' AND subject_code='$subj_code' AND semester=$my_sem");
    } else {
        $teach_id = intval($target_val);
        // Check duplicate for this teacher in this sem
        $check = $conn->query("SELECT feedback_id FROM feedback WHERE student_id=$student_id AND feedback_type='Faculty' AND teacher_id=$teach_id AND semester=$my_sem");
    }

    if ($check && $check->num_rows > 0) {
        $error = "You have already submitted feedback for this " . $feed_type . " this semester.";
    } else {
        // Insert
        // rating is already in the table per user confirmation of schema error
        $sql = "INSERT INTO feedback (student_id, feedback_type, subject_code, teacher_id, semester, rating, comments) 
                VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("issiiis", $student_id, $feed_type, $subj_code, $teach_id, $my_sem, $rating, $comments);
        
        if ($stmt->execute()) {
            $message = "Feedback submitted successfully! Thank you.";
        } else {
            $error = "Database Error: " . $stmt->error;
        }
    }
}

// 3. FETCH DATA FOR FORM
// Get all subjects for current Sem & Dept
$subjects_res = $conn->query("SELECT * FROM subjects WHERE department='$my_dept' AND semester=$my_sem");
$subjects = [];
if($subjects_res) {
    while($s = $subjects_res->fetch_assoc()) {
        // Check if feedback already given (this semester)
        $chk = $conn->query("SELECT 1 FROM feedback WHERE student_id=$student_id AND feedback_type='Subject' AND subject_code='{$s['subject_code']}' AND semester=$my_sem");
        if($chk->num_rows == 0) {
            $subjects[] = $s;
        }
    }
}

// Get all teachers handling these subjects (or just Dept teachers)
$teachers_res = $conn->query("SELECT * FROM teachers WHERE department='$my_dept'");
$teachers = [];
if($teachers_res) {
    while($t = $teachers_res->fetch_assoc()) {
        // Check if feedback already given
        $chk = $conn->query("SELECT 1 FROM feedback WHERE student_id=$student_id AND feedback_type='Faculty' AND teacher_id={$t['teacher_id']} AND semester=$my_sem");
        if($chk->num_rows == 0) {
            $teachers[] = $t;
        }
    }
}

// Fetch History (Current Semester Only)
$history = $conn->query("SELECT * FROM feedback WHERE student_id = $student_id AND semester = $my_sem ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Feedback - Chendhuran SIS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../includes/css/styles.css" rel="stylesheet">
    <style>
        .star-rating { direction: rtl; display: inline-block; font-size: 1.5rem; }
        .star-rating input { display: none; }
        .star-rating label { color: #ddd; cursor: pointer; }
        .star-rating input:checked ~ label, .star-rating label:hover, .star-rating label:hover ~ label { color: #f59e0b; }
    </style>
</head>
<body>

<?php include '../includes/sidebar.php'; ?>

<main class="main-content">
    <div class="glass-header">
        <h4 class="fw-bold mb-1">Semester Feedback</h4>
        <p class="text-muted mb-0 small">Rate your Subjects and Faculty (Sem <?php echo $my_sem; ?>)</p>
    </div>

    <?php if($message): ?><div class="alert alert-success shadow-sm"><?php echo $message; ?></div><?php endif; ?>
    <?php if($error): ?><div class="alert alert-danger shadow-sm"><?php echo $error; ?></div><?php endif; ?>

    <div class="row">
        <!-- FORM SECTION -->
        <div class="col-lg-5 mb-4">
            <div class="glass-card p-4 h-100">
                <h5 class="mb-4 fw-bold text-primary">Provide Feedback</h5>
                
                <form method="POST" id="feedbackForm">
                    <!-- Toggle Type -->
                    <div class="btn-group w-100 mb-3" role="group">
                        <input type="radio" class="btn-check" name="feedback_type" id="typeSubject" value="Subject" checked onchange="toggleForm('Subject')">
                        <label class="btn btn-outline-primary" for="typeSubject"><i class="fas fa-book me-2"></i>Subject</label>

                        <input type="radio" class="btn-check" name="feedback_type" id="typeFaculty" value="Faculty" onchange="toggleForm('Faculty')">
                        <label class="btn btn-outline-primary" for="typeFaculty"><i class="fas fa-chalkboard-teacher me-2"></i>Faculty</label>
                    </div>

                    <!-- Subject Dropdown -->
                    <div class="mb-3" id="subjectField">
                        <label class="form-label">Select Subject</label>
                        <select name="target_id" class="form-select" id="subjSelect">
                            <option value="">-- Choose Subject --</option>
                            <?php foreach($subjects as $s): ?>
                                <option value="<?php echo $s['subject_code']; ?>"><?php echo $s['subject_name']; ?> (<?php echo $s['subject_code']; ?>)</option>
                            <?php endforeach; ?>
                        </select>
                        <?php if(empty($subjects)): ?>
                            <small class="text-success d-block mt-1"><i class="fas fa-check-circle me-1"></i> You have rated all subjects!</small>
                        <?php endif; ?>
                    </div>

                    <!-- Faculty Dropdown (Hidden initially) -->
                    <div class="mb-3" id="facultyField" style="display:none;">
                        <label class="form-label">Select Faculty</label>
                        <select name="target_id" class="form-select" id="facSelect" disabled>
                            <option value="">-- Choose Teacher --</option>
                            <?php foreach($teachers as $t): ?>
                                <option value="<?php echo $t['teacher_id']; ?>"><?php echo $t['name']; ?></option>
                            <?php endforeach; ?>
                        </select>
                        <?php if(empty($teachers)): ?>
                            <small class="text-success d-block mt-1"><i class="fas fa-check-circle me-1"></i> You have rated all faculty!</small>
                        <?php endif; ?>
                    </div>

                    <!-- Rating -->
                    <div class="mb-3 text-center">
                        <label class="form-label d-block">Your Rating</label>
                        <div class="star-rating">
                            <input type="radio" id="star5" name="rating" value="5" required><label for="star5" title="Excellent"><i class="fas fa-star"></i></label>
                            <input type="radio" id="star4" name="rating" value="4"><label for="star4" title="Good"><i class="fas fa-star"></i></label>
                            <input type="radio" id="star3" name="rating" value="3"><label for="star3" title="Average"><i class="fas fa-star"></i></label>
                            <input type="radio" id="star2" name="rating" value="2"><label for="star2" title="Poor"><i class="fas fa-star"></i></label>
                            <input type="radio" id="star1" name="rating" value="1"><label for="star1" title="Very Poor"><i class="fas fa-star"></i></label>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Comments</label>
                        <textarea name="message" class="form-control" rows="3" required placeholder="What did you like? What can be improved?"></textarea>
                    </div>

                    <button type="submit" name="submit_feedback" class="btn btn-primary w-100">Submit Feedback</button>
                </form>
            </div>
        </div>

        <!-- HISTORY SECTION -->
        <div class="col-lg-7">
            <div class="glass-card p-4 h-100">
                 <h5 class="mb-3 fw-bold text-secondary">Feedback History (Sem <?php echo $my_sem; ?>)</h5>
                 <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="bg-light">
                            <tr>
                                <th>Type</th>
                                <th>Target</th>
                                <th>Rating</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($history && $history->num_rows > 0): ?>
                                <?php while($row = $history->fetch_assoc()): 
                                    $target = ($row['feedback_type'] == 'Subject') ? $row['subject_code'] : "Teacher ID: " . $row['teacher_id']; // Can resolve name if needed
                                ?>
                                    <tr>
                                        <td><span class="badge bg-light text-dark border"><?php echo $row['feedback_type'] ?? 'General'; ?></span></td>
                                        <td class="fw-bold text-primary"><?php echo htmlspecialchars($target); ?></td>
                                        <td>
                                            <span class="text-warning">
                                                <?php for($i=0; $i<$row['rating']; $i++) echo '<i class="fas fa-star"></i>'; ?>
                                            </span>
                                        </td>
                                        <td class="text-muted text-sm"><?php echo date('M d', strtotime($row['created_at'])); ?></td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr><td colspan="4" class="text-center text-muted py-4">No feedback submitted yet.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</main>

<script>
function toggleForm(type) {
    if (type === 'Subject') {
        document.getElementById('subjectField').style.display = 'block';
        document.getElementById('subjSelect').disabled = false;
        document.getElementById('facultyField').style.display = 'none';
        document.getElementById('facSelect').disabled = true;
    } else {
        document.getElementById('subjectField').style.display = 'none';
        document.getElementById('subjSelect').disabled = true;
        document.getElementById('facultyField').style.display = 'block';
        document.getElementById('facSelect').disabled = false;
    }
}
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
