<?php
// transcript.php - Official Academic Record (Web View)
require_once '../includes/db_connect.php';
require_once '../includes/year_helpers.php';
check_login(['student', 'admin']);

$viewer_role = $_SESSION['role'];
$target_student_id = 0;

if ($viewer_role == 'student') {
    $target_student_id = $_SESSION['profile_id'];
} elseif ($viewer_role == 'admin') {
    if (isset($_GET['student_id'])) {
        $target_student_id = intval($_GET['student_id']);
    } else {
        die("Student ID required for Admin view.");
    }
} else {
    die("Access Denied");
}

// 1. Fetch Student Info
$stmt = $conn->prepare("SELECT * FROM students WHERE student_id = ?");
$stmt->bind_param("i", $target_student_id);
$stmt->execute();
$student = $stmt->get_result()->fetch_assoc();
if (!$student) die("Student not found.");

$current_sem_max = $student['semester'];
$selected_sem = isset($_GET['semester']) ? intval($_GET['semester']) : $current_sem_max;

// 2. Fetch ALL Subjects for student's department (only up to current semester)
// Then fetch scores separately and merge
$dept = $student['department'];

// First, get all subjects for this student's department (only semesters reached)
$subjects_sql = "SELECT subject_code, subject_name, semester, credits 
                 FROM subjects 
                 WHERE department = ? AND semester <= ?
                 ORDER BY semester ASC, subject_code ASC";
$stmt = $conn->prepare($subjects_sql);
$stmt->bind_param("si", $dept, $current_sem_max);
$stmt->execute();
$subjects_res = $stmt->get_result();

// Initialize structure with all subjects
$all_sem_data = [];
while($sub = $subjects_res->fetch_assoc()) {
    $sem = $sub['semester'];
    $code = $sub['subject_code'];
    
    if (!isset($all_sem_data[$sem])) $all_sem_data[$sem] = [];
    $all_sem_data[$sem][$code] = [
        'name' => $sub['subject_name'],
        'credits' => $sub['credits'] ?? 3,
        'breakdown' => []
    ];
}

// Now fetch scores and merge
$scores_sql = "SELECT subject_code, assessment_type, marks_obtained 
               FROM scores 
               WHERE student_id = ?";
$stmt = $conn->prepare($scores_sql);
$stmt->bind_param("i", $target_student_id);
$stmt->execute();
$scores_res = $stmt->get_result();

while($score = $scores_res->fetch_assoc()) {
    $code = $score['subject_code'];
    $type = $score['assessment_type'];
    $marks = $score['marks_obtained'];
    
    // Find which semester this subject belongs to
    foreach($all_sem_data as $sem => $subjects) {
        if (isset($subjects[$code])) {
            $all_sem_data[$sem][$code]['breakdown'][$type] = $marks;
            break;
        }
    }
}

// Custom Grade Logic
function get_custom_grade($marks) {
    // scale: 100-97 O, 96-91 A+, 90-81 A, 80-71 B+, 70-61 B, 60-51 C, 50-40 P, <40 F
    if ($marks >= 97) return ['O', 10];
    if ($marks >= 91) return ['A+', 9];
    if ($marks >= 81) return ['A', 8];
    if ($marks >= 71) return ['B+', 7];
    if ($marks >= 61) return ['B', 6];
    if ($marks >= 51) return ['C', 5];
    if ($marks >= 40) return ['P', 4];
    return ['F', 0];
}

// Calculate CGPA (Weighted Average)
$total_weighted_points = 0;
$total_credits = 0;

foreach($all_sem_data as $s_id => $subs) {
    // Only calculate CGPA up to the selected semester (Snapshot view)
    if ($s_id > $selected_sem) continue;

    foreach($subs as $code => $data) {
        $final_mark = $data['breakdown']['Final Exam'] ?? null;
        $cr = $data['credits']; // Default set above
        // Only count subjects with Final Exam marks
        if ($final_mark !== null && $final_mark !== '') {
            $g_info = get_custom_grade($final_mark);
            $gp = $g_info[1];
            $total_weighted_points += ($gp * $cr);
            $total_credits += $cr;
        }
    }
}
$cgpa = $total_credits > 0 ? $total_weighted_points / $total_credits : 0;

// Filter for Display
$display_data = $all_sem_data[$selected_sem] ?? [];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Transcript - <?php echo htmlspecialchars($student['roll_number']); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../includes/css/styles.css" rel="stylesheet">
</head>
<body>

<?php include '../includes/sidebar.php'; ?>

<main class="main-content">
    
    <div class="glass-header">
        <h4 class="fw-bold mb-1">Academic Transcript</h4>
        <p class="text-muted mb-0 small">Semester-wise Grade Sheet</p>
    </div>

    <!-- Controls & Info -->
    <div class="glass-card p-3 mb-4">
        <form method="GET" class="row align-items-end">
            <div class="col-md-4">
                <label class="form-label fw-bold">Select Semester</label>
                <select name="semester" class="form-select" required onchange="this.form.submit()">
                    <option value="">Choose...</option>
                    <?php foreach(get_all_years() as $year => $data): 
                        // Only show years/semesters that student has reached
                        $year_first_sem = $data['semesters'][0];
                        if ($year_first_sem > $current_sem_max) continue; // Skip future years
                    ?>
                        <optgroup label="<?php echo $data['label']; ?>">
                            <?php foreach($data['semesters'] as $s): 
                                // Only show semesters student has reached
                                if ($s > $current_sem_max) continue;
                            ?>
                                <option value="<?php echo $s; ?>" <?php if($selected_sem == $s) echo 'selected'; ?>>
                                    Semester <?php echo $s; ?>
                                </option>
                            <?php endforeach; ?>
                        </optgroup>
                    <?php endforeach; ?>
                </select>
                <?php if($viewer_role == 'admin'): ?>
                    <input type="hidden" name="student_id" value="<?php echo $target_student_id; ?>">
                <?php endif; ?>
            </div>
            <div class="col-md-8 text-end">
                <div class="d-inline-block bg-white px-4 py-2 rounded shadow-sm border">
                    <small class="text-muted d-block text-uppercase fw-bold" style="font-size: 0.7rem;">Cumulative GPA</small>
                    <span class="fs-4 fw-bold text-primary"><?php echo number_format($cgpa, 2); ?> <span class="fs-6 text-muted">/ 10</span></span>
                </div>
            </div>
        </form>
    </div>

    <!-- Marks Table -->
    <div class="glass-card p-0 overflow-hidden">
        <div class="card-header bg-white p-3 border-bottom d-flex justify-content-between align-items-center">
            <h6 class="fw-bold mb-0 text-primary">Semester <?php echo $selected_sem; ?> Results</h6>
            <?php 
                // Calc SGPA for selected sem (Weighted)
                $sem_weighted_p = 0; 
                $sem_credits = 0;
                foreach($display_data as $sub) {
                    $fm = $sub['breakdown']['Final Exam'] ?? null;
                    $cr = $sub['credits'];
                    // Only count if Final Exam mark exists
                    if ($fm !== null && $fm !== '') {
                        $gp = get_custom_grade($fm)[1];
                        $sem_weighted_p += ($gp * $cr);
                        $sem_credits += $cr;
                    }
                }
                $sgpa = $sem_credits > 0 ? $sem_weighted_p / $sem_credits : 0;
            ?>
            <span class="badge bg-primary bg-opacity-10 text-primary border border-primary">SGPA: <?php echo number_format($sgpa, 2); ?> / 10</span>
        </div>
        
        <?php if(empty($display_data)): ?>
            <div class="p-5 text-center text-muted">
                <p>No records found for Semester <?php echo $selected_sem; ?>.</p>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0 text-center">
                    <thead class="bg-light text-muted small text-uppercase" style="font-size: 0.8rem;">
                        <tr>
                            <th class="text-start ps-4" style="width: 30%;">Subject</th>
                            <th>Asmt 1<br><span class="text-muted fw-normal">(50)</span></th>
                            <th>Asmt 2<br><span class="text-muted fw-normal">(50)</span></th>
                            <th>Asmt 3<br><span class="text-muted fw-normal">(50)</span></th>
                            <th>Assg<br><span class="text-muted fw-normal">(20)</span></th>
                            <th class="bg-primary bg-opacity-10 text-primary">Final<br><span class="text-muted fw-normal">(100)</span></th>
                            <th>Grade</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($display_data as $code => $data): 
                            $bk = $data['breakdown'];
                            $a1 = $bk['Assessment 1'] ?? '-';
                            $a2 = $bk['Assessment 2'] ?? '-';
                            $a3 = $bk['Assessment 3'] ?? '-';
                            $assg = $bk['Assignment'] ?? ($bk['Assignment 1'] ?? '-'); 
                            $final = $bk['Final Exam'] ?? '-';
                            
                            // Only calculate grade if Final Exam exists
                            $grade = '-';
                            $grade_cls = 'badge bg-secondary';
                            
                            if ($final !== '-' && $final !== null && $final !== '') {
                                $final_int = (int)$final;
                                list($grade, $gp) = get_custom_grade($final_int);
                                $grade_cls = ($grade == 'F') ? 'badge bg-danger' : 
                                            (($grade == 'O' || $grade == 'A+') ? 'badge bg-success' : 'badge bg-secondary');
                            }
                        ?>
                        <tr>
                            <td class="text-start ps-4">
                                <span class="fw-bold text-dark"><?php echo htmlspecialchars($data['name']); ?></span><br>
                                <small class="text-muted"><?php echo htmlspecialchars($code); ?></small>
                            </td>
                            <td><?php echo $a1; ?></td>
                            <td><?php echo $a2; ?></td>
                            <td><?php echo $a3; ?></td>
                            <td><?php echo $assg; ?></td>
                            <td class="bg-primary bg-opacity-10 fw-bold text-dark"><?php echo $final; ?></td>
                            <td><span class="<?php echo $grade_cls; ?>"><?php echo $grade; ?></span></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
    
    <div class="alert alert-light mt-4 border text-muted small">
        <strong><i class="fas fa-info-circle me-1"></i> Grading Scale:</strong>
        O (97-100), A+ (91-96), A (81-90), B+ (71-80), B (61-70), C (51-60), P (40-50), F (<40).
        <br>
        * Grade and GPA are based solely on the Final Exam mark.
    </div>

</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
