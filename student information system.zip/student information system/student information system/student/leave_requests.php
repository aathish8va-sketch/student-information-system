<?php
// student/leave_requests.php - Combined Apply and View Leave Requests
require_once '../includes/db_connect.php';
check_login(['student']);

$student_id = $_SESSION['profile_id'];
$student_name = $_SESSION['user_name'];

// Fetch student info
$s_query = $conn->query("SELECT * FROM students WHERE student_id = $student_id");
$student = $s_query->fetch_assoc();

// Handle form submission
$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_request'])) {
    if (!verify_csrf_token($_POST['csrf_token'])) {
        $error = "Invalid request. Please try again.";
    } else {
        $request_type = sanitize_input($_POST['request_type']);
        $from_date = sanitize_input($_POST['from_date']);
        $to_date = sanitize_input($_POST['to_date']);
        $reason = sanitize_input($_POST['reason']);
        
        if (empty($request_type) || empty($from_date) || empty($to_date) || empty($reason)) {
            $error = "All fields are required.";
        } elseif (strtotime($to_date) < strtotime($from_date)) {
            $error = "End date cannot be before start date.";

        } else {
             // VALIDATION: Semester & Holiday Check
             $error_found = false;

             // 1. Check if dates fall within Active Semester (Strict for Students)
             $sem_check = $conn->query("SELECT * FROM semester_dates WHERE ('$from_date' BETWEEN start_date AND end_date) AND ('$to_date' BETWEEN start_date AND end_date)");
             if ($sem_check->num_rows == 0) {
                 $error = "Leave dates fall outside the Active Semester dates.";
                 $error_found = true;
             }
             else {
                 // 2. Check for Holidays/Sundays
                 $check_dates = [$from_date, $to_date];
                 foreach($check_dates as $d) {
                     if (date('N', strtotime($d)) == 7) {
                         $error = "Selected date ($d) is a Sunday.";
                         $error_found = true;
                         break;
                     }
                     $h_check = $conn->query("SELECT * FROM academic_holidays WHERE holiday_date = '$d'");
                     if ($h_check->num_rows > 0) {
                         $h_name = $h_check->fetch_assoc()['description'];
                         $error = "Selected date ($d) is a Holiday ($h_name).";
                         $error_found = true;
                         break;
                     }
                 }
             }

             if (!$error_found) {
                $stmt = $conn->prepare("INSERT INTO leave_requests (student_id, request_type, from_date, to_date, reason, status, submitted_at) VALUES (?, ?, ?, ?, ?, 'Pending', NOW())");
                if ($stmt === false) {
                    $error = "Database error: " . $conn->error;
                } else {
                    $stmt->bind_param("issss", $student_id, $request_type, $from_date, $to_date, $reason);
                    
                    if ($stmt->execute()) {
                        $success = "Your leave request has been submitted successfully.";
                        $_POST = array();
                    } else {
                        $error = "Failed to submit request. Please try again.";
                    }
                    $stmt->close();
                }
             }
        }
    }

}

// Filter
$filter = isset($_GET['filter']) ? $_GET['filter'] : 'all';
$where_clause = "lr.student_id = $student_id";
if ($filter == 'pending') {
    $where_clause .= " AND lr.status = 'Pending'";
} elseif ($filter == 'approved') {
    $where_clause .= " AND (lr.status = 'Approved' OR lr.status = 'Approved by Principal')";
} elseif ($filter == 'rejected') {
    $where_clause .= " AND (lr.status LIKE '%Rejected%')";
}

// Fetch requests
$requests_query = "
    SELECT lr.*, t1.name as mentor_name, t2.name as hod_name, t3.name as principal_name
    FROM leave_requests lr
    LEFT JOIN teachers t1 ON lr.mentor_id = t1.teacher_id
    LEFT JOIN teachers t2 ON lr.hod_id = t2.teacher_id
    LEFT JOIN teachers t3 ON lr.principal_id = t3.teacher_id
    WHERE $where_clause
    ORDER BY lr.submitted_at DESC
";
$requests = $conn->query($requests_query);

function get_status_badge($status) {
    switch($status) {
        case 'Pending': return '<span class="badge bg-warning text-dark">Pending Review</span>';
        case 'Approved by Mentor': return '<span class="badge bg-info">Approved - Pending HOD</span>';
        case 'Approved by HOD': return '<span class="badge bg-primary">Approved - Pending Principal</span>';
        case 'Approved': return '<span class="badge bg-success">Approved</span>';
        case 'Approved by Principal': return '<span class="badge bg-success">Fully Approved</span>';
        default: return '<span class="badge bg-danger">Rejected</span>';
    }
}

function get_request_icon($type) {
    switch($type) {
        case 'Medical Leave': return '<i class="fas fa-clinic-medical text-danger"></i>';
        case 'Personal Leave': return '<i class="fas fa-user-clock text-primary"></i>';
        case 'On-Duty': return '<i class="fas fa-briefcase text-success"></i>';
        default: return '<i class="fas fa-file"></i>';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Leave Requests - Chendhuran SIS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;800&display=swap" rel="stylesheet">
    <link href="../includes/css/styles.css" rel="stylesheet">
</head>
<body>
<?php include '../includes/sidebar.php'; ?>

<main class="main-content">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h3 class="fw-bold mb-1">Leave & On-Duty Requests</h3>
            <p class="text-muted mb-0"><i class="fas fa-user me-1"></i> <?php echo htmlspecialchars($student_name); ?></p>
        </div>
    </div>

    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="fas fa-check-circle me-2"></i><?php echo $success; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <i class="fas fa-exclamation-circle me-2"></i><?php echo $error; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- Application Form -->
    <div class="card border-0 shadow-sm mb-4">
        <div class="card-header bg-white border-bottom">
            <h6 class="fw-bold mb-0"><i class="fas fa-plus-circle me-2 text-primary"></i> Submit New Request</h6>
        </div>
        <div class="card-body">
            <form method="POST" action="">
                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                <div class="row g-3">
                    <div class="col-md-3">
                        <label class="form-label fw-semibold">Type <span class="text-danger">*</span></label>
                        <select name="request_type" class="form-select" required>
                            <option value="">Select type</option>
                            <option value="Medical Leave">Medical Leave</option>
                            <option value="Personal Leave">Personal Leave</option>
                            <option value="On-Duty">On-Duty</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label fw-semibold">From Date <span class="text-danger">*</span></label>
                        <input type="date" name="from_date" class="form-control" min="<?php echo date('Y-m-d'); ?>" required>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label fw-semibold">To Date <span class="text-danger">*</span></label>
                        <input type="date" name="to_date" class="form-control" min="<?php echo date('Y-m-d'); ?>" required>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label fw-semibold">&nbsp;</label>
                        <button type="submit" name="submit_request" class="btn btn-primary w-100">
                            <i class="fas fa-paper-plane me-2"></i> Submit Request
                        </button>
                    </div>
                </div>
                <div class="mt-3">
                    <label class="form-label fw-semibold">Reason <span class="text-danger">*</span></label>
                    <textarea name="reason" class="form-control" rows="2" placeholder="Provide reason..." required></textarea>
                </div>
            </form>
        </div>
    </div>

    <!-- Filter Tabs -->
    <div class="card border-0 shadow-sm mb-3">
        <div class="card-body p-0">
            <ul class="nav nav-pills p-3">
                <li class="nav-item">
                    <a class="nav-link <?php echo $filter == 'all' ? 'active' : ''; ?>" href="?filter=all">All</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo $filter == 'pending' ? 'active' : ''; ?>" href="?filter=pending">Pending</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo $filter == 'approved' ? 'active' : ''; ?>" href="?filter=approved">Approved</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo $filter == 'rejected' ? 'active' : ''; ?>" href="?filter=rejected">Rejected</a>
                </li>
            </ul>
        </div>
    </div>

    <!-- Requests List -->
    <?php if ($requests && $requests->num_rows > 0): ?>
        <?php while ($req = $requests->fetch_assoc()): ?>
            <div class="card border-0 shadow-sm mb-3">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-8">
                            <div class="d-flex align-items-start">
                                <div class="me-3 fs-3"><?php echo get_request_icon($req['request_type']); ?></div>
                                <div class="flex-grow-1">
                                    <h6 class="fw-bold mb-1"><?php echo htmlspecialchars($req['request_type']); ?></h6>
                                    <p class="text-muted small mb-2">
                                        <i class="fas fa-calendar me-1"></i>
                                        <?php echo date('M d', strtotime($req['from_date'])); ?> - <?php echo date('M d, Y', strtotime($req['to_date'])); ?>
                                    </p>
                                    <p class="mb-0"><strong>Reason:</strong> <?php echo htmlspecialchars($req['reason']); ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 text-md-end">
                            <?php echo get_status_badge($req['status']); ?>
                            <br><small class="text-muted">Submitted: <?php echo date('M d, Y', strtotime($req['submitted_at'])); ?></small>
                        </div>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>
    <?php else: ?>
        <div class="card border-0 shadow-sm">
            <div class="card-body text-center py-5">
                <i class="fas fa-inbox fa-4x text-muted mb-3"></i>
                <p class="text-muted">No requests found</p>
            </div>
        </div>
    <?php endif; ?>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
setTimeout(() => document.querySelectorAll('.alert').forEach(a => new bootstrap.Alert(a).close()), 3000);
</script>
</body>
</html>
