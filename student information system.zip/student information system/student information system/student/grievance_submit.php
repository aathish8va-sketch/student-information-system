<?php
// grievance_submit.php
require_once '../includes/db_connect.php';
check_login(['student']);

$student_id = $_SESSION['profile_id'];
$message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_grievance'])) {
    // Auto-fetch department from student profile (secure method)
    $stud = $conn->query("SELECT department FROM students WHERE student_id=$student_id")->fetch_assoc();
    $dept = $stud['department']; // Automatically set to student's department

    $type = sanitize_input($_POST['grievance_type'] ?? 'General');
    $subj = sanitize_input($_POST['subject_code'] ?? '');
    $msg = sanitize_input($_POST['message']); 
    $msg_safe = $conn->real_escape_string($_POST['message']); 

    $sql = "INSERT INTO grievances (student_id, department, grievance_type, subject_code, message, status) VALUES ('$student_id', '$dept', '$type', '$subj', '$msg_safe', 'Pending')";
    if ($conn->query($sql)) {
        $message = "<div class='alert alert-success'>Grievance submitted successfully to $dept HOD.</div>";
    } else {
        $message = "<div class='alert alert-danger'>Error: " . $conn->error . "</div>";
    }
}

// Fetch student dept to pre-fill
$stud = $conn->query("SELECT department FROM students WHERE student_id=$student_id")->fetch_assoc();
$my_dept = $stud['department'];

// Fetch subjects for dropdown
$sub_query = "SELECT * FROM subjects WHERE department = '$my_dept'"; // Simplified: Show all dept subjects
$subjects = $conn->query($sub_query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Grievance Redressal - Chendhuran SIS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../includes/css/styles.css" rel="stylesheet">
</head>
</head>
<body>
<?php include '../includes/sidebar.php'; ?>

<main class="main-content">
    <div class="glass-header">
        <h4 class="fw-bold mb-1">Grievance Redressal</h4>
        <p class="text-muted mb-0 small">Submit and track your complaints securely.</p>
    </div>
    
    <?php echo $message; ?>

            <div class="glass-card p-4">
                <h5 class="mb-3">Submit a Complaint</h5>
                <form method="POST">
                    <div class="row g-3">
                        <!-- 1. Complaint Category (About What) -->
                        <div class="col-md-12">
                            <label class="form-label">Complaint Category (What is this about?)</label>
                            <select name="grievance_type" class="form-select" required>
                                <option value="General">General Issue</option>
                                <option value="Academic">Academic (Grades, Teaching)</option>
                                <option value="Infrastructure">Infrastructure (Lab, Classroom)</option>
                                <option value="Personal">Personal / Harassment</option>
                                <option value="Ragging">Ragging (Urgent)</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>

                        <!-- 3. Subject (Topic) -->
                        <div class="col-md-12">
                            <label class="form-label">Subject / Topic</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-book"></i></span>
                                <input type="text" name="subject_code" class="form-control" placeholder="e.g. CS302 or 'Canteen Issue'">
                            </div>
                            <small class="text-muted">Enter Subject Code for academic issues, or a brief topic for others.</small>
                        </div>

                        <!-- 4. Details -->
                        <div class="col-md-12">
                            <label class="form-label">Grievance Details</label>
                            <textarea name="message" class="form-control" rows="5" required placeholder="Please describe your grievance in detail..."></textarea>
                        </div>
                    </div>

                    <div class="mt-4 text-end">
                        <button type="submit" name="submit_grievance" class="btn btn-danger px-4">
                            <i class="fas fa-paper-plane me-2"></i> Submit Grievance
                        </button>
                    </div>
                </form>
            </div>

            <div class="mt-4">
                <h5 class="mb-3">My Past Grievances</h5>
                <div class="glass-card p-0 overflow-hidden">
                    <table class="table table-hover mb-0">
                        <thead class="bg-light">
                            <tr>
                                <th>Date</th>
                                <th>To</th>
                                <th>Subject</th>
                                <th>Message</th>
                                <th>Status</th>
                                <th>Response</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $hist = $conn->query("SELECT * FROM grievances WHERE student_id=$student_id ORDER BY created_at DESC");
                            while($row = $hist->fetch_assoc()):
                                $status = !empty($row['status']) ? $row['status'] : 'Pending';
                                $statusColor = match($status) {
                                    'Pending', 'In Progress' => 'bg-warning text-dark',
                                    'Resolved', 'Closed', 'Resolved by HOD', 'Resolved by Principal' => 'bg-success',
                                    'Rejected', 'Rejected by HOD', 'Rejected by Principal' => 'bg-danger',
                                    default => 'bg-secondary'
                                };
                            ?>
                            <tr>
                                <td><?php echo date('d M Y', strtotime($row['created_at'])); ?></td>
                                <td><?php echo $row['department']; ?></td>
                                <td><?php echo $row['subject_code'] ?: 'General'; ?></td>
                                <td style="white-space: pre-wrap;"><?php echo htmlspecialchars($row['message']); ?></td>
                                <td><span class="badge <?php echo $statusColor; ?>"><?php echo htmlspecialchars($status); ?></span></td>
                                <td class="small text-muted"><?php echo $row['admin_response'] ? htmlspecialchars($row['admin_response']) : '-'; ?></td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </main>
    </div>
</div>
</body>
</html>
