<?php
// student/academic_records.php - Detailed Semester Performance
require_once '../includes/db_connect.php';
check_login(['student']);

$student_id = $_SESSION['profile_id'];
$student_name = $_SESSION['user_name'];

// Fetch Student Data
$s_res = $conn->query("SELECT * FROM students WHERE student_id = $student_id")->fetch_assoc();
$current_sem = $s_res['semester'];
$dept = $s_res['department'];

// Semester Selection
$selected_sem = isset($_GET['semester']) ? intval($_GET['semester']) : $current_sem;

// Fetch Subjects for Selected Semester
$subjects_query = "SELECT * FROM subjects WHERE department = '$dept' AND semester = $selected_sem ORDER BY subject_code";
$subjects = $conn->query($subjects_query);

// Helper for GP
function calculate_gp($marks, $max) {
    if ($max == 0) return 0;
    $pct = ($marks / $max) * 100;
    if ($pct >= 90) return 10;
    if ($pct >= 80) return 9;
    if ($pct >= 70) return 8;
    if ($pct >= 60) return 7;
    if ($pct >= 50) return 6;
    return 0;
}

function calculate_grade($marks, $max) {
    if ($max == 0) return '-';
    $pct = ($marks / $max) * 100;
    if ($pct >= 90) return 'O';
    if ($pct >= 80) return 'A+';
    if ($pct >= 70) return 'A';
    if ($pct >= 60) return 'B+';
    if ($pct >= 50) return 'B';
    return 'RA';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Academic Records - Chendhuran SIS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../includes/css/styles.css" rel="stylesheet">
</head>
<body>

<?php include '../includes/sidebar.php'; ?>

<main class="main-content">
    <div class="glass-header">
        <h4 class="fw-bold mb-1">Academic Performance</h4>
        <p class="text-muted mb-0 small">Detailed mark breakdown and GPA analysis.</p>
    </div>

    <!-- Filter Section -->
    <div class="glass-card p-3 mb-4">
        <form method="GET" class="row align-items-end g-2">
            <div class="col-md-4">
                <label class="form-label fw-bold small text-muted">Select Semester</label>
                <select name="semester" class="form-select" onchange="this.form.submit()">
                    <?php for($i=1; $i<=6; $i++): ?>
                        <option value="<?php echo $i; ?>" <?php if($selected_sem == $i) echo 'selected'; ?>>Semester <?php echo $i; ?></option>
                    <?php endfor; ?>
                </select>
            </div>
            <div class="col-md-8 text-end">
                <?php
                // Calculate Accurate CGPA (Average of Subject GPs)
                // 1. Fetch all scores for student
                $all_scores_q = "SELECT subject_code, marks_obtained, max_marks FROM scores WHERE student_id=$student_id";
                $all_res = $conn->query($all_scores_q);
                
                $subj_totals = []; // [code => [obt, max]]
                while($rw = $all_res->fetch_assoc()) {
                    $c = $rw['subject_code'];
                    if(!isset($subj_totals[$c])) $subj_totals[$c] = ['obt'=>0, 'max'=>0];
                    $subj_totals[$c]['obt'] += $rw['marks_obtained'];
                    $subj_totals[$c]['max'] += $rw['max_marks'];
                }
                
                $total_gp = 0;
                $subj_count = 0;
                
                foreach($subj_totals as $st) {
                    if($st['max'] > 0) {
                        $gp = calculate_gp($st['obt'], $st['max']);
                        $total_gp += $gp;
                        $subj_count++;
                    }
                }
                
                $cgpa = $subj_count > 0 ? $total_gp / $subj_count : 0;
                ?>
                <div class="d-inline-block bg-white px-4 py-2 rounded shadow-sm border">
                    <small class="text-muted d-block text-uppercase fw-bold" style="font-size: 0.7rem;">Cumulative GPA</small>
                    <span class="fs-4 fw-bold text-primary"><?php echo number_format($cgpa, 2); ?> <span class="fs-6 text-muted">/ 10</span></span>
                </div>
            </div>
        </form>
    </div>

    <!-- Marks Matrix -->
    <div class="glass-card p-0 overflow-hidden">
        <div class="card-header bg-white p-3 border-bottom">
            <h6 class="fw-bold mb-0 text-primary">Semester <?php echo $selected_sem; ?> Score Sheet</h6>
        </div>
        
        <?php if($subjects && $subjects->num_rows > 0): ?>
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0 text-center">
                <thead class="bg-light text-muted small text-uppercase" style="font-size: 0.8rem;">
                    <tr>
                        <th class="text-start ps-4" style="width: 20%;">Subject</th>
                        <th>Asmt 1<br><span class="text-muted fw-normal">(50)</span></th>
                        <th>Asmt 2<br><span class="text-muted fw-normal">(50)</span></th>
                        <th>Asmt 3<br><span class="text-muted fw-normal">(50)</span></th>
                        <th>Assg<br><span class="text-muted fw-normal">(20)</span></th>
                        <th>Final<br><span class="text-muted fw-normal">(100)</span></th>
                        <th class="bg-primary bg-opacity-10 text-primary">Total</th>
                        <th>Grade</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $sem_gp_total = 0;
                    $sem_sub_count = 0;
                    
                    while($sub = $subjects->fetch_assoc()): 
                        $code = $sub['subject_code'];
                        // Fetch scores for this subject
                        $sc_q = "SELECT assessment_type, marks_obtained, max_marks FROM scores WHERE student_id=$student_id AND subject_code='$code'";
                        $sc_res = $conn->query($sc_q);
                        
                        $marks = []; // Key: Type => Obtained
                        $maxes = []; // Key: Type => Max
                        
                        while($s = $sc_res->fetch_assoc()) {
                            // Normalize keys
                            $key = $s['assessment_type'];
                            $marks[$key] = $s['marks_obtained'];
                            $maxes[$key] = $s['max_marks'];
                        }

                        // Map to columns (Graceful fallback if data missing)
                        $a1 = $marks['Assessment 1'] ?? '-';
                        $a2 = $marks['Assessment 2'] ?? '-';
                        $a3 = $marks['Assessment 3'] ?? '-';
                        // Handle Variations of Assignment
                        $assg = $marks['Assignment'] ?? ($marks['Assignment 1'] ?? '-'); 
                        $final = $marks['Final Exam'] ?? '-';

                        // Calculate Total for Row
                        $row_obt = 0; 
                        $row_max = 0;
                        foreach($marks as $t => $m) { $row_obt += $m; $row_max += $maxes[$t]; }
                        
                        // Grade Logic
                        $gp = calculate_gp($row_obt, $row_max);
                        $grade = calculate_grade($row_obt, $row_max);
                        
                        $sem_gp_total += $gp;
                        $sem_sub_count++;

                        // Styling
                        $grade_cls = ($grade == 'RA') ? 'badge bg-danger' : 
                                    (($grade == 'O' || $grade == 'A+') ? 'badge bg-success' : 'badge bg-secondary');
                    ?>
                    <tr>
                        <td class="text-start ps-4">
                            <div class="fw-bold text-dark"><?php echo $sub['subject_name']; ?></div>
                            <small class="text-muted"><?php echo $code; ?></small>
                        </td>
                        <td><?php echo $a1; ?></td>
                        <td><?php echo $a2; ?></td>
                        <td><?php echo $a3; ?></td>
                        <td><?php echo $assg; ?></td>
                        <td><span class="fw-bold text-dark"><?php echo $final; ?></span></td>
                        <td class="bg-primary bg-opacity-10 fw-bold text-primary">
                            <?php echo $row_obt; ?>
                        </td>
                        <td><span class="<?php echo $grade_cls; ?>"><?php echo $grade; ?></span> <small class="text-muted">/ 10</small></td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
                <tfoot class="border-top">
                    <?php 
                        $sgpa = $sem_sub_count > 0 ? $sem_gp_total / $sem_sub_count : 0;
                    ?>
                    <tr>
                        <td colspan="7" class="text-end fw-bold py-3">SEMESTER GPA (SGPA):</td>
                        <td class="fw-bold fs-5 text-primary py-3"><?php echo number_format($sgpa, 2); ?> <span class="fs-6 text-muted">/ 10</span></td>
                    </tr>
                </tfoot>
            </table>
        </div>
        <?php else: ?>
            <div class="p-5 text-center text-muted">
                <i class="fas fa-file-excel fa-3x mb-3 opacity-25"></i>
                <p>No subjects enrolled for Semester <?php echo $selected_sem; ?>.</p>
            </div>
        <?php endif; ?>
    </div>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
