<?php
// student/student_dashboard.php - Professional Student Dashboard
require_once '../includes/db_connect.php';
require_once '../includes/year_helpers.php';
check_login(['student']);

$student_id = $_SESSION['profile_id'];
$student_name = $_SESSION['user_name'];

// Fetch Student Data
$s_res = $conn->query("SELECT * FROM students WHERE student_id = $student_id")->fetch_assoc();
$sem = $s_res['semester'];
$dept = $s_res['department'];
// GET ACTIVE SEMESTER START DATE
$active_sem_start = '2025-12-17'; // Fallback
$sem_q = $conn->query("SELECT start_date FROM semester_dates WHERE is_active = 1 LIMIT 1");
if ($sem_q && $sem_q->num_rows > 0) {
    $active_sem_start = $sem_q->fetch_row()[0];
} else {
    // Fallback: Check date range if no active flag
    $today_d = date('Y-m-d');
    $sem_q2 = $conn->query("SELECT start_date FROM semester_dates WHERE '$today_d' BETWEEN start_date AND end_date LIMIT 1");
    if($sem_q2 && $sem_q2->num_rows > 0) $active_sem_start = $sem_q2->fetch_row()[0];
}

// 1. Attendance: Average of Subject-wise Percentages
$att_sql = "SELECT subject_code, 
            COUNT(*) as total_classes, 
            SUM(CASE WHEN status = 'P' THEN 1 ELSE 0 END) as present_classes 
            FROM attendance 
            WHERE student_id = $student_id 
            AND date >= '$active_sem_start' 
            GROUP BY subject_code";
$att_res = $conn->query($att_sql);

$total_att_pct = 0;
$att_sub_count = 0;
while($row = $att_res->fetch_assoc()) {
    if ($row['total_classes'] > 0) {
        $sub_pct = ($row['present_classes'] / $row['total_classes']) * 100;
        $total_att_pct += $sub_pct;
        $att_sub_count++;
    }
}
$att_pct = $att_sub_count > 0 ? round($total_att_pct / $att_sub_count) : 0;

// 2. CGPA: Cumulative (Upto Previous Semester)
$prev_sem_limit = $sem - 1;
// Custom Grade Logic (Synced with Transcript)
function get_dash_gp($marks) {
    if ($marks >= 97) return 10;
    if ($marks >= 91) return 9;
    if ($marks >= 81) return 8;
    if ($marks >= 71) return 7;
    if ($marks >= 61) return 6;
    if ($marks >= 51) return 5;
    if ($marks >= 40) return 4;
    return 0;
}

if ($prev_sem_limit > 0) {
    // Fetch ALL Final Exam scores from Sem 1 to Prev
    $gp_sql = "SELECT sc.marks_obtained, s.credits 
               FROM scores sc 
               JOIN subjects s ON sc.subject_code = s.subject_code 
               WHERE sc.student_id = $student_id 
                 AND sc.assessment_type = 'Final Exam' 
                 AND s.semester <= $prev_sem_limit";
    $cgpa_res = $conn->query($gp_sql);

    $total_weighted_points = 0;
    $total_credits = 0;
    while($row = $cgpa_res->fetch_assoc()) {
        $m = (int)$row['marks_obtained'];
        $cr = isset($row['credits']) ? intval($row['credits']) : 3; // Default 3
        
        $gp = get_dash_gp($m);
        $total_weighted_points += ($gp * $cr);
        $total_credits += $cr;
    }
    $cgpa = $total_credits > 0 ? number_format($total_weighted_points / $total_credits, 2) : "0.00";
    $cgpa_label = "CGPA";
} else {
    $cgpa = "N/A";
    $cgpa_label = "CGPA";
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Portal - Chendhuran SIS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;800&display=swap" rel="stylesheet">
    <link href="../includes/css/styles.css" rel="stylesheet">
</head>
<body>
<?php include '../includes/sidebar.php'; ?>

<main class="main-content">
    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-5">
        <div>
            <h3 class="fw-bold mb-1">Welcome, <?php echo htmlspecialchars($student_name); ?></h3>
            <p class="text-muted mb-0">
                <i class="fas fa-graduation-cap me-1"></i> 
                <?php echo $dept; ?> • <?php echo format_year_semester($sem); ?>
            </p>
        </div>
        <div class="text-end">
            <h4 class="fw-bold mb-0" id="clock">--:--</h4>
            <small class="text-muted"><?php echo date('l, F j, Y'); ?></small>
        </div>
    </div>

    <!-- Quick Stats -->
    <div class="row g-4 mb-5">
        <div class="col-md-4">
            <div class="stat-card d-flex align-items-center">
                <div class="stat-icon bg-blue-soft text-primary me-3" style="background: #eff6ff;">
                    <i class="fas fa-chart-line"></i>
                </div>
                <div>
                    <h6 class="text-muted text-uppercase text-xs fw-bold mb-1"><?php echo $cgpa_label; ?></h6>
                    <h3 class="fw-bold mb-0"><?php echo $cgpa; ?></h3>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="stat-card d-flex align-items-center">
                <div class="stat-icon bg-green-soft text-success me-3" style="background: #ecfdf5;">
                    <i class="fas fa-user-clock"></i>
                </div>
                <div>
                    <h6 class="text-muted text-uppercase text-xs fw-bold mb-1">Attendance</h6>
                    <h3 class="fw-bold mb-0"><?php echo $att_pct; ?>%</h3>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="stat-card d-flex align-items-center">
                <div class="stat-icon bg-purple-soft text-warning me-3" style="background: #fffbeb;">
                    <i class="fas fa-book"></i>
                </div>
                <div>
                    <h6 class="text-muted text-uppercase text-xs fw-bold mb-1">Current Semester</h6>
                    <h3 class="fw-bold mb-0"><?php echo $sem; ?></h3>
                </div>
            </div>
        </div>
    </div>

    <!-- Performance Tracker Section -->
    <div class="row g-4">
        <div class="col-lg-8">
            <div class="glass-card h-100">
                <div class="card-header bg-white border-bottom d-flex justify-content-between align-items-center">
                    <h6 class="fw-bold mb-0 text-primary">Subject Performance (Current Sem)</h6>
                    <span class="badge bg-primary bg-opacity-10 text-primary">Analysis</span>
                </div>
                <div class="card-body">
                    <canvas id="performanceChart" height="150"></canvas>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="glass-card h-100">
                <div class="card-header bg-white border-bottom">
                    <h6 class="fw-bold mb-0 text-primary">Assessment Progress</h6>
                </div>
                <div class="card-body d-flex flex-column justify-content-center">
                    <?php 
                        // Assessment Progress: Total Course Completion (All Semesters)
                        
                        // 1. Total Subjects Passed (Final Exam >= 40) across ALL semesters
                        $pass_sql = "SELECT COUNT(DISTINCT sc.subject_code) 
                                     FROM scores sc 
                                     JOIN subjects s ON sc.subject_code = s.subject_code 
                                     WHERE sc.student_id = $student_id 
                                       AND sc.assessment_type = 'Final Exam' 
                                       AND sc.marks_obtained >= 40";
                        $pass_count = $conn->query($pass_sql)->fetch_row()[0];

                        // 2. Total Subjects Requirement (Dynamic based on Department)
                        $sub_count_sql = "SELECT COUNT(*) FROM subjects WHERE department = '$dept'";
                        $total_sub_enrolled = $conn->query($sub_count_sql)->fetch_row()[0];
                        
                        // Prevent division by zero
                        if ($total_sub_enrolled == 0) $total_sub_enrolled = 1;
                        
                        $progress_pct = round(($pass_count / $total_sub_enrolled) * 100);
                    ?>
                    <div class="text-center mb-4">
                        <h2 class="display-4 fw-bold text-success"><?php echo $progress_pct; ?>%</h2>
                        <p class="text-muted small">Course Completion</p>
                    </div>
                    <div class="progress mb-3" style="height: 10px;">
                        <div class="progress-bar bg-success" role="progressbar" style="width: <?php echo $progress_pct; ?>%"></div>
                    </div>
                     <p class="text-center text-muted small mb-0">You have passed <?php echo $pass_count; ?> out of <?php echo $total_sub_enrolled; ?> subjects.</p>
                </div>
            </div>
        </div>
    </div>

</main>

<?php
// Prepare Data for Chart
// Fetch best score percentage per subject for current semester
$chart_sql = "
    SELECT s.subject_name, MAX((sc.marks_obtained / sc.max_marks) * 100) as pct
    FROM scores sc
    JOIN subjects s ON sc.subject_code = s.subject_code
    WHERE sc.student_id = $student_id AND s.semester = $sem
    GROUP BY s.subject_code
";
$chart_res = $conn->query($chart_sql);
$labels = [];
$data = [];
while($row = $chart_res->fetch_assoc()) {
    $labels[] = $row['subject_name'];
    $data[] = round($row['pct']);
}
?>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    // Clock
    function updateClock() {
        const now = new Date();
        document.getElementById('clock').textContent = now.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
    }
    setInterval(updateClock, 1000);
    updateClock();

    // Chart.js
    const ctx = document.getElementById('performanceChart').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($labels); ?>,
            datasets: [{
                label: 'Performance (%)',
                data: <?php echo json_encode($data); ?>,
                backgroundColor: 'rgba(59, 130, 246, 0.5)',
                borderColor: 'rgba(59, 130, 246, 1)',
                borderWidth: 1,
                borderRadius: 5
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    grid: { borderDash: [2, 2] }
                },
                x: {
                    grid: { display: false }
                }
            },
            plugins: {
                legend: { display: false }
            }
        }
    });
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
