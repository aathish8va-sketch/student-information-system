<?php
// student/attendance_record.php - Student Attendance Calendar
require_once '../includes/db_connect.php';
require_once '../includes/year_helpers.php';
check_login(['student']);

$student_id = $_SESSION['profile_id'];
$student_name = $_SESSION['user_name'];

// Fetch student info
$s_res = $conn->query("SELECT * FROM students WHERE student_id = $student_id")->fetch_assoc();
$sem = $s_res['semester'];
$dept = $s_res['department'];

    // Calculate OVERALL (Current Semester) attendance stats
    // GET ACTIVE SEMESTER START DATE (Dynamic)
    $active_sem_start = '2025-12-17'; // Fallback
    $sem_q = $conn->query("SELECT start_date FROM semester_dates WHERE is_active = 1 LIMIT 1");
    if ($sem_q && $sem_q->num_rows > 0) {
        $active_sem_start = $sem_q->fetch_row()[0];
    } else {
        $today_d = date('Y-m-d');
        $sem_q2 = $conn->query("SELECT start_date FROM semester_dates WHERE '$today_d' BETWEEN start_date AND end_date LIMIT 1");
        if($sem_q2 && $sem_q2->num_rows > 0) $active_sem_start = $sem_q2->fetch_row()[0];
    }

    $overall_query = $conn->prepare("
        SELECT COUNT(*) as total, SUM(CASE WHEN status = 'P' THEN 1 ELSE 0 END) as present
        FROM attendance
        WHERE student_id = ? AND date >= ?
    ");
    $overall_query->bind_param("is", $student_id, $active_sem_start);
    $overall_query->execute();
    $overall_stats = $overall_query->get_result()->fetch_assoc();
    $overall_total = $overall_stats['total'];
    $overall_present = $overall_stats['present'];
    $overall_pct = $overall_total > 0 ? round(($overall_present / $overall_total) * 100, 1) : 0;

    // Fetch Attendance filtered by SEMESTER (via Subject) & DATE RANGE
    $selected_sem = isset($_GET['semester']) ? intval($_GET['semester']) : $sem;
    $date_from = $_GET['date_from'] ?? null;
    $date_to = $_GET['date_to'] ?? null;

    $hist_sql = "
        SELECT a.date, a.subject_code, a.status, s.subject_name
        FROM attendance a
        JOIN subjects s ON a.subject_code = s.subject_code
        WHERE a.student_id = ? 
        AND s.semester = ?";

    $params = [$student_id, $selected_sem];
    $types = "ii";

    if ($date_from && $date_to) {
        $hist_sql .= " AND a.date BETWEEN ? AND ?";
        $params[] = $date_from;
        $params[] = $date_to;
        $types .= "ss";
    }

    $hist_sql .= " ORDER BY a.date DESC";

    $stmt = $conn->prepare($hist_sql);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $res = $stmt->get_result();

    $history_by_month = [];
    while($row = $res->fetch_assoc()) {
        $month_key = date('F Y', strtotime($row['date'])); 
        if (!isset($history_by_month[$month_key])) {
            $history_by_month[$month_key] = [];
        }
        $history_by_month[$month_key][] = $row;
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Attendance Record - Chendhuran SIS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../includes/css/styles.css" rel="stylesheet">
</head>
<body>
<?php include '../includes/sidebar.php'; ?>

<main class="main-content">
    <!-- Header -->
    <div class="glass-header mb-4">
        <h4 class="fw-bold mb-1"><i class="fas fa-calendar-check me-2"></i>My Attendance Record</h4>
        <p class="text-muted mb-0 small">View your day-by-day attendance history</p>
    </div>

    <!-- Overall Stats (Always Shows All-Time Attendance) -->
    <div class="row g-3 mb-4">
        <div class="col-md-4">
            <div class="card border-0 shadow-sm">
                <div class="card-body text-center">
                    <h2 class="fw-bold text-success mb-1"><?php echo $overall_pct; ?>%</h2>
                    <small class="text-muted text-uppercase">Overall Attendance</small>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card border-0 shadow-sm">
                <div class="card-body text-center">
                    <h2 class="fw-bold text-primary mb-1"><?php echo $overall_present; ?></h2>
                    <small class="text-muted text-uppercase">Classes Attended</small>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card border-0 shadow-sm">
                <div class="card-body text-center">
                    <h2 class="fw-bold text-danger mb-1"><?php echo $overall_total - $overall_present; ?></h2>
                    <small class="text-muted text-uppercase">Classes Missed</small>
                </div>
            </div>
        </div>
    </div>

    <!-- Semester Filter -->
    <div class="card border-0 shadow-sm mb-4">
        <div class="card-body py-3">
            <form method="GET" class="row align-items-end">
                <div class="col-md-3">
                    <label class="form-label fw-bold small mb-1">Semester</label>
                    <select name="semester" class="form-select" onchange="this.form.submit()">
                        <?php for($i=1; $i<=6; $i++): ?>
                            <option value="<?php echo $i; ?>" <?php if($i == ($selected_sem ?? $sem)) echo 'selected'; ?>>
                                Semester <?php echo $i; ?>
                            </option>
                        <?php endfor; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-bold small mb-1">From Date</label>
                    <input type="date" name="date_from" class="form-control" value="<?php echo $date_from; ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-bold small mb-1">To Date</label>
                    <input type="date" name="date_to" class="form-control" value="<?php echo $date_to; ?>">
                </div>
                <div class="col-md-3">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-filter me-2"></i>Apply Filter
                    </button>
                </div>
                <!-- Info Badge below -->
                <div class="col-12 mt-3 text-end">
                    <span class="badge bg-light text-dark border">
                        <i class="fas fa-info-circle me-1"></i> 
                        Showing Semester <?php echo ($selected_sem ?? $sem); ?> 
                        <?php if($date_from && $date_to) echo " (" . date('d M', strtotime($date_from)) . " to " . date('d M', strtotime($date_to)) . ")"; ?>
                    </span>
                    <a href="attendance_record.php" class="btn btn-sm btn-link text-muted ms-2">Reset</a>
                </div>
            </form>
        </div>
    </div>
    


    <?php if(empty($history_by_month)): ?>
        <div class="card border-0 shadow-sm">
            <div class="card-body text-center py-5">
                <i class="fas fa-calendar-times fa-3x text-muted mb-3"></i>
                <p class="text-muted">No attendance found for Semester <?php echo $selected_sem; ?>.</p>
            </div>
        </div>
    <?php else: ?>
        <div class="row">
            <div class="col-12">
                <!-- Timeline Style Layout -->
                <?php 
                $month_index = 0;
                foreach($history_by_month as $month => $records): 
                    // Calculate Monthly Stats
                    $m_total = count($records);
                    $m_present = 0;
                    foreach($records as $r) if($r['status'] == 'P') $m_present++;
                    $m_pct = $m_total > 0 ? round(($m_present / $m_total) * 100) : 0;
                    
                    // Collapse ID
                    $cid = 'collapse_' . str_replace(' ', '', $month);
                    
                    // Show first month, collapse others
                    $show_class = ($month_index === 0) ? 'show' : '';
                    $month_index++;
                ?>
                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center" 
                         style="cursor: pointer;" data-bs-toggle="collapse" data-bs-target="#<?php echo $cid; ?>">
                        <div class="d-flex align-items-center">
                            <div class="text-center me-3 border-end pe-3">
                                <h5 class="fw-bold mb-0 text-dark"><?php echo date('M', strtotime($month)); ?></h5>
                                <small class="text-muted"><?php echo date('Y', strtotime($month)); ?></small>
                            </div>
                            <div>
                                <h6 class="fw-bold mb-0 text-primary"><?php echo $month; ?></h6>
                                <small class="text-muted"><?php echo $m_total; ?> Classes Recorded</small>
                            </div>
                        </div>
                        <div class="text-end">
                            <span class="badge <?php echo $m_pct >= 75 ? 'bg-success' : ($m_pct >= 60 ? 'bg-warning' : 'bg-danger'); ?> rounded-pill px-3 py-2">
                                <?php echo $m_pct; ?>% Attendance
                            </span>
                            <i class="fas fa-chevron-down ms-3 text-muted"></i>
                        </div>
                    </div>
                    
                    <div id="<?php echo $cid; ?>" class="collapse <?php echo $show_class; ?>">
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover mb-0 align-middle">
                                    <thead class="bg-light text-muted small text-uppercase">
                                        <tr>
                                            <th class="ps-4">Date</th>
                                            <th>Subject</th>
                                            <th class="text-center">Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach($records as $rec): 
                                            $d_str = date('d M, D', strtotime($rec['date']));
                                        ?>
                                        <tr>
                                            <td class="ps-4 fw-bold text-secondary" style="width: 150px;"><?php echo $d_str; ?></td>
                                            <td>
                                                <span class="fw-bold text-dark"><?php echo htmlspecialchars($rec['subject_name']); ?></span>
                                                <small class="d-block text-muted"><?php echo $rec['subject_code']; ?></small>
                                            </td>
                                            <td class="text-center">
                                                <?php if($rec['status'] == 'P'): ?>
                                                    <span class="badge bg-success bg-opacity-10 text-success border border-success px-3">Present</span>
                                                <?php else: ?>
                                                    <span class="badge bg-danger bg-opacity-10 text-danger border border-danger px-3">Absent</span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endif; ?>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
