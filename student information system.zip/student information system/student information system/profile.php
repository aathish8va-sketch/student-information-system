<?php
// profile.php - User Profile & Settings
require_once 'includes/db_connect.php';
require_once 'includes/year_helpers.php';
// Any logged in user can access
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];
$profile_id = $_SESSION['profile_id'];
$message = '';
$error = '';

// Fetch Details based on role
$name = 'User';
$details = [];

if ($role == 'student') {
    $res = $conn->query("SELECT * FROM students WHERE student_id = $profile_id");
    if($r = $res->fetch_assoc()) {
        $name = $r['name'];
        $year = get_year_from_semester($r['semester']);
        $details = [
            'Roll Number' => $r['roll_number'],
            'Department' => $r['department'],
            'Year' => get_year_label($year),
            'Semester' => $r['semester']
        ];
    }
} elseif ($role == 'teacher') {
    $res = $conn->query("SELECT * FROM teachers WHERE teacher_id = $profile_id");
    if($r = $res->fetch_assoc()) {
        $name = $r['name'];
        $details = [
            'Department' => $r['department']
        ];
    }
} else {
    $name = 'Administrator';
    $details = ['Role' => 'System Admin'];
}

// Handle Password Change
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $new_pass = $_POST['new_password'];
    $confirm_pass = $_POST['confirm_password'];
    
    if (!empty($new_pass)) {
        if ($new_pass === $confirm_pass) {
            $new_hash = password_hash($new_pass, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("UPDATE users SET password_hash = ? WHERE user_id = ?");
            $stmt->bind_param("si", $new_hash, $user_id);
            if ($stmt->execute()) {
                $message = "Password updated successfully.";
            } else {
                $error = "Error updating password.";
            }
        } else {
            $error = "Passwords do not match.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Profile - Chendhuran</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="includes/css/styles.css" rel="stylesheet">
</head>
</head>
<body>
<?php include 'includes/sidebar.php'; ?>

<main class="main-content">
    <div class="glass-header d-flex justify-content-between align-items-center">
        <div>
            <h4 class="fw-bold mb-1">My Account</h4>
            <p class="text-muted mb-0 small">Manage your security settings and view profile details.</p>
        </div>
    </div>

    <?php if($message): ?><div class="alert alert-success shadow-sm"><?php echo $message; ?></div><?php endif; ?>
    <?php if($error): ?><div class="alert alert-danger shadow-sm"><?php echo $error; ?></div><?php endif; ?>

    <div class="row">
        <div class="col-md-6 mb-4">
            <div class="glass-card p-4 h-100">
                <div class="text-center mb-4">
                    <div class="bg-white rounded-circle d-inline-block p-4 shadow-sm mb-3">
                        <i class="fas fa-user fa-4x text-primary"></i>
                    </div>
                    <h3 class="fw-bold"><?php echo escape($name); ?></h3>
                    <span class="badge bg-primary text-uppercase"><?php echo $role; ?></span>
                </div>
                
                <div class="list-group list-group-flush bg-transparent">
                    <div class="list-group-item bg-transparent d-flex justify-content-between px-0">
                        <span class="text-muted">Email</span>
                        <span class="fw-bold"><?php echo $_SESSION['email']; ?></span>
                    </div>
                    <?php foreach($details as $key => $val): ?>
                    <div class="list-group-item bg-transparent d-flex justify-content-between px-0">
                        <span class="text-muted"><?php echo $key; ?></span>
                        <span class="fw-bold"><?php echo escape($val); ?></span>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <div class="col-md-6 mb-4">
            <div class="glass-card p-4 h-100">
                <h4 class="mb-4 fw-bold text-secondary">Security Settings</h4>
                
                <form method="POST">
                    <div class="mb-3">
                        <label class="form-label">New Password</label>
                        <input type="password" name="new_password" class="form-control" required>
                    </div>
                    <div class="mb-4">
                        <label class="form-label">Confirm Password</label>
                        <input type="password" name="confirm_password" class="form-control" required>
                    </div>
                    <button type="submit" class="btn btn-warning w-100 fw-bold text-dark">
                        <i class="fas fa-key me-2"></i> Update Password
                    </button>
                </form>
            </div>
        </div>
    </div>
</main>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
