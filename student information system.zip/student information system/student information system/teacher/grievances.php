<?php
// teacher/grievances.php - Combined Submit and View Teacher Grievances
require_once '../includes/db_connect.php';
check_login(['teacher']);

$teacher_id = $_SESSION['profile_id'];
$teacher_name = $_SESSION['user_name'];

// Fetch teacher info
$t_query = $conn->query("SELECT * FROM teachers WHERE teacher_id = $teacher_id");
$teacher = $t_query->fetch_assoc();

// Check Teacher Role (HOD/Principal/Etc)
$teacher_role = '';
$teacher_dept = '';
if(isset($teacher['teacher_role'])) $teacher_role = $teacher['teacher_role'];
if(isset($teacher['department'])) $teacher_dept = $teacher['department'];

// HOD Logic: Handle Status Update
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_grievance']) && ($teacher_role == 'HOD' || $teacher_role == 'Principal')) {
    $gid = intval($_POST['grievance_id']);
    $status_base = sanitize_input($_POST['status']);
    
    // Append Role to Status for clarity (e.g. "Resolved by HOD")
    if ($status_base == 'Resolved' || $status_base == 'Rejected') {
        $status = $status_base . " by " . $teacher_role;
    } else {
        $status = $status_base;
    }

    $response = sanitize_input($_POST['response']);
    
    // Verify it belongs to HOD's dept (or Principal access)
    $allowed = false;
    if($teacher_role == 'Principal') $allowed = true;
    else {
        // Check if grievance belongs to HOD dept
        $chk = $conn->query("SELECT department FROM grievances WHERE grievance_id=$gid");
        if($chk && $row=$chk->fetch_assoc()) {
            if($row['department'] == $teacher_dept) $allowed = true;
        }
    }

    if($allowed) {
        $stmt = $conn->prepare("UPDATE grievances SET status=?, admin_response=?, resolved_at=NOW(), assigned_to=? WHERE grievance_id=?");
        $resolver_name = "HOD ($teacher_dept)"; 
        
        // We use assigned_to to store WHO resolved it (ID)
        $stmt->bind_param("ssii", $status, $response, $teacher_id, $gid);
        
        if($stmt->execute()) {
            $success = "Grievance #$gid updated successfully.";
            // Clear POST to prevent resubmission
            $_POST = array();
        } else {
            $error = "Failed to update grievance.";
        }
    } else {
        $error = "Unauthorized to update this grievance.";
    }
}


// Alert messages
$success = '';
$error = '';

// Handle form submission for teacher grievances
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_grievance'])) {
    if (!verify_csrf_token($_POST['csrf_token'])) {
        $error = "Invalid request. Please try again.";
    } else {
        $category = sanitize_input($_POST['category']);
        $description = sanitize_input($_POST['description']);
        $topic = sanitize_input($_POST['topic']);
        
        if (empty($category) || empty($description) || empty($topic)) {
            $error = "All fields are required.";
        } else {
            // For teacher submissions, we treat 'department' as their own dept for routing
            $dept = $teacher['department'];
            
            // Schema has subject/description as NOT NULL, so we duplicate data to be safe
            $stmt = $conn->prepare("INSERT INTO grievances (submitter_type, teacher_id, grievance_type, message, description, subject, status, created_at, department) VALUES ('Teacher', ?, ?, ?, ?, ?, 'Pending', NOW(), ?)");
            
            if($stmt === false) {
                $error = "Database error: " . $conn->error;
            } else {
                // Map inputs: topic->subject, description->message&description
                $stmt->bind_param("isssss", $teacher_id, $category, $description, $description, $topic, $dept);
                
                if ($stmt->execute()) {
                    $success = "Your grievance has been submitted successfully.";
                    $_POST = array();
                } else {
                    $error = "Failed to submit grievance: " . $stmt->error;
                }
                $stmt->close();
            }
        }
    }
}

// Filter for MY grievances
$filter = isset($_GET['filter']) ? $_GET['filter'] : 'all';
$where_clause = "g.teacher_id = $teacher_id AND g.submitter_type = 'Teacher'";
if ($filter == 'pending') {
    $where_clause .= " AND g.status = 'Pending'";
} elseif ($filter == 'resolved') {
    $where_clause .= " AND (g.status IN ('Resolved', 'Closed') OR g.status LIKE 'Resolved by%')";
} elseif ($filter == 'rejected') {
    $where_clause .= " AND (g.status LIKE '%Rejected%')";
}

// Fetch MY grievances
$grievances = $conn->query("
    SELECT g.*
    FROM grievances g
    WHERE $where_clause
    ORDER BY g.created_at DESC
");

// ==========================================
// HOD VIEW: Department Grievances Fetch
// ==========================================
$dept_grievances = null;
if ($teacher_role == 'HOD' || $teacher_role == 'Principal') {
    $dept_where = "1=1";
    if($teacher_role == 'HOD') {
        // Fetch grievances TARGETING this department
        $dept_where = "g.department = '$teacher_dept'";
    }
    
    // Fetch pending by default or all? Let's show all for now with filter
    $dept_filter = $_GET['d_filter'] ?? 'Pending';
    // Department View Filter
    if($dept_filter != 'All') {
        if($dept_filter == 'Resolved' || $dept_filter == 'Closed') {
            $dept_where .= " AND (g.status IN ('Resolved', 'Closed') OR g.status LIKE 'Resolved by%')";
        } elseif($dept_filter == 'Rejected') {
            $dept_where .= " AND (g.status LIKE '%Rejected%')";
        } else {
            $dept_where .= " AND g.status='$dept_filter'";
        }
    }
    
    $dept_grievances = $conn->query("
        SELECT g.*, s.name as student_name, s.roll_number, s.department as student_dept,
               t.name as teacher_name
        FROM grievances g
        LEFT JOIN students s ON g.student_id = s.student_id
        LEFT JOIN teachers t ON g.teacher_id = t.teacher_id
        WHERE $dept_where
        ORDER BY g.created_at DESC
    ");
}


function get_status_badge($status) {
    switch($status) {
        case 'Pending': return '<span class="badge bg-warning text-dark">Pending Review</span>';
        case 'In Progress': return '<span class="badge bg-info text-white">In Progress</span>';
        case 'Resolved': return '<span class="badge bg-success">Resolved</span>';
        default: return '<span class="badge bg-danger">Rejected</span>';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Grievances - Chendhuran SIS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;800&display=swap" rel="stylesheet">
    <link href="../includes/css/styles.css" rel="stylesheet">
    <style>
        /* Enhanced Grievance Card Styling */
        .grievance-card-enhanced {
            border-left-width: 5px !important;
            border-left-style: solid !important;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .grievance-card-enhanced:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.15) !important;
        }
        
        /* Filter Button Enhancements */
        .btn-group .btn {
            font-weight: 500;
            transition: all 0.2s;
        }
        .btn-group .btn:hover {
            transform: translateY(-1px);
        }
        
        /* Status Badge Icons */
        .badge i {
            font-size: 0.9em;
        }
        
        /* Better spacing for message content */
        .message-content {
            line-height: 1.7;
            font-size: 0.95rem;
        }
    </style>
</head>
<body>
<?php include '../includes/sidebar.php'; ?>

<main class="main-content">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h3 class="fw-bold mb-1">Grievances</h3>
            <p class="text-muted mb-0">
                <i class="fas fa-user-tie me-1"></i> <?php echo htmlspecialchars($teacher_name); ?>
                <?php if($teacher_role) echo " &bull; <span class='badge bg-primary'>$teacher_role</span>"; ?>
            </p>
        </div>
    </div>

    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="fas fa-check-circle me-2"></i><?php echo $success; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <i class="fas fa-exclamation-circle me-2"></i><?php echo $error; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- TABS for HOD -->
    <?php if($teacher_role == 'HOD' || $teacher_role == 'Principal'): ?>
    <ul class="nav nav-tabs mb-4">
        <li class="nav-item">
            <a class="nav-link <?php echo (!isset($_GET['view']) || $_GET['view']=='dept') ? 'active' : ''; ?>" href="?view=dept">
                <i class="fas fa-inbox me-2"></i>Department Inbox
                <?php if($dept_grievances): ?>
                    <span class="badge bg-danger ms-2"><?php echo $dept_grievances->num_rows; ?></span>
                <?php endif; ?>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo (isset($_GET['view']) && $_GET['view']=='my') ? 'active' : ''; ?>" href="?view=my">
                <i class="fas fa-paper-plane me-2"></i>My Reported Issues
            </a>
        </li>
    </ul>
    <?php endif; ?>


    <!-- VIEW: DEPARTMENT INBOX (HOD ONLY) -->
    <?php if( ($teacher_role == 'HOD' || $teacher_role == 'Principal') && (!isset($_GET['view']) || $_GET['view']=='dept') ): ?>
        
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div class="btn-group" role="group">
                <a href="?view=dept&d_filter=Pending" class="btn <?php echo $dept_filter=='Pending'?'btn-warning':'btn-outline-warning'; ?>">
                    <i class="fas fa-clock me-1"></i> Pending
                    <?php 
                    $pending_count = $conn->query("SELECT COUNT(*) FROM grievances WHERE department='$teacher_dept' AND status='Pending'")->fetch_row()[0];
                    if($pending_count > 0): ?>
                        <span class="badge bg-dark ms-1"><?php echo $pending_count; ?></span>
                    <?php endif; ?>
                </a>
                <a href="?view=dept&d_filter=Resolved" class="btn <?php echo $dept_filter=='Resolved'?'btn-success':'btn-outline-success'; ?>">
                    <i class="fas fa-check-circle me-1"></i> Resolved
                    <?php 
                    $resolved_count = $conn->query("SELECT COUNT(*) FROM grievances WHERE department='$teacher_dept' AND (status IN ('Resolved','Closed') OR status LIKE 'Resolved by%')")->fetch_row()[0];
                    if($resolved_count > 0): ?>
                        <span class="badge bg-dark ms-1"><?php echo $resolved_count; ?></span>
                    <?php endif; ?>
                </a>
                <a href="?view=dept&d_filter=Rejected" class="btn <?php echo $dept_filter=='Rejected'?'btn-danger':'btn-outline-danger'; ?>">
                    <i class="fas fa-times-circle me-1"></i> Rejected
                    <?php 
                    $rejected_count = $conn->query("SELECT COUNT(*) FROM grievances WHERE department='$teacher_dept' AND status LIKE '%Rejected%'")->fetch_row()[0];
                    if($rejected_count > 0): ?>
                        <span class="badge bg-dark ms-1"><?php echo $rejected_count; ?></span>
                    <?php endif; ?>
                </a>
                <a href="?view=dept&d_filter=All" class="btn <?php echo $dept_filter=='All'?'btn-primary':'btn-outline-primary'; ?>">
                    <i class="fas fa-list me-1"></i> All
                </a>
            </div>
        </div>

        <?php if ($dept_grievances && $dept_grievances->num_rows > 0): ?>
            <div class="row">
            <?php while ($dg = $dept_grievances->fetch_assoc()): 
                 // Determine status color and border
                 $status_config = match($dg['status']) {
                    'Pending' => ['color' => 'warning', 'border' => '#F59E0B', 'icon' => 'clock'],
                    'In Progress' => ['color' => 'info', 'border' => '#3B82F6', 'icon' => 'spinner'],
                    'Resolved', 'Closed', 'Resolved by HOD', 'Resolved by Principal' => ['color' => 'success', 'border' => '#10B981', 'icon' => 'check-circle'],
                    'Rejected', 'Rejected by HOD', 'Rejected by Principal' => ['color' => 'danger', 'border' => '#EF4444', 'icon' => 'times-circle'],
                    default => ['color' => 'secondary', 'border' => '#6B7280', 'icon' => 'info-circle']
                };
                $submitter_name = $dg['student_name'] ?? $dg['teacher_name'] ?? 'Unknown';
                $submitter_type = $dg['student_name'] ? 'Student' : 'Staff';
            ?>
                <div class="col-12 mb-3">
                    <div class="card border-0 shadow-sm h-100" style="border-left: 4px solid <?php echo $status_config['border']; ?> !important;">
                        <div class="card-body p-4">
                            <!-- Header Section -->
                            <div class="d-flex justify-content-between align-items-start mb-3">
                                <div class="flex-grow-1">
                                    <div class="d-flex align-items-center gap-2 mb-2">
                                        <span class="badge bg-<?php echo $status_config['color']; ?>">
                                            <i class="fas fa-<?php echo $status_config['icon']; ?> me-1"></i>
                                            <?php echo htmlspecialchars($dg['status'] ?: 'Pending'); ?>
                                        </span>
                                        <span class="badge bg-light text-dark border">
                                            <?php echo htmlspecialchars($dg['grievance_type'] ?: 'General'); ?>
                                        </span>
                                    </div>
                                    <h6 class="fw-bold mb-0">
                                        <?php echo htmlspecialchars($dg['subject'] ?: 'No Subject'); ?>
                                    </h6>
                                </div>
                                
                                <!-- Action Button -->
                                <div>
                                    <?php if($dg['status'] == 'Pending' || $dg['status'] == 'In Progress'): ?>
                                        <button class="btn btn-primary btn-sm" data-bs-toggle="collapse" data-bs-target="#resolveBox<?php echo $dg['grievance_id']; ?>">
                                            <i class="fas fa-gavel me-1"></i> Take Action
                                        </button>
                                    <?php else: ?>
                                        <span class="badge bg-light text-muted border px-3 py-2">
                                            <i class="fas fa-check me-1"></i> Closed
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <!-- Submitter Info -->
                            <div class="d-flex align-items-center gap-2 mb-3 text-muted small">
                                <i class="fas fa-user-circle"></i>
                                <strong><?php echo htmlspecialchars($submitter_name); ?></strong>
                                <span class="badge bg-light text-dark"><?php echo $submitter_type; ?></span>
                                <span>•</span>
                                <i class="fas fa-calendar-alt"></i>
                                <span><?php echo date('M d, Y • h:i A', strtotime($dg['created_at'])); ?></span>
                            </div>

                            <!-- Message Section -->
                            <div class="bg-light rounded p-3 mb-3">
                                <p class="mb-0" style="white-space: pre-wrap; line-height: 1.6;">
                                    <?php echo htmlspecialchars($dg['description'] ?? $dg['message'] ?? 'No description provided'); ?>
                                </p>
                            </div>

                            <!-- Admin Response (if exists) -->
                            <?php if(!empty($dg['admin_response'])): ?>
                            <div class="alert alert-info mb-3">
                                <div class="d-flex gap-2">
                                    <i class="fas fa-reply"></i>
                                    <div>
                                        <strong>HOD Response:</strong>
                                        <p class="mb-0 mt-1"><?php echo htmlspecialchars($dg['admin_response']); ?></p>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>

                            <!-- Resolution Form -->
                            <div class="collapse mt-3" id="resolveBox<?php echo $dg['grievance_id']; ?>">
                                <div class="border-top pt-3">
                                    <form method="POST" class="needs-validation" novalidate>
                                        <input type="hidden" name="grievance_id" value="<?php echo $dg['grievance_id']; ?>">
                                        
                                        <div class="row g-3">
                                            <!-- Quick Action Buttons -->
                                            <div class="col-12">
                                                <label class="form-label fw-bold">
                                                    <i class="fas fa-gavel me-1"></i> Decision
                                                </label>
                                                <div class="btn-group w-100" role="group">
                                                    <input type="radio" class="btn-check" name="status" id="resolve<?php echo $dg['grievance_id']; ?>" value="Resolved" required>
                                                    <label class="btn btn-outline-success" for="resolve<?php echo $dg['grievance_id']; ?>">
                                                        <i class="fas fa-check-circle me-1"></i> Resolve
                                                    </label>
                                                    
                                                    <input type="radio" class="btn-check" name="status" id="reject<?php echo $dg['grievance_id']; ?>" value="Rejected" required>
                                                    <label class="btn btn-outline-danger" for="reject<?php echo $dg['grievance_id']; ?>">
                                                        <i class="fas fa-times-circle me-1"></i> Reject
                                                    </label>
                                                </div>
                                            </div>

                                            <!-- Response Textarea -->
                                            <div class="col-12">
                                                <label for="response<?php echo $dg['grievance_id']; ?>" class="form-label fw-bold">
                                                    <i class="fas fa-comment-dots me-1"></i> Your Response
                                                </label>
                                                <textarea 
                                                    class="form-control" 
                                                    id="response<?php echo $dg['grievance_id']; ?>" 
                                                    name="response" 
                                                    rows="3" 
                                                    placeholder="Provide your remarks and reasoning..."
                                                    required
                                                ></textarea>
                                                <div class="form-text">
                                                    <i class="fas fa-info-circle"></i> This response will be visible to the submitter
                                                </div>
                                            </div>

                                            <!-- Action Buttons -->
                                            <div class="col-12">
                                                <div class="d-flex gap-2 justify-content-end">
                                                    <button type="button" class="btn btn-light" data-bs-toggle="collapse" data-bs-target="#resolveBox<?php echo $dg['grievance_id']; ?>">
                                                        <i class="fas fa-times me-1"></i> Cancel
                                                    </button>
                                                    <button type="submit" class="btn btn-primary">
                                                        <i class="fas fa-paper-plane me-1"></i> Submit Decision
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            
                            <!-- Show Response if Resolved -->
                            <?php if(!empty($dg['admin_response'])): ?>
                                <div class="mt-3 border-top pt-2">
                                    <small class="text-muted fw-bold">Response:</small>
                                    <p class="mb-0 text-sm text-dark"><?php echo htmlspecialchars($dg['admin_response']); ?></p>
                                </div>
                            <?php endif; ?>

                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
            </div>
        <?php else: ?>
            <div class="text-center py-5 text-muted">
                <i class="fas fa-check-circle fa-3x mb-3 text-light"></i>
                <p>No grievances found in this filter.</p>
            </div>
        <?php endif; ?>

    <?php endif; ?>


    <!-- VIEW: MY SUBMISSIONS (Default for Teachers, Tab 2 for HOD with 'view=my') -->
    <?php if( (!isset($_GET['view']) && $teacher_role != 'HOD' && $teacher_role != 'Principal') || (isset($_GET['view']) && $_GET['view']=='my') ): ?>

    <!-- Submission Form -->
    <div class="glass-card p-4 mb-4">
        <h5 class="fw-bold mb-3"><i class="fas fa-edit me-2 text-primary"></i> Submit New Grievance</h5>
        <form method="POST" action="">
            <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
            
            <div class="row g-3">
                <!-- 1. Category -->
                <div class="col-md-6">
                    <label class="form-label fw-semibold">Grievance Category</label>
                    <select name="category" class="form-select" required>
                        <option value="">Select category</option>
                        <option value="Infrastructure">Infrastructure</option>
                        <option value="Workload">Workload</option>
                        <option value="Administration">Administration</option>
                        <option value="Facilities">Facilities</option>
                        <option value="Salary">Salary / Benefits</option>
                        <option value="Other">Other</option>
                    </select>
                </div>

                <!-- 2. Subject/Topic -->
                <div class="col-md-6">
                    <label class="form-label fw-semibold">Subject / Topic</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-heading"></i></span>
                        <input type="text" name="topic" class="form-control" placeholder="e.g. Broken AC in Lab 1" required>
                    </div>
                </div>

                <!-- 3. Details -->
                <div class="col-md-12">
                    <label class="form-label fw-semibold">Description</label>
                    <textarea name="description" class="form-control" rows="4" placeholder="Describe your grievance in detail..." required></textarea>
                </div>
            </div>
            
            <div class="mt-3 text-end">
                <button type="submit" name="submit_grievance" class="btn btn-primary px-4">
                    <i class="fas fa-paper-plane me-2"></i> Submit Grievance
                </button>
            </div>
        </form>
    </div>

    <!-- My Past Grievances Table -->
    <div class="mt-4">
        <h5 class="mb-3 fw-bold">My Past Grievances</h5>
        <div class="card border-0 shadow-sm overflow-hidden">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light text-secondary text-uppercase text-xs fw-bold">
                        <tr>
                            <th class="ps-4">Date</th>
                            <th>Subject / Topic</th>
                            <th style="width: 40%;">Message</th>
                            <th>Status</th>
                            <th>Response</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($grievances && $grievances->num_rows > 0): ?>
                            <?php while ($grv = $grievances->fetch_assoc()): 
                                $status = !empty($grv['status']) ? $grv['status'] : 'Pending';
                                $statusColor = match($status) {
                                    'Pending' => 'bg-warning text-dark',
                                    'Resolved', 'Closed', 'Resolved by HOD', 'Resolved by Principal' => 'bg-success',
                                    'Rejected', 'Rejected by HOD', 'Rejected by Principal' => 'bg-danger',
                                    'In Progress' => 'bg-info',
                                    default => 'bg-secondary'
                                };
                            ?>
                            <tr>
                                <td class="ps-4 text-nowrap"><?php echo date('d M Y', strtotime($grv['created_at'])); ?></td>
                                <td class="fw-medium"><?php echo htmlspecialchars($grv['subject'] ?: 'General'); ?></td>
                                <td>
                                    <div class="text-wrap" style="max-height: 60px; overflow-y: auto; font-size: 0.9em;">
                                        <?php echo htmlspecialchars($grv['message']); ?>
                                    </div>
                                </td>
                                <td><span class="badge <?php echo $statusColor; ?>"><?php echo htmlspecialchars($status); ?></span></td>
                                <td class="small text-muted" style="max-width: 200px;">
                                    <?php echo $grv['admin_response'] ? htmlspecialchars($grv['admin_response']) : '-'; ?>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center py-4 text-muted">
                                    <i class="fas fa-check-circle fa-2x mb-2 d-block text-light"></i>
                                    No grievances found.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <?php endif; // End My Submissions View ?>

</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
setTimeout(() => document.querySelectorAll('.alert').forEach(a => new bootstrap.Alert(a).close()), 3000);
</script>
</body>
</html>
