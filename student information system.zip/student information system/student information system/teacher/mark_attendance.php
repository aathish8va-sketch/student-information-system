<?php
// mark_attendance.php
require_once '../includes/db_connect.php';
require_once '../includes/year_helpers.php';
check_login(['teacher']);

$teacher_id = $_SESSION['profile_id'];
$message = '';

// Handle Submit
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['save_attendance'])) {
    $subject_code = sanitize_input($_POST['subject_code']);
    $date = sanitize_input($_POST['date']);
    
    // VALIDATION: Academic Calendar Checks
    // 1. Future Date
    if (strtotime($date) > strtotime(date('Y-m-d'))) {
        $message = "<div class='alert alert-danger'>Error: Cannot mark attendance for future dates.</div>";
    } 
    // 2. Check within Active Semester (Improved: Check within specific Semester Dates)
    else {
        $period_check = $conn->query("SELECT * FROM semester_dates WHERE '$date' BETWEEN start_date AND end_date LIMIT 1");
    // Fallback to Academic Years if Semesters not defined? No, stick to new system logic if populated.
    // If table empty, maybe fallback. But we populated it.
    if ($period_check->num_rows === 0) {
        // Fallback check against Academic Year just in case, but warn
        $ac_check = $conn->query("SELECT * FROM academic_years WHERE '$date' BETWEEN start_date AND end_date LIMIT 1");
        if ($ac_check->num_rows === 0) {
             $message = "<div class='alert alert-danger'><strong>Blocked:</strong> The selected date falls outside any configured Academic Year/Semester.</div>";
        } else {
             $message = "<div class='alert alert-warning'><strong>Warning:</strong> Date is in Academic Year but outside defined Semester terms (Break?). Attendance blocked.</div>";
        }
    }
        else {
            // 3. Check for Holiday
            $holiday_check = $conn->query("SELECT * FROM academic_holidays WHERE holiday_date = '$date' LIMIT 1");
            if($holiday_check->num_rows > 0) {
                 $h_info = $holiday_check->fetch_assoc();
                 $message = "<div class='alert alert-warning'><strong>Holiday:</strong> Cannot mark attendance on this date ({$h_info['description']}).</div>";
            }
            // 4. Check for Sunday (Optional but requested strict working days)
            elseif (date('N', strtotime($date)) == 7) {
                 $message = "<div class='alert alert-warning'><strong>Sunday:</strong> Attendance cannot be marked on Sundays.</div>";
            }
            else {
                // Valid Date - Proceed
                $status_array = $_POST['status'] ?? [];
                // ... (Existing Save Logic)
                $count = 0;
                foreach ($status_array as $stu_id => $status) {
                    $stu_id = intval($stu_id);
                    $status = sanitize_input($status);
                    
                    // Upsert Attendance
                    $sql = "INSERT INTO attendance (student_id, subject_code, date, status) 
                            VALUES ($stu_id, '$subject_code', '$date', '$status')
                            ON DUPLICATE KEY UPDATE status='$status'";
                    
                    if ($conn->query($sql)) $count++;
                }
                $message = "<div class='alert alert-success'>Attendance saved for $count students on $date.</div>";
            }
        }
    }
}
elseif ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Fallback
}

// Get Teacher's Subjects (Filtered by Active Semester)
// Determine Active Semesters based on Academic Calendar
$active_sems = [];
$sem_chk = $conn->query("SELECT period_name FROM semester_dates WHERE is_active = 1 LIMIT 1");
if ($sem_chk && $sem_chk->num_rows > 0) {
    $p_name = $sem_chk->fetch_row()[0];
    if (stripos($p_name, 'Even') !== false) $active_sems = [2, 4, 6];
    else $active_sems = [1, 3, 5];
} else {
    $month = date('n');
    if ($month <= 5 || $month == 12) $active_sems = [2, 4, 6];
    else $active_sems = [1, 3, 5];
}
$sem_list = implode(',', $active_sems);

$subjects = $conn->query("SELECT * FROM subjects WHERE (assigned_teacher_id = $teacher_id OR teacher_id = $teacher_id) AND semester IN ($sem_list)");

// Get Users if Subject Selected
$students = [];
// Smart Date Default: If today is Sunday or Holiday, default to last working day
$default_date = date('Y-m-d');
// Check if today is Sunday (7) or Holiday
$check_h = $conn->query("SELECT * FROM academic_holidays WHERE holiday_date = '$default_date'");
if (date('N', strtotime($default_date)) == 7 || $check_h->num_rows > 0) {
    // Look back up to 5 days
    for ($i = 1; $i <= 5; $i++) {
        $prev = date('Y-m-d', strtotime("-$i days"));
        $is_sun = (date('N', strtotime($prev)) == 7);
        $is_hol = $conn->query("SELECT * FROM academic_holidays WHERE holiday_date = '$prev'")->num_rows > 0;
        
        if (!$is_sun && !$is_hol) {
            $default_date = $prev;
            break;
        }
    }
}

$selected_subject = $_GET['subject'] ?? '';
$selected_date = $_GET['date'] ?? $default_date;

if ($selected_subject) {
    // Determine Department and Semester from Subject
    $sub_details = $conn->query("SELECT * FROM subjects WHERE subject_code = '$selected_subject'")->fetch_assoc();
    if ($sub_details) {
        $dept = $sub_details['department'];
        $sem = $sub_details['semester'];
        
        // Fetch Students
        $students = $conn->query("SELECT * FROM students WHERE department = '$dept' AND semester = $sem ORDER BY roll_number ASC");
    }
}

// Fetch Approved Leaves for Auto-fill
$leave_map = [];
if ($selected_date) {
    $l_query = $conn->query("SELECT student_id, request_type FROM leave_requests WHERE status='Approved' AND '$selected_date' BETWEEN from_date AND to_date");
    if ($l_query) {
        while($l = $l_query->fetch_assoc()) {
            $leave_map[$l['student_id']] = $l['request_type'];
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Mark Attendance - Chendhuran SIS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../includes/css/styles.css" rel="stylesheet">
</head>
<body>
<?php include '../includes/sidebar.php'; ?>

<main class="main-content">
            <div class="glass-header">
                <h4 class="fw-bold mb-1">Mark Daily Attendance</h4>
                <p class="text-muted mb-0 small">Record student attendance for today.</p>
            </div>
            
            <?php echo $message; ?>

            <div class="glass-card p-4 mb-4">
                <form method="GET" class="row g-3">
                    <div class="col-md-5">
                        <label class="form-label">Select Subject</label>
                        <select name="subject" class="form-select" onchange="this.form.submit()" required>
                            <option value="">-- Select --</option>
                            <?php 
                            if ($subjects->num_rows > 0):
                                $subjects->data_seek(0);
                                while($sub = $subjects->fetch_assoc()): 
                            ?>
                                <option value="<?php echo $sub['subject_code']; ?>" <?php if($selected_subject == $sub['subject_code']) echo 'selected'; ?>>
                                    <?php echo htmlspecialchars($sub['subject_name']); ?> (<?php echo $sub['subject_code']; ?>)
                                </option>
                            <?php 
                                endwhile; 
                            else:
                            ?>
                                <option value="" disabled>No subjects for active semester</option>
                            <?php endif; ?>
                        </select>
                    </div>
                    <div class="col-md-5">
                        <label class="form-label">Date</label>
                        <input type="date" name="date" class="form-control" value="<?php echo $selected_date; ?>" max="<?php echo date('Y-m-d'); ?>" onchange="this.form.submit()">
                    </div>
                    <div class="col-md-2 d-flex align-items-end">
                        <button type="submit" class="btn btn-primary w-100">Load</button>
                    </div>
                </form>
            </div>

            <?php if ($selected_subject && $students->num_rows > 0): ?>
            <div class="glass-card p-4">
                <form method="POST">
                    <input type="hidden" name="subject_code" value="<?php echo $selected_subject; ?>">
                    <input type="hidden" name="date" value="<?php echo $selected_date; ?>">
                    
                    <div class="d-flex justify-content-between mb-3">
                        <h5 class="fw-bold">Student List</h5>
                        <div>
                            <button type="button" class="btn btn-sm btn-success me-2" onclick="setAll('P')">All Present</button>
                            <button type="button" class="btn btn-sm btn-danger" onclick="setAll('A')">All Absent</button>
                        </div>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>Roll No</th>
                                    <th>Name</th>
                                    <th class="text-center">Present</th>
                                    <th class="text-center">Absent</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                while($stu = $students->fetch_assoc()): 
                                    // Check existing status logic if needed (not implemented for simplicity, always default P or null)
                                    // To make it better, we should fetch existing attendance for this date
                                    $existing_status = ''; 
                                    // Querying inside loop is bad practice for large sets, but fine for class size ~60
                                    $check = $conn->query("SELECT status FROM attendance WHERE student_id={$stu['student_id']} AND subject_code='$selected_subject' AND date='$selected_date'");
                                    if($check->num_rows > 0) $existing_status = $check->fetch_assoc()['status'];
                                    else $existing_status = 'P'; // Default

                                    // Auto-check logic
                                    $leave_type = $leave_map[$stu['student_id']] ?? null;
                                    
                                    // If no existing record in DB, use auto-logic
                                    if ($existing_status == 'P' && $check->num_rows == 0) {
                                         if ($leave_type == 'On-Duty') {
                                             $existing_status = 'P'; // OD counts as Present
                                         } elseif ($leave_type) {
                                             $existing_status = 'A'; // Other leaves count as Absent
                                         }
                                    }
                                ?>
                                <tr>
                                    <td><?php echo $stu['roll_number']; ?></td>
                                    <td>
                                        <?php echo $stu['name']; ?>
                                        <?php if($leave_type): ?>
                                            <span class="badge bg-<?php echo ($leave_type == 'On-Duty') ? 'info' : 'warning'; ?> ms-2">
                                                <?php echo ($leave_type == 'On-Duty') ? 'On Duty' : 'On Leave'; ?>
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center">
                                        <input type="radio" class="btn-check status-p" name="status[<?php echo $stu['student_id']; ?>]" id="p_<?php echo $stu['student_id']; ?>" value="P" <?php if($existing_status=='P') echo 'checked'; ?>>
                                        <label class="btn btn-outline-success btn-sm" for="p_<?php echo $stu['student_id']; ?>">P</label>
                                    </td>
                                    <td class="text-center">
                                        <input type="radio" class="btn-check status-a" name="status[<?php echo $stu['student_id']; ?>]" id="a_<?php echo $stu['student_id']; ?>" value="A" <?php if($existing_status=='A') echo 'checked'; ?>>
                                        <label class="btn btn-outline-danger btn-sm" for="a_<?php echo $stu['student_id']; ?>">A</label>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <div class="text-end mt-3">
                        <button type="submit" name="save_attendance" class="btn btn-primary px-5">Save Attendance</button>
                    </div>
                </form>
            </div>
            <?php elseif($selected_subject): ?>
                <div class="alert alert-warning">No students found for this subject's department/semester.</div>
            <?php endif; ?>

        </main>

<script>
function setAll(status) {
    let radios = document.querySelectorAll('.status-' + status.toLowerCase());
    radios.forEach(r => r.checked = true);
}
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
