<?php
// teacher/my_teacher_leaves.php - View Teacher's Own Leave Requests
require_once '../includes/db_connect.php';
check_login(['teacher']);

$teacher_id = $_SESSION['profile_id'];
$teacher_name = $_SESSION['user_name'];

// Fetch teacher info
$t_query = $conn->query("SELECT * FROM teachers WHERE teacher_id = $teacher_id");
$teacher = $t_query->fetch_assoc();

// Filter
$filter = isset($_GET['filter']) ? $_GET['filter'] : 'all';

// Build query
$where_clause = "lr.teacher_id = $teacher_id AND lr.applicant_type = 'Teacher'";
if ($filter == 'pending') {
    $where_clause .= " AND lr.status = 'Pending'";
} elseif ($filter == 'approved') {
    $where_clause .= " AND (lr.status = 'Approved by HOD' OR lr.status = 'Approved by Principal')";
} elseif ($filter == 'rejected') {
    $where_clause .= " AND  (lr.status LIKE '%Rejected%')";
}

// Fetch requests
$requests_query = "
    SELECT lr.*, 
           t1.name as hod_name,
           t2.name as principal_name
    FROM leave_requests lr
    LEFT JOIN teachers t1 ON lr.hod_id = t1.teacher_id
    LEFT JOIN teachers t2 ON lr.principal_id = t2.teacher_id
    WHERE $where_clause
    ORDER BY lr.submitted_at DESC
";
$requests = $conn->query($requests_query);

// Helper functions
function get_status_badge($status) {
    switch($status) {
        case 'Pending':
            return '<span class="badge bg-warning text-dark"><i class="fas fa-clock me-1"></i> Pending Review</span>';
        case 'Approved by HOD':
            return '<span class="badge bg-primary"><i class="fas fa-check me-1"></i> Approved by HOD - Pending Principal</span>';
        case 'Approved by Principal':
            return '<span class="badge bg-success"><i class="fas fa-check-double me-1"></i> Fully Approved</span>';
        case 'Rejected by HOD':
        case 'Rejected by Principal':
            return '<span class="badge bg-danger"><i class="fas fa-times-circle me-1"></i> Rejected</span>';
        default:
            return '<span class="badge bg-secondary">' . $status . '</span>';
    }
}

function get_request_icon($type) {
    switch($type) {
        case 'Medical Leave': return '<i class="fas fa-clinic-medical text-danger"></i>';
        case 'Personal Leave': return '<i class="fas fa-user-clock text-primary"></i>';
        case 'On-Duty': return '<i class="fas fa-briefcase text-success"></i>';
        default: return '<i class="fas fa-file"></i>';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Leave Requests - Chendhuran SIS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;800&display=swap" rel="stylesheet">
    <link href="../includes/css/styles.css" rel="stylesheet">
</head>
<body>
<?php include '../includes/sidebar.php'; ?>

<main class="main-content">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h3 class="fw-bold mb-1">My Leave Requests</h3>
            <p class="text-muted mb-0">
                <i class="fas fa-user me-1"></i> <?php echo htmlspecialchars($teacher_name); ?>
            </p>
        </div>
        <a href="apply_teacher_leave.php" class="btn btn-primary">
            <i class="fas fa-plus-circle me-2"></i> New Request
        </a>
    </div>

    <!-- Filter Tabs -->
    <div class="card border-0 shadow-sm mb-4">
        <div class="card-body p-0">
            <ul class="nav nav-pills p-3" role="tablist">
                <li class="nav-item">
                    <a class="nav-link <?php echo $filter == 'all' ? 'active' : ''; ?>" href="?filter=all">
                        All Requests
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo $filter == 'pending' ? 'active' : ''; ?>" href="?filter=pending">
                        Pending
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo $filter == 'approved' ? 'active' : ''; ?>" href="?filter=approved">
                        Approved
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo $filter == 'rejected' ? 'active' : ''; ?>" href="?filter=rejected">
                        Rejected
                    </a>
                </li>
            </ul>
        </div>
    </div>

    <!-- Requests List -->
    <?php if ($requests && $requests->num_rows > 0): ?>
        <?php while ($req = $requests->fetch_assoc()): ?>
            <div class="card border-0 shadow-sm mb-3">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-8">
                            <div class="d-flex align-items-start mb-2">
                                <div class="me-3 fs-3">
                                    <?php echo get_request_icon($req['request_type']); ?>
                                </div>
                                <div class="flex-grow-1">
                                    <h6 class="fw-bold mb-1"><?php echo htmlspecialchars($req['request_type']); ?></h6>
                                    <p class="text-muted small mb-2">
                                        <i class="fas fa-calendar me-1"></i>
                                        <?php echo date('M d, Y', strtotime($req['from_date'])); ?> - 
                                        <?php echo date('M d, Y', strtotime($req['to_date'])); ?>
                                        <?php 
                                        $days = (strtotime($req['to_date']) - strtotime($req['from_date'])) / (60 * 60 * 24) + 1;
                                        echo "(" . $days . " day" . ($days > 1 ? "s" : "") . ")";
                                        ?>
                                    </p>
                                    <p class="mb-0"><strong>Reason:</strong> <?php echo htmlspecialchars($req['reason']); ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 text-md-end">
                            <div class="mb-2">
                                <?php echo get_status_badge($req['status']); ?>
                            </div>
                            <small class="text-muted">
                                <i class="fas fa-clock me-1"></i>
                                Submitted: <?php echo date('M d, Y', strtotime($req['submitted_at'])); ?>
                            </small>
                            <br>
                            <button class="btn btn-sm btn-outline-primary mt-2" 
                                    data-bs-toggle="collapse" 
                                    data-bs-target="#timeline-<?php echo $req['request_id']; ?>">
                                <i class="fas fa-eye me-1"></i> View Details
                            </button>
                        </div>
                    </div>

                    <!-- Timeline (Collapsible) -->
                    <div class="collapse mt-3" id="timeline-<?php echo $req['request_id']; ?>">
                        <hr>
                        <h6 class="fw-bold mb-3">Approval Timeline</h6>
                        
                        <div class="mb-3">
                            <i class="fas fa-check-circle text-success me-2"></i>
                            <strong>Submitted</strong>
                            <p class="text-muted small mb-0 ms-4">
                                <?php echo date('M d, Y h:i A', strtotime($req['submitted_at'])); ?>
                            </p>
                        </div>
                        
                        <?php if ($req['hod_id']): ?>
                            <div class="mb-3">
                                <i class="fas fa-<?php echo strpos($req['status'], 'Rejected') ? 'times-circle text-danger' : 'check-circle text-success'; ?> me-2"></i>
                                <strong>HOD Review</strong>
                                <p class="text-muted small mb-1 ms-4">
                                    Reviewed by <?php echo htmlspecialchars($req['hod_name']); ?> on 
                                    <?php echo date('M d, Y h:i A', strtotime($req['hod_reviewed_at'])); ?>
                                </p>
                                <?php if ($req['hod_comments']): ?>
                                    <div class="alert alert-<?php echo $req['status'] == 'Rejected by HOD' ? 'danger' : 'info'; ?> alert-sm ms-4 mb-0">
                                        <strong>Comments:</strong> <?php echo htmlspecialchars($req['hod_comments']); ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php else: ?>
                            <div class="mb-3">
                                <i class="fas fa-clock text-warning me-2"></i>
                                <strong>HOD Review</strong>
                                <p class="text-muted small mb-0 ms-4">Pending HOD approval...</p>
                            </div>
                        <?php endif; ?>
                        
                        <?php if ($req['status'] != 'Rejected by HOD'): ?>
                            <?php if ($req['principal_id']): ?>
                                <div class="mb-3">
                                    <i class="fas fa-<?php echo $req['status'] == 'Rejected by Principal' ? 'times-circle text-danger' : 'check-circle text-success'; ?> me-2"></i>
                                    <strong>Principal Final Review</strong>
                                    <p class="text-muted small mb-1 ms-4">
                                        Reviewed on <?php echo date('M d, Y h:i A', strtotime($req['principal_reviewed_at'])); ?>
                                    </p>
                                    <?php if ($req['principal_comments']): ?>
                                        <div class="alert alert-<?php echo $req['status'] == 'Rejected by Principal' ? 'danger' : 'success'; ?> alert-sm ms-4 mb-0">
                                            <strong>Comments:</strong> <?php echo htmlspecialchars($req['principal_comments']); ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            <?php else: ?>
                                <div class="mb-3">
                                    <i class="fas fa-clock text-warning me-2"></i>
                                    <strong>Principal Final Review</strong>
                                    <p class="text-muted small mb-0 ms-4">
                                        <?php echo $req['status'] == 'Approved by HOD' ? 'Pending Principal approval...' : 'Pending HOD approval first'; ?>
                                    </p>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>
    <?php else: ?>
        <div class="card border-0 shadow-sm">
            <div class="card-body text-center py-5">
                <i class="fas fa-inbox fa-4x text-muted mb-3"></i>
                <h5 class="text-muted">No leave requests found</h5>
                <p class="text-muted">You haven't submitted any leave requests yet.</p>
                <a href="apply_teacher_leave.php" class="btn btn-primary mt-3">
                    <i class="fas fa-plus-circle me-2"></i> Submit Your First Request
                </a>
            </div>
        </div>
    <?php endif; ?>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
