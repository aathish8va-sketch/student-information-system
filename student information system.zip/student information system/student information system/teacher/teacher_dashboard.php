<?php
// teacher/teacher_dashboard.php - Professional Teacher Dashboard
require_once '../includes/db_connect.php';
check_login(['teacher']);

// Set timezone to IST
date_default_timezone_set('Asia/Kolkata');

$teacher_id = $_SESSION['profile_id'];
$teacher_name = $_SESSION['user_name'];

// Fetch Stats
// 1. My Subjects count
$t_res = $conn->query("SELECT department FROM teachers WHERE teacher_id=$teacher_id");
$dept = ($t_res && $t_res->num_rows > 0) ? $t_res->fetch_assoc()['department'] : 'General';

// Count my assigned subjects
$my_subjects_count_query = $conn->query("SELECT COUNT(*) FROM subjects WHERE assigned_teacher_id=$teacher_id OR teacher_id=$teacher_id");
$my_subjects_count = $my_subjects_count_query ? $my_subjects_count_query->fetch_row()[0] : 0;

// 2. Pending Grievances (Targeted to Me)
$t_role_query = $conn->query("SELECT teacher_role FROM teachers WHERE teacher_id=$teacher_id");
$t_role = ($t_role_query && $t_role_query->num_rows > 0) ? $t_role_query->fetch_assoc()['teacher_role'] : 'Teacher';

$conditions = ["assigned_to = '$teacher_name'"]; // Direct assignments
if ($t_role == 'HOD') {
    // HOD sees all grievances for their department
    $conditions[] = "department = '$dept'";
}
if ($t_role == 'Principal') {
    // Principal sees all
    $conditions[] = "1=1";
}
$where_cond = implode(' OR ', $conditions);

$pg_res = $conn->query("SELECT COUNT(*) FROM grievances WHERE status='Pending' AND ($where_cond)");
$pending_g = $pg_res ? $pg_res->fetch_row()[0] : 0;

// 3. Attendance Taken Today?
$ac_res = $conn->query("SELECT COUNT(DISTINCT date) FROM attendance WHERE date=CURRENT_DATE AND student_id IN (SELECT student_id FROM students WHERE department='$dept')");
$att_check = $ac_res ? $ac_res->fetch_row()[0] : 0;
$att_status = $att_check > 0 ? "Completed" : "Pending";

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Faculty Dashboard - Chendhuran SIS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;800&display=swap" rel="stylesheet">
    <link href="../includes/css/styles.css" rel="stylesheet">
</head>
<body>
<?php include '../includes/sidebar.php'; ?>

<main class="main-content">
    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-5">
        <div>
            <h2 class="fw-bold text-dark mb-1">Faculty Overview</h2>
            <p class="text-muted mb-0">Welcome, <?php echo $teacher_name; ?> (Department of <?php echo $dept; ?>)</p>
        </div>
        <div class="text-end">
            <h4 class="fw-bold mb-0" id="clock">--:--</h4>
            <small class="text-muted"><?php echo date('l, F j, Y'); ?></small>
        </div>
    </div>

    <!-- Stats Cards -->
    <div class="row g-4 mb-5">
        <div class="col-md-4">
            <div class="stat-card d-flex align-items-center">
                <div class="stat-icon bg-blue-soft text-primary me-3" style="background: #eff6ff;">
                    <i class="fas fa-book-open"></i>
                </div>
                <div>
                    <h6 class="text-muted text-uppercase text-xs fw-bold mb-1">My Subjects</h6>
                    <h3 class="fw-bold mb-0"><?php echo $my_subjects_count; ?></h3>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="stat-card d-flex align-items-center">
                <div class="stat-icon bg-green-soft text-success me-3" style="background: #ecfdf5;">
                    <i class="fas fa-calendar-check"></i>
                </div>
                <div>
                    <h6 class="text-muted text-uppercase text-xs fw-bold mb-1">Today's Attendance</h6>
                    <h3 class="fw-bold mb-0 <?php echo $att_status=='Completed'?'text-success':'text-warning'; ?>"><?php echo $att_status; ?></h3>
                </div>
            </div>
        </div>
        <?php if ($t_role == 'HOD' || $t_role == 'Principal'): ?>
        <!-- For HOD/Principal: Department Grievances -->
        <div class="col-md-4">
            <div class="stat-card d-flex align-items-center">
                <div class="stat-icon bg-red-soft text-danger me-3" style="background: #fef2f2;">
                    <i class="fas fa-exclamation-circle"></i>
                </div>
                <div>
                    <h6 class="text-muted text-uppercase text-xs fw-bold mb-1">Dept Grievances</h6>
                    <h3 class="fw-bold mb-0"><?php echo $pending_g; ?></h3>
                </div>
            </div>
        </div>
        <?php else: 
            // For Regular Teachers/Mentors: Show Academic Year
            $academic_year = "2025-2026";
            $sem_icon = "fa-calendar-alt";
            
            // Get active academic year
            $active_year_query = $conn->query("SELECT year_name FROM academic_years WHERE is_active = 1 LIMIT 1");
            if ($active_year_query && $active_year_query->num_rows > 0) {
                $active_year = $active_year_query->fetch_assoc();
                $academic_year = $active_year['year_name'];
            }
        ?>
        <!-- For Teachers/Mentors: Academic Year -->
        <div class="col-md-4">
            <div class="stat-card d-flex align-items-center">
                <div class="stat-icon bg-info-soft text-info me-3" style="background: #dbeafe;">
                    <i class="fas <?php echo $sem_icon; ?>"></i>
                </div>
                <div>
                    <h6 class="text-muted text-uppercase text-xs fw-bold mb-1">Academic Year</h6>
                    <h3 class="fw-bold mb-0"><?php echo $academic_year; ?></h3>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <!-- My Assigned Subjects -->
    <div class="row g-4 mb-4">
        <div class="col-12">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white border-bottom">
                    <h6 class="fw-bold mb-0"><i class="fas fa-book-open me-2 text-primary"></i> My Assigned Subjects</h6>
                </div>
                <div class="card-body p-0">
                    <?php 
                    // Determine Active Semesters based on Academic Calendar
                    $active_sems = [];
                    $sem_chk = $conn->query("SELECT period_name FROM semester_dates WHERE is_active = 1 LIMIT 1");
                    if ($sem_chk && $sem_chk->num_rows > 0) {
                        $p_name = $sem_chk->fetch_row()[0];
                        // If "Even" in name -> 2, 4, 6. Else -> 1, 3, 5
                        if (stripos($p_name, 'Even') !== false) $active_sems = [2, 4, 6];
                        else $active_sems = [1, 3, 5];
                    } else {
                       // Fallback based on month (Dec-May = Even, Jun-Nov = Odd)
                       $month = date('n');
                       if ($month <= 5 || $month == 12) $active_sems = [2, 4, 6];
                       else $active_sems = [1, 3, 5];
                    }
                    $sem_list = implode(',', $active_sems);

                    $my_subjects = $conn->query("SELECT * FROM subjects WHERE (assigned_teacher_id = $teacher_id OR teacher_id = $teacher_id) AND semester IN ($sem_list) ORDER BY subject_name");
                    if($my_subjects && $my_subjects->num_rows > 0):
                    ?>
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>Subject</th>
                                    <th>Code</th>
                                    <th>Semester</th>
                                    <th class="text-center">Students</th>
                                    <th class="text-center">Last Assessment Avg</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while($subj = $my_subjects->fetch_assoc()): 
                                    // Count students
                                    $student_count_query = $conn->query("SELECT COUNT(*) FROM students WHERE department = '{$subj['department']}' AND semester = {$subj['semester']}");
                                    $student_count = $student_count_query ? $student_count_query->fetch_row()[0] : 0;
                                    
                                    // Get latest assessment average
                                    $latest_avg_query = $conn->query("SELECT AVG(marks_obtained/max_marks * 100) as avg_pct FROM scores WHERE subject_code = '{$subj['subject_code']}' ORDER BY recorded_at DESC LIMIT 100");
                                    $avg_pct = $latest_avg_query && $latest_avg_query->num_rows > 0 ? $latest_avg_query->fetch_assoc()['avg_pct'] : null;
                                ?>
                                <tr>
                                    <td class="fw-medium"><?php echo htmlspecialchars($subj['subject_name']); ?></td>
                                    <td><span class="badge bg-light text-dark border"><?php echo $subj['subject_code']; ?></span></td>
                                    <td>Semester <?php echo $subj['semester']; ?></td>
                                    <td class="text-center">
                                        <span class="badge bg-primary"><?php echo $student_count; ?> students</span>
                                    </td>
                                    <td class="text-center">
                                        <?php if($avg_pct): ?>
                                            <span class="badge <?php echo $avg_pct >= 75 ? 'bg-success' : ($avg_pct >= 60 ? 'bg-warning' : 'bg-danger'); ?>">
                                                <?php echo round($avg_pct, 1); ?>%
                                            </span>
                                        <?php else: ?>
                                            <span class="text-muted">No data</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="submit_score.php?subject=<?php echo $subj['subject_code']; ?>" class="btn btn-sm btn-outline-primary">
                                            <i class="fas fa-pen-alt"></i> Grade
                                        </a>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php else: ?>
                    <div class="text-center py-4 text-muted">
                        <i class="fas fa-info-circle fa-2x mb-3"></i>
                        <p>No subjects registered for the active semester.</p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <?php 
    // Check if teacher is a Class Mentor OR HOD/Principal
    $teacher_role_query = $conn->query("SELECT teacher_role FROM teachers WHERE teacher_id = $teacher_id");
    $teacher_role = $teacher_role_query ? $teacher_role_query->fetch_assoc()['teacher_role'] : 'Teacher';
    
    // HOD View: Show Department Staff
    if ($teacher_role == 'HOD'):
        $staff_query = $conn->query("
            SELECT name, teacher_role 
            FROM teachers 
            WHERE department = '$dept' 
            ORDER BY 
                CASE teacher_role
                    WHEN 'Principal' THEN 1
                    WHEN 'HOD' THEN 2
                    WHEN 'Class Mentor' THEN 3
                    WHEN 'Teacher' THEN 4
                END,
                name
        ");
        $sh_count = $staff_query ? $staff_query->num_rows : 0;
    ?>
    <!-- Department Staff List (For HOD/Principal) -->
    <div class="row g-4 mb-4">
        <div class="col-12">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white border-bottom d-flex justify-content-between align-items-center">
                    <h6 class="fw-bold mb-0">
                        <i class="fas fa-chalkboard-teacher me-2 text-primary"></i> Department Faculty
                        <span class="badge bg-primary ms-2"><?php echo $sh_count; ?> Staff</span>
                    </h6>
                </div>
                <div class="card-body p-0">
                    <?php if($sh_count > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>Name</th>
                                    <th>Role</th>
                                    <th>Department</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while($stf = $staff_query->fetch_assoc()): ?>
                                <tr>
                                    <td class="fw-medium"><?php echo htmlspecialchars($stf['name']); ?></td>
                                    <td><span class="badge bg-light text-dark border"><?php echo htmlspecialchars($stf['teacher_role']); ?></span></td>
                                    <td><small class="text-muted"><?php echo htmlspecialchars($dept); ?></small></td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php else: ?>
                    <div class="text-center py-4 text-muted">
                        <p>No staff found in this department.</p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <?php elseif ($teacher_role == 'Class Mentor'): 
        // Mentor View: Show My Students
        $my_students = $conn->query("SELECT * FROM students WHERE class_teacher_id = $teacher_id ORDER BY semester, name");
        $st_count = $my_students ? $my_students->num_rows : 0;
    ?>
    <!-- My Students (Class Teacher Assignments) -->
    <div class="row g-4 mb-4">
        <div class="col-12">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white border-bottom d-flex justify-content-between align-items-center">
                    <h6 class="fw-bold mb-0">
                        <i class="fas fa-users me-2 text-success"></i> My Students (Class Teacher)
                        <span class="badge bg-primary ms-2"><?php echo $st_count; ?> students</span>
                    </h6>
                </div>
                <div class="card-body p-0">
                    <?php if($st_count > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>Roll Number</th>
                                    <th>Name</th>
                                    <th>Department</th>
                                    <th>Semester</th>
                                    <th>Contact</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $count = 0;
                                while($stu = $my_students->fetch_assoc()): 
                                    if($count >= 10) break; // Show first 10
                                    $count++;
                                ?>
                                <tr>
                                    <td><span class="badge bg-light text-dark border"><?php echo $stu['roll_number']; ?></span></td>
                                    <td class="fw-medium"><?php echo htmlspecialchars($stu['name']); ?></td>
                                    <td><?php echo $stu['department']; ?></td>
                                    <td>Semester <?php echo $stu['semester']; ?></td>
                                    <td><small class="text-muted"><?php echo $stu['email'] ?? 'N/A'; ?></small></td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php if($st_count > 10): ?>
                    <div class="card-footer bg-light text-center">
                        <small class="text-muted">Showing 10 of <?php echo $st_count; ?> students</small>
                    </div>
                    <?php endif; ?>
                    <?php else: ?>
                    <div class="text-center py-4 text-muted">
                        <i class="fas fa-info-circle fa-2x mb-3"></i>
                        <p>No students assigned to you as class teacher yet.</p>
                        <small>Contact admin to assign students to you.</small>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <div class="row g-4">
        <!-- Quick Actions -->
        <div class="col-md-6">
            <div class="card h-100 border-0 shadow-sm">
                <div class="card-header bg-white border-bottom">
                    <h6 class="fw-bold mb-0"><i class="fas fa-bolt me-2 text-warning"></i> Quick Actions</h6>
                </div>
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-6">
                            <a href="mark_attendance.php" class="d-block text-decoration-none">
                                <div class="p-3 bg-success bg-opacity-10 rounded text-center hover-shadow">
                                    <i class="fas fa-calendar-check fa-2x text-success mb-2"></i>
                                    <div class="fw-medium text-dark">Mark Attendance</div>
                                </div>
                            </a>
                        </div>
                        <div class="col-6">
                            <a href="submit_score.php" class="d-block text-decoration-none">
                                <div class="p-3 bg-primary bg-opacity-10 rounded text-center hover-shadow">
                                    <i class="fas fa-pen-alt fa-2x text-primary mb-2"></i>
                                    <div class="fw-medium text-dark">Enter Marks</div>
                                </div>
                            </a>
                        </div>
                        <div class="col-6">
                            <a href="submit_behavior.php" class="d-block text-decoration-none">
                                <div class="p-3 bg-info bg-opacity-10 rounded text-center hover-shadow">
                                    <i class="fas fa-star fa-2x text-info mb-2"></i>
                                    <div class="fw-medium text-dark">Rate Behavior</div>
                                </div>
                            </a>
                        </div>
                        <div class="col-6">
                            <a href="leave_requests.php" class="d-block text-decoration-none">
                                <div class="p-3 bg-warning bg-opacity-10 rounded text-center hover-shadow">
                                    <i class="fas fa-calendar-times fa-2x text-warning mb-2"></i>
                                    <div class="fw-medium text-dark">Apply Leave</div>
                                </div>
                            </a>
                        </div>
                        <?php if($t_role == 'HOD' || $t_role == 'Principal'): ?>
                        <div class="col-6">
                            <a href="grievances.php" class="d-block text-decoration-none">
                                <div class="p-3 bg-danger bg-opacity-10 rounded text-center hover-shadow">
                                    <i class="fas fa-exclamation-circle fa-2x text-danger mb-2"></i>
                                    <div class="fw-medium text-dark">Grievances</div>
                                    <?php if($pending_g > 0): ?>
                                    <span class="badge bg-danger mt-1"><?php echo $pending_g; ?></span>
                                    <?php endif; ?>
                                </div>
                            </a>
                        </div>
                        <?php endif; ?>
                        <?php if($t_role == 'Class Mentor'): ?>
                        <div class="col-6">
                            <a href="class_administration.php" class="d-block text-decoration-none">
                                <div class="p-3 bg-secondary bg-opacity-10 rounded text-center hover-shadow">
                                    <i class="fas fa-users fa-2x text-secondary mb-2"></i>
                                    <div class="fw-medium text-dark">My Class</div>
                                </div>
                            </a>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- At-Risk Students Alert -->
        <div class="col-md-6">
            <div class="card h-100 border-0 shadow-sm">
                <div class="card-header bg-white border-bottom">
                     <h6 class="fw-bold mb-0"><i class="fas fa-exclamation-triangle me-2 text-warning"></i> Students Requiring Attention</h6>
                </div>
                <div class="card-body">
                    <?php
                    // Get students with <75% attendance in this department
                    $at_risk = $conn->query("
                        SELECT s.name, s.roll_number,
                               COUNT(CASE WHEN a.status = 'P' THEN 1 END) * 100.0 / COUNT(*) as attendance_pct
                        FROM students s
                        LEFT JOIN attendance a ON s.student_id = a.student_id
                        WHERE s.department = '$dept'
                        GROUP BY s.student_id
                        HAVING attendance_pct < 75
                        ORDER BY attendance_pct ASC
                        LIMIT 5
                    ");
                    
                    if($at_risk && $at_risk->num_rows > 0):
                    ?>
                        <div class="list-group list-group-flush">
                            <?php while($risk = $at_risk->fetch_assoc()): ?>
                            <div class="list-group-item px-0">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <div class="fw-medium text-sm"><?php echo htmlspecialchars($risk['name']); ?></div>
                                        <small class="text-muted"><?php echo $risk['roll_number']; ?></small>
                                    </div>
                                    <span class="badge bg-danger"><?php echo round($risk['attendance_pct'], 1); ?>% attendance</span>
                                </div>
                            </div>
                            <?php endwhile; ?>
                        </div>
                        <div class="mt-3">
                            <small class="text-muted"><i class="fas fa-info-circle me-1"></i> Students with less than 75% attendance</small>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-4">
                            <i class="fas fa-check-circle fa-3x text-success mb-3"></i>
                            <p class="text-muted fw-medium mt-2">Attendance looks good!</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

    </div>
</main>

<script>
    function updateClock() {
        const now = new Date();
        document.getElementById('clock').textContent = now.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
    }
    setInterval(updateClock, 1000);
    updateClock();
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
