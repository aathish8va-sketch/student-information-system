<?php
// teacher/leave_approvals.php - Three-Tier Leave Approval (Mentor → HOD → Principal)
require_once '../includes/db_connect.php';
check_login(['teacher']);

$teacher_id = isset($_SESSION['profile_id']) ? intval($_SESSION['profile_id']) : 0;

// Validate Teacher ID
if ($teacher_id <= 0) {
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        echo json_encode(['success' => false, 'message' => 'Session Error: Invalid Teacher ID']);
        exit;
    }
    // If not POST, normal redirect (handled by check_login usually, but safe fallback)
    header("Location: ../login.php");
    exit;
}

// Fetch teacher info with error handling
$t_query = $conn->query("SELECT * FROM teachers WHERE teacher_id = $teacher_id");

if (!$t_query) {
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        echo json_encode(['success' => false, 'message' => 'Database Error: ' . $conn->error]);
        exit;
    }
    die("Database Error: " . $conn->error);
}

$teacher = $t_query->fetch_assoc();
if (!$teacher) {
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        echo json_encode(['success' => false, 'message' => 'Teacher profile not found']);
        exit;
    }
    die("Teacher profile not found");
}

$dept = $teacher['department'];
$teacher_role = $teacher['teacher_role'] ?? 'Teacher';
$teacher_name = $teacher['name']; // Restore teacher_name for display

// Determine which sections to show
$is_mentor = ($teacher_role == 'Class Mentor'); // HODs/Principals should not see Mentor section unless they are explicitly Class Mentors
$is_hod = ($teacher_role == 'HOD' || $teacher_role == 'Principal');
$is_principal = ($teacher_role == 'Principal');

// Handle AJAX approval/rejection
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    
    if (!verify_csrf_token($_POST['csrf_token'])) {
        echo json_encode(['success' => false, 'message' => 'Invalid request']);
        exit;
    }
    
    $request_id = (int)$_POST['request_id'];
    $action = $_POST['action'];
    $comments = sanitize_input($_POST['comments'] ?? '');
    
    $req_q = $conn->query("SELECT * FROM leave_requests WHERE request_id = $request_id");
    if (!$req_q) {
        echo json_encode(['success' => false, 'message' => 'Database Error: ' . $conn->error]);
        exit;
    }
    $req = $req_q->fetch_assoc();
    
    if (!$req) {
        echo json_encode(['success' => false, 'message' => 'Request not found']);
        exit;
    }
    
    $success = false;
    $message = '';
    if ($action == 'mentor_approve') {
        $stmt = $conn->prepare("UPDATE leave_requests SET status = 'Approved by Mentor', mentor_id = ?, mentor_reviewed_at = NOW(), mentor_comments = ? WHERE request_id = ?");
        if (!$stmt) { echo json_encode(['success' => false, 'message' => 'Prepare Error: ' . $conn->error]); exit; }
        
        $stmt->bind_param("isi", $teacher_id, $comments, $request_id);
        $success = $stmt->execute();
        $message = $success ? 'Request approved and forwarded to HOD' : 'Failed to approve request: ' . $stmt->error;
        $stmt->close();
    } elseif ($action == 'mentor_reject') {
        $stmt = $conn->prepare("UPDATE leave_requests SET status = 'Rejected by Mentor', mentor_id = ?, mentor_reviewed_at = NOW(), mentor_comments = ? WHERE request_id = ?");
        if (!$stmt) { echo json_encode(['success' => false, 'message' => 'Prepare Error: ' . $conn->error]); exit; }

        $stmt->bind_param("isi", $teacher_id, $comments, $request_id);
        $success = $stmt->execute();
        $message = $success ? 'Request rejected' : 'Failed to reject request: ' . $stmt->error;
        $stmt->close();
    } elseif ($action == 'hod_approve') {
        // CHECK source
        // Use student_id presence to determine type (applicant_type column does not exist)
        $chk_q = $conn->query("SELECT student_id, request_type FROM leave_requests WHERE request_id = $request_id");
        if (!$chk_q) { echo json_encode(['success' => false, 'message' => 'DB Error checking source: ' . $conn->error]); exit; }
        $chk = $chk_q->fetch_assoc();
        
        // If student_id is set and > 0, it's a student
        if ($chk && !empty($chk['student_id'])) {
             $new_status = 'Approved'; // Final
             $msg = 'Request approved (Final)';
             
             // HOOK: Auto-Update Attendance for On-Duty
             // If Final Approved and it is ON-DUTY, update attendance to 'P'
             if ($chk['request_type'] == 'On-Duty') {
                 // Fetch dates
                 $d_q = $conn->query("SELECT from_date, to_date FROM leave_requests WHERE request_id = $request_id")->fetch_assoc();
                 if ($d_q) {
                     $f_d = $d_q['from_date'];
                     $t_d = $d_q['to_date'];
                     // Update Attendance (Only change 'A' to 'P', or insert 'P' if missing? Stick to update existing)
                     // User said "change to present".
                     $conn->query("UPDATE attendance SET status = 'P' WHERE student_id = {$chk['student_id']} AND date BETWEEN '$f_d' AND '$t_d'");
                 }
             }
        } else {
             $new_status = 'Approved by HOD'; // Goes to Principal
             $msg = 'Request approved and forwarded to Principal';
        }

        $stmt = $conn->prepare("UPDATE leave_requests SET status = ?, hod_id = ?, hod_reviewed_at = NOW(), hod_comments = ? WHERE request_id = ?");
        if (!$stmt) { echo json_encode(['success' => false, 'message' => 'Prepare Error: ' . $conn->error]); exit; }

        $stmt->bind_param("sisi", $new_status, $teacher_id, $comments, $request_id);
        $success = $stmt->execute();
        $message = $success ? $msg : 'Failed to approve request: ' . $stmt->error;
        $stmt->close();
    } elseif ($action == 'hod_reject') {
        $stmt = $conn->prepare("UPDATE leave_requests SET status = 'Rejected by HOD', hod_id = ?, hod_reviewed_at = NOW(), hod_comments = ? WHERE request_id = ?");
        if (!$stmt) { echo json_encode(['success' => false, 'message' => 'Prepare Error: ' . $conn->error]); exit; }

        $stmt->bind_param("isi", $teacher_id, $comments, $request_id);
        $success = $stmt->execute();
        $message = $success ? 'Request rejected by HOD' : 'Failed to reject request: ' . $stmt->error;
        $stmt->close();
    } elseif ($action == 'principal_approve') {
        $stmt = $conn->prepare("UPDATE leave_requests SET status = 'Approved by Principal', principal_id = ?, principal_reviewed_at = NOW(), principal_comments = ? WHERE request_id = ?");
        if (!$stmt) { echo json_encode(['success' => false, 'message' => 'Prepare Error: ' . $conn->error]); exit; }

        $stmt->bind_param("isi", $teacher_id, $comments, $request_id);
        $success = $stmt->execute();
        $message = $success ? 'Request fully approved' : 'Failed to approve request: ' . $stmt->error;
        $stmt->close();
    } elseif ($action == 'principal_reject') {
        $stmt = $conn->prepare("UPDATE leave_requests SET status = 'Rejected by Principal', principal_id = ?, principal_reviewed_at = NOW(), principal_comments = ? WHERE request_id = ?");
        if (!$stmt) { echo json_encode(['success' => false, 'message' => 'Prepare Error: ' . $conn->error]); exit; }

        $stmt->bind_param("isi", $teacher_id, $comments, $request_id);
        $success = $stmt->execute();
        $message = $success ? 'Request rejected by Principal' : 'Failed to reject request: ' . $stmt->error;
        $stmt->close();
    }
    
    echo json_encode(['success' => $success, 'message' => $message]);
    exit;
}

// Counts
$mentor_pending = 0;
$hod_pending = 0;
$principal_pending = 0;

if ($is_mentor) {
    $count_q = $conn->query("SELECT COUNT(*) FROM leave_requests lr JOIN students s ON lr.student_id = s.student_id WHERE s.class_teacher_id = $teacher_id AND lr.status = 'Pending'");
    $mentor_pending = $count_q ? $count_q->fetch_row()[0] : 0;
}

if ($is_hod) {
    // Count student requests from this department that have been approved by mentor
    $student_count = $conn->query("SELECT COUNT(*) FROM leave_requests lr JOIN students s ON lr.student_id = s.student_id WHERE s.department = '$dept' AND lr.status = 'Approved by Mentor'");
    $hod_pending = $student_count ? $student_count->fetch_row()[0] : 0;
}

if ($is_principal) {
    $count_q = $conn->query("SELECT COUNT(*) FROM leave_requests WHERE status = 'Approved by HOD' OR (status = 'Pending' AND teacher_id IN (SELECT teacher_id FROM teachers WHERE teacher_role = 'HOD'))");
    $principal_pending = $count_q ? $count_q->fetch_row()[0] : 0;
}

// Helper functions
function get_request_icon($type) {
    switch($type) {
        case 'Medical Leave': return '<i class="fas fa-clinic-medical text-danger"></i>';
        case 'Personal Leave': return '<i class="fas fa-user-clock text-primary"></i>';
        case 'On-Duty': return '<i class="fas fa-briefcase text-success"></i>';
        default: return '<i class="fas fa-file"></i>';
    }
}

function get_status_badge($status) {
    switch($status) {
        case 'Pending': return '<span class="badge bg-warning text-dark">Pending</span>';
        case 'Approved by Mentor': return '<span class="badge bg-info">Approved by Mentor</span>';
        case 'Approved by HOD': return '<span class="badge bg-primary">Approved by HOD</span>';
        case 'Approved': return '<span class="badge bg-success">Approved</span>';
        case 'Approved by Principal': return '<span class="badge bg-success">Fully Approved</span>';
        case 'Rejected by Mentor': return '<span class="badge bg-danger">Rejected by Mentor</span>';
        case 'Rejected by HOD': return '<span class="badge bg-danger">Rejected by HOD</span>';
        case 'Rejected by Principal': return '<span class="badge bg-danger">Rejected by Principal</span>';
        default: return '<span class="badge bg-secondary">' . $status . '</span>';
    }
}
?>
<?php if (!defined('INCLUDED_AS_FRAGMENT')): ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Leave Approvals - Chendhuran SIS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;800&display=swap" rel="stylesheet">
    <link href="../includes/css/styles.css" rel="stylesheet">
</head>
<body>
<?php include '../includes/sidebar.php'; ?>

<main class="main-content">
<?php endif; ?>

<?php if (defined('INCLUDED_AS_FRAGMENT')): ?>
<div class="fade-in">
<?php endif; ?>
    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h3 class="fw-bold mb-1">Leave & On-Duty Approvals</h3>
            <p class="text-muted mb-0">
                <i class="fas fa-user me-1"></i> <?php echo htmlspecialchars($teacher_name); ?> • 
                <span class="badge bg-<?php echo $teacher_role == 'Principal' ? 'danger' : ($teacher_role == 'HOD' ? 'success' : 'primary'); ?>">
                    <?php echo $teacher_role; ?>
                </span>
            </p>
        </div>
    </div>

    <?php if (!$is_principal): // Hide stat cards from Principal ?>
    <!-- Stats Cards -->
    <div class="row g-3 mb-4">
        <?php if ($is_mentor): ?>
        <div class="col-md-4">
            <div class="stat-card">
                <h6 class="text-muted text-uppercase text-xs fw-bold mb-1">Pending Mentor Review</h6>
                <h3 class="fw-bold mb-0"><?php echo $mentor_pending; ?></h3>
            </div>
        </div>
        <?php endif; ?>
        
        <?php if ($is_hod && false): // DISABLED - User requested removal ?>
        <div class="col-md-4">
            <div class="stat-card">
                <h6 class="text-muted text-uppercase text-xs fw-bold mb-1">Pending HOD Approval</h6>
                <h3 class="fw-bold mb-0"><?php echo $hod_pending; ?></h3>
            </div>
        </div>
        <?php endif; ?>
        
        <?php if ($is_principal): ?>
        <div class="col-md-4">
            <div class="stat-card">
                <h6 class="text-muted text-uppercase text-xs fw-bold mb-1">Pending Principal Approval</h6>
                <h3 class="fw-bold mb-0"><?php echo $principal_pending; ?></h3>
            </div>
        </div>
        <?php endif; ?>
    </div>
    <?php endif; // End hide stat cards from Principal ?>

    <?php if (!$is_mentor && !$is_hod && !$is_principal): ?>
        <div class="alert alert-info">
            <i class="fas fa-info-circle me-2"></i>
            You don't have approval permissions. Please contact admin to assign you a role (Class Mentor, HOD, or Principal).
        </div>
    <?php endif; ?>

    <!-- MENTOR SECTION -->
    <?php if ($is_mentor): 
        $mentor_requests = $conn->query("
            SELECT lr.*, s.name as student_name, s.roll_number, s.department as student_dept, s.semester
            FROM leave_requests lr
            JOIN students s ON lr.student_id = s.student_id
            WHERE s.class_teacher_id = $teacher_id AND lr.status = 'Pending'
            ORDER BY lr.submitted_at ASC
        ");
    ?>
    <div class="card border-0 shadow-sm mb-4">
        <div class="card-header bg-white border-bottom">
            <h6 class="fw-bold mb-0">
                <i class="fas fa-user-check me-2 text-primary"></i> Mentor Approvals
                <span class="badge bg-warning text-dark ms-2"><?php echo $mentor_pending; ?> Pending</span>
            </h6>
        </div>
        <div class="card-body p-3">
            <?php if ($mentor_requests && $mentor_requests->num_rows > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>Student</th>
                                <th>Type</th>
                                <th>Dates</th>
                                <th>Reason</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($req = $mentor_requests->fetch_assoc()): ?>
                            <tr>
                                <td>
                                    <strong><?php echo htmlspecialchars($req['student_name']); ?></strong><br>
                                    <small class="text-muted"><?php echo $req['roll_number']; ?></small>
                                </td>
                                <td><?php echo get_request_icon($req['request_type']);  ?> <?php echo htmlspecialchars($req['request_type']); ?></td>
                                <td><small><?php echo date('M d', strtotime($req['from_date'])); ?> - <?php echo date('M d', strtotime($req['to_date'])); ?></small></td>
                                <td><small><?php echo htmlspecialchars(substr($req['reason'], 0, 50)) . '...'; ?></small></td>
                                <td>
                                    <button class="btn btn-sm btn-success me-1" onclick="approveRequest(<?php echo $req['request_id']; ?>, 'mentor_approve')">
                                        <i class="fas fa-check"></i> Approve
                                    </button>
                                    <button class="btn btn-sm btn-danger" onclick="showRejectModal(<?php echo $req['request_id']; ?>, 'mentor_reject')">
                                        <i class="fas fa-times"></i> Reject
                                    </button>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="text-center py-4">
                    <i class="fas fa-check-circle fa-3x text-success mb-3"></i>
                    <p class="text-muted">No pending mentor requests</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- HOD SECTION (Unified Student+Staff) -->
    <?php if ($is_hod): 
        // 1. Fetch Student Requests (Approved by Mentor)
        $hod_student_reqs = $conn->query("
            SELECT lr.*, s.name as student_name, s.roll_number, s.semester, 
                   COALESCE(tm.name, tc.name, 'Unknown') as mentor_name,
                   lr.mentor_comments 
            FROM leave_requests lr
            JOIN students s ON lr.student_id = s.student_id
            LEFT JOIN teachers tm ON lr.mentor_id = tm.teacher_id
            LEFT JOIN teachers tc ON s.class_teacher_id = tc.teacher_id
            WHERE s.department = '$dept' AND lr.status = 'Approved by Mentor'
            ORDER BY lr.submitted_at ASC
        ");

        // 2. Fetch Staff Requests (Unified for HOD/Principal)
        if ($is_principal) {
            // Principal sees ALL staff requests that are Pending or Approved by HOD (waiting for final)
            // This merges the previous "Principal Final Approval" content into this list
            $hod_staff_reqs = $conn->query("
                SELECT lr.*, t.name as teacher_name, t.department, t.teacher_role
                FROM leave_requests lr
                JOIN teachers t ON lr.teacher_id = t.teacher_id
                WHERE 
                   (lr.status = 'Pending') OR (lr.status = 'Approved by HOD')
                ORDER BY lr.submitted_at ASC
            ");
        } else {
            // HOD sees only their department's pending staff requests
            $hod_staff_reqs = $conn->query("
                SELECT lr.*, t.name as teacher_name, t.department, t.teacher_role
                FROM leave_requests lr
                JOIN teachers t ON lr.teacher_id = t.teacher_id
                WHERE t.department = '$dept' 
                AND lr.status = 'Pending' 
                AND t.teacher_role != 'HOD'
                ORDER BY lr.submitted_at ASC
            ");
        }

        $student_pending_count = $hod_student_reqs ? $hod_student_reqs->num_rows : 0;
        $staff_pending_count = $hod_staff_reqs ? $hod_staff_reqs->num_rows : 0;
    ?>
    
    <?php if (!$is_principal): // Hide Student Leaves from Principal ?>
    <!-- 1. STUDENT LEAVES CARD -->
    <div class="card border-0 shadow-sm mb-4">
        <div class="card-header bg-success bg-opacity-10 border-bottom d-flex justify-content-between align-items-center">
            <h6 class="fw-bold mb-0 text-success">
                <i class="fas fa-user-graduate me-2"></i> Student Leaves
            </h6>
            <span class="badge bg-success rounded-pill"><?php echo $student_pending_count; ?> Pending</span>
        </div>
        <div class="card-body p-3">
            <?php if ($hod_student_reqs && $hod_student_reqs->num_rows > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover mb-0 align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>Student</th>
                                <th>Type</th>
                                <th>Dates</th>
                                <th>Mentor</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($req = $hod_student_reqs->fetch_assoc()): ?>
                            <tr>
                                <td>
                                    <div class="fw-bold"><?php echo htmlspecialchars($req['student_name']); ?></div>
                                    <div class="small text-muted"><?php echo $req['roll_number']; ?> • Sem <?php echo $req['semester']; ?></div>
                                </td>
                                <td><?php echo get_request_icon($req['request_type']); ?> <?php echo htmlspecialchars($req['request_type']); ?></td>
                                <td>
                                    <div class="small date-badge"><?php echo date('M d', strtotime($req['from_date'])); ?> - <?php echo date('M d', strtotime($req['to_date'])); ?></div>
                                </td>
                                <td>
                                    <div class="small text-primary"><i class="fas fa-check-circle me-1"></i><?php echo htmlspecialchars($req['mentor_name'] ?? 'Unknown'); ?></div>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-outline-success me-1" onclick="approveRequest(<?php echo $req['request_id']; ?>, 'hod_approve')">
                                        <i class="fas fa-check"></i>
                                    </button>
                                    <button class="btn btn-sm btn-outline-danger" onclick="showRejectModal(<?php echo $req['request_id']; ?>, 'hod_reject')">
                                        <i class="fas fa-times"></i>
                                    </button>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="text-center py-4 text-muted">
                    <i class="fas fa-check-circle fa-2x mb-2 opacity-50"></i>
                    <p class="mb-0">No pending student requests</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; // End Student Leaves (hidden from Principal) ?>

    <!-- 2. STAFF LEAVES CARD -->
    <div class="card border-0 shadow-sm mb-4">
        <div class="card-header bg-primary bg-opacity-10 border-bottom d-flex justify-content-between align-items-center">
            <h6 class="fw-bold mb-0 text-primary">
                <i class="fas fa-chalkboard-teacher me-2"></i> Staff Leaves
                <?php if ($is_principal) echo "(All Departments)"; ?>
            </h6>
            <span class="badge bg-primary rounded-pill"><?php echo $staff_pending_count; ?> Pending</span>
        </div>
        <div class="card-body p-3">
            <?php if ($hod_staff_reqs && $hod_staff_reqs->num_rows > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover mb-0 align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>Staff Member</th>
                                <th>Type</th>
                                <th>Dates</th>
                                <th>Reason</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($req = $hod_staff_reqs->fetch_assoc()): ?>
                            <tr>
                                <td>
                                    <div class="fw-bold text-dark"><?php echo htmlspecialchars($req['teacher_name']); ?></div>
                                    <span class="badge bg-light text-secondary border"><?php echo htmlspecialchars($req['teacher_role'] ?? 'Faculty'); ?></span>
                                    <?php if ($is_principal): ?>
                                    <br><small class="text-muted"><?php echo htmlspecialchars($req['department'] ?? ''); ?></small>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo get_request_icon($req['request_type']); ?> <?php echo htmlspecialchars($req['request_type']); ?></td>
                                <td>
                                    <div class="small date-badge"><?php echo date('M d', strtotime($req['from_date'])); ?> - <?php echo date('M d', strtotime($req['to_date'])); ?></div>
                                </td>
                                <td>
                                    <span class="text-truncate d-inline-block" style="max-width: 150px;" title="<?php echo htmlspecialchars($req['reason']); ?>">
                                        <?php echo htmlspecialchars($req['reason']); ?>
                                    </span>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-outline-success me-1" onclick="approveRequest(<?php echo $req['request_id']; ?>, '<?php echo $is_principal ? 'principal_approve' : 'hod_approve'; ?>')">
                                        <i class="fas fa-check"></i>
                                    </button>
                                    <button class="btn btn-sm btn-outline-danger" onclick="showRejectModal(<?php echo $req['request_id']; ?>, '<?php echo $is_principal ? 'principal_reject' : 'hod_reject'; ?>')">
                                        <i class="fas fa-times"></i>
                                    </button>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="text-center py-4 text-muted">
                    <i class="fas fa-mug-hot fa-2x mb-2 opacity-50"></i>
                    <p class="mb-0">No pending staff requests</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>

</main>

<!-- Reject Modal -->
<div class="modal fade" id="rejectModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Reject Request</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="reject_request_id">
                <input type="hidden" id="reject_action">
                <div class="mb-3">
                    <label class="form-label">Reason for Rejection <span class="text-danger">*</span></label>
                    <textarea class="form-control" id="reject_comments" rows="3" required placeholder="Please provide a reason for rejection..."></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-danger" onclick="confirmReject()">
                    <i class="fas fa-times me-2"></i> Confirm Rejection
                </button>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
const csrfToken = '<?php echo generate_csrf_token(); ?>';
let rejectModal;

document.addEventListener('DOMContentLoaded', function() {
    rejectModal = new bootstrap.Modal(document.getElementById('rejectModal'));
});

function approveRequest(requestId, action) {
    if (!confirm('Are you sure you want to approve this request?')) return;
    
    const formData = new FormData();
    formData.append('action', action);
    formData.append('request_id', requestId);
    formData.append('comments', 'Approved');
    formData.append('csrf_token', csrfToken);
    
    fetch('leave_approvals.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        alert(data.message);
        if (data.success) location.reload();
    })
    .catch(error => {
        alert('Network error occurred');
        console.error(error);
    });
}

function showRejectModal(requestId, action) {
    document.getElementById('reject_request_id').value = requestId;
    document.getElementById('reject_action').value = action;
    document.getElementById('reject_comments').value = '';
    rejectModal.show();
}

function confirmReject() {
    const requestId = document.getElementById('reject_request_id').value;
    const action = document.getElementById('reject_action').value;
    const comments = document.getElementById('reject_comments').value.trim();
    
    if (!comments) {
        alert('Please provide a reason for rejection');
        return;
    }
    
    const formData = new FormData();
    formData.append('action', action);
    formData.append('request_id', requestId);
    formData.append('comments', comments);
    formData.append('csrf_token', csrfToken);
    
    fetch('leave_approvals.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        alert(data.message);
        if (data.success) {
            rejectModal.hide();
            location.reload();
        }
    })
    .catch(error => {
        alert('Network error occurred');
        console.error(error);
    });
}
</script>
<?php if (defined('INCLUDED_AS_FRAGMENT')): ?>
</div>
<?php endif; ?>

<?php if (!defined('INCLUDED_AS_FRAGMENT')): ?>
</main>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php endif; ?>
