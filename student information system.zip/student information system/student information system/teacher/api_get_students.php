<?php
// api_get_students.php - AJAX Endpoint
require_once '../includes/db_connect.php';
// check_login(['teacher']); // Optional: strict check, or rely on session

if(!isset($_GET['dept']) || !isset($_GET['sem'])) {
    echo json_encode([]);
    exit;
}

$dept = $conn->real_escape_string($_GET['dept']);
$sem_param = intval($_GET['sem']);

// Extended Logic to fetch Marks or Attendance
$subject_code = isset($_GET['subject_code']) ? $conn->real_escape_string($_GET['subject_code']) : '';
$assess_type = isset($_GET['assessment_type']) ? $conn->real_escape_string($_GET['assessment_type']) : '';
$date = isset($_GET['date']) ? $conn->real_escape_string($_GET['date']) : date('Y-m-d');
$fetch_type = $_GET['type'] ?? 'basic'; // 'scores', 'attendance', 'basic'

// Base Query
$sql = "SELECT s.student_id as id, s.roll_number, s.name 
        FROM students s 
        WHERE s.department = '$dept' AND s.semester = $sem_param";

if ($fetch_type == 'scores' && $subject_code && $assess_type) {
    // Join with Scores
    $sql = "SELECT s.student_id as id, s.roll_number, s.name, sc.marks_obtained 
            FROM students s 
            LEFT JOIN scores sc ON s.student_id = sc.student_id 
                AND sc.subject_code = '$subject_code' 
                AND sc.assessment_type = '$assess_type'
            WHERE s.department = '$dept' AND s.semester = $sem_param";
} elseif ($fetch_type == 'attendance' && $subject_code && $date) {
    // Join with Attendance
    $sql = "SELECT s.student_id as id, s.roll_number, s.name, a.status 
            FROM students s 
            LEFT JOIN attendance a ON s.student_id = a.student_id 
                AND a.subject_code = '$subject_code' 
                AND a.date = '$date'
            WHERE s.department = '$dept' AND s.semester = $sem_param";
}

$sql .= " ORDER BY s.roll_number ASC";

$res = $conn->query($sql);
$students = [];

while($row = $res->fetch_assoc()) {
    // Add year (keep existing logic)
    $sem = $sem_param; 
    $year_num = ceil($sem / 2);
    $suffix = ($year_num == 1) ? 'st' : (($year_num == 2) ? 'nd' : (($year_num == 3) ? 'rd' : 'th'));
    $row['year'] = "{$year_num}{$suffix} Year";
    
    // Normalize nulls
    if(isset($row['marks_obtained']) && $row['marks_obtained'] === null) $row['marks_obtained'] = '';
    if(isset($row['status']) && $row['status'] === null) $row['status'] = 'P'; // Default to Present if new
    
    $students[] = $row;
}

header('Content-Type: application/json');
echo json_encode($students);
?>
