<?php
// submit_score.php - Class Management & Grading
require_once '../includes/db_connect.php';
require_once '../includes/year_helpers.php';
check_login(['teacher']);

$teacher_id = $_SESSION['profile_id'];
$message = '';
$error = '';

// Handle Submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['submit_scores'])) {
        // ... (Score logic - robust loop)
        $sub = $_POST['subject_code'];
        $assess = $_POST['assessment_type'];
        $max = $_POST['max_marks'];
        
        foreach ($_POST['marks'] as $sid => $mark) {
            if ($mark !== '') {
                // Upsert Logic (Insert or Update)
                $sql = "INSERT INTO scores (student_id, subject_code, assessment_type, marks_obtained, max_marks) 
                        VALUES (?, ?, ?, ?, ?) 
                        ON DUPLICATE KEY UPDATE marks_obtained = ?, max_marks = ?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("issdddd", $sid, $sub, $assess, $mark, $max, $mark, $max);
                $stmt->execute();
            }
        }
        $message = "Scores saved successfully.";
    } elseif (isset($_POST['submit_attendance'])) {
        // ... (Attendance logic)
        $sub = $_POST['subject_code'];
        $date = $_POST['date'];
        
        foreach ($_POST['attendance'] as $sid => $status) {
            $sql = "INSERT INTO attendance (student_id, subject_code, date, status) 
                    VALUES (?, ?, ?, ?) 
                    ON DUPLICATE KEY UPDATE status = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("issss", $sid, $sub, $date, $status, $status);
            $stmt->execute();
        }
        $message = "Attendance recorded for $date.";
    }
}

// Fetch Subjects
// Fetch Subjects (Filtered by Active Semester)
// Determine Active Semesters based on Academic Calendar
$active_sems = [];
$sem_chk = $conn->query("SELECT period_name FROM semester_dates WHERE is_active = 1 LIMIT 1");
if ($sem_chk && $sem_chk->num_rows > 0) {
    $p_name = $sem_chk->fetch_row()[0];
    if (stripos($p_name, 'Even') !== false) $active_sems = [2, 4, 6];
    else $active_sems = [1, 3, 5];
} else {
    $month = date('n');
    if ($month <= 5 || $month == 12) $active_sems = [2, 4, 6];
    else $active_sems = [1, 3, 5];
}
$sem_list = implode(',', $active_sems);

$subjects = $conn->query("SELECT * FROM subjects WHERE (assigned_teacher_id = $teacher_id OR teacher_id = $teacher_id) AND semester IN ($sem_list)");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Class Manager - Chendhuran</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../includes/css/styles.css" rel="stylesheet">
</head>
<body>
<?php include '../includes/sidebar.php'; ?>

<main class="main-content">
    <div class="glass-header d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold mb-1">Mark Entry Portal</h4>
            <p class="text-muted mb-0 small">Gradebook & Assessment Management</p>
        </div>
        <div>
             <span class="badge bg-white text-secondary border px-3 py-2 fw-normal shadow-sm">
                <i class="fas fa-edit me-1 text-primary"></i> <span id="max_marks_display">Max: -</span>
            </span>
        </div>
    </div>

    <?php if($message): ?><div class="alert alert-success shadow-sm border-0 fade-in"><i class="fas fa-check-circle me-2"></i><?php echo $message; ?></div><?php endif; ?>

    <form method="POST" id="marksForm">
        <input type="hidden" name="submit_scores" value="1">
        
        <!-- Control Panel -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-body p-4">
                <div class="row g-4">
                    <div class="col-md-4 border-end">
                        <label class="fw-bold text-uppercase text-xs text-muted mb-2">1. Select Subject</label>
                        <select class="form-select" name="subject_code" id="subject_select_scores" required onchange="renderAssessmentTabs(); loadStudents('scores');">
                            <option value="">-- Choose Subject --</option>
                            <?php 
                            if ($subjects->num_rows > 0):
                                $subjects->data_seek(0);
                                while($sub = $subjects->fetch_assoc()): 
                                    $year_label = get_year_label(get_year_from_semester($sub['semester']));
                            ?>
                                <option value="<?php echo $sub['subject_code']; ?>" 
                                        data-dept="<?php echo $sub['department']; ?>" 
                                        data-sem="<?php echo $sub['semester']; ?>"
                                        data-type="<?php echo $sub['subject_type'] ?? 'Theory'; ?>">
                                    <?php echo escape($sub['subject_name']); ?> 
                                    (Sem <?php echo $sub['semester']; ?>)
                                </option>
                            <?php 
                                endwhile;
                            else:
                            ?>
                                <option value="" disabled>No subjects for active semester</option>
                            <?php endif; ?>
                        </select>
                    </div>
                    <div class="col-md-8">
                        <label class="fw-bold text-uppercase text-xs text-muted mb-2">2. Select Assessment</label>
                        <input type="hidden" name="assessment_type" id="assessment_type" required>
                        <input type="hidden" name="max_marks" id="max_marks">
                        
                        <div id="assessment_tabs" class="nav nav-pills overflow-auto flex-nowrap pb-2" style="gap: 8px;">
                            <?php 
                            $static_assessments = [
                                ['val' => 'Assessment 1', 'label' => 'Assessment 1', 'max' => 50],
                                ['val' => 'Assessment 2', 'label' => 'Assessment 2', 'max' => 50],
                                ['val' => 'Assessment 3', 'label' => 'Assessment 3', 'max' => 50],
                                ['val' => 'Assignment', 'label' => 'Assignment', 'max' => 20],
                                ['val' => 'Final Exam', 'label' => 'Final Exam', 'max' => 100]
                            ];
                            foreach($static_assessments as $sa): 
                            ?>
                                <button type="button" 
                                        class="btn btn-outline-primary assessment-tab bg-white" 
                                        onclick="selectAssessment(this, '<?php echo $sa['val']; ?>', <?php echo $sa['max']; ?>)">
                                    <?php echo $sa['label']; ?>
                                </button>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Data Entry Grid -->
        <div class="card border-0 shadow-sm" style="min-height: 400px;">
            <div class="card-header bg-white border-bottom py-3">
                <div class="d-flex justify-content-between align-items-center">
                    <h6 class="fw-bold mb-0 text-primary"><i class="fas fa-list-ol me-2"></i>Student List</h6>
                    <button type="submit" class="btn btn-primary shadow-sm px-4" id="btn_save_scores" style="display:none">
                        <i class="fas fa-save me-2"></i> Save Scores
                    </button>
                </div>
            </div>
            <div class="card-body p-0">
                <div id="student_list_scores" class="table-responsive">
                    <div class="text-center py-5 text-muted">
                        <img src="https://cdn-icons-png.flaticon.com/512/7486/7486803.png" alt="Select" style="width: 64px; opacity: 0.5;" class="mb-3">
                        <p class="mb-0">Select a Subject and Assessment to begin grading.</p>
                    </div>
                </div>
            </div>
        </div>
    </form>
</main>

<script>
// Handle Assessment Selection
function selectAssessment(btn, value, max) {
    const subjectSelect = document.getElementById('subject_select_scores');
    if (!subjectSelect.value) {
        alert("Please select a Subject first.");
        subjectSelect.focus();
        return;
    }

    // Set Hidden Input
    document.getElementById('assessment_type').value = value;
    document.getElementById('max_marks').value = max;
    document.getElementById('max_marks_display').innerText = 'Max: ' + max;
    
    // UI Active State
    document.querySelectorAll('.assessment-tab').forEach(b => {
        b.classList.remove('active', 'btn-primary');
        b.classList.add('btn-outline-primary', 'bg-white');
    });
    btn.classList.remove('btn-outline-primary', 'bg-white');
    btn.classList.add('active', 'btn-primary');
    
    // Load Data
    loadStudents('scores');
}

// Render tabs is no longer needed dynamically as they are static, 
// but we might need to reset them if context changes? 
// No, standard connection means they are always valid.
function renderAssessmentTabs() {
    // Legacy function placeholder if called by onchange
    // We might want to Reset the selected tab if subject changes?
    // Let's keep the current selection active if compatible, or just reload data.
    // If we just reload data, and assessment is already selected, it works!
     const currentAssess = document.getElementById('assessment_type').value;
     if(currentAssess) {
         loadStudents('scores');
     }
}

function updateMaxMarks() {
    // Handled by tab click
}

function loadStudents(type) {
    const selectId = type === 'scores' ? 'subject_select_scores' : 'subject_select_att';
    const listId = type === 'scores' ? 'student_list_scores' : 'student_list_att';
    const btnId = type === 'scores' ? 'btn_save_scores' : 'btn_save_att';
    
    const select = document.getElementById(selectId);
    const option = select.options[select.selectedIndex];
    
    if (!option.value) {
        document.getElementById(listId).innerHTML = '<div class="text-center py-5 text-muted"><p>Please select a subject.</p></div>';
        document.getElementById(btnId).style.display = 'none';
        return;
    }
    
    if (type === 'scores') {
        const assessType = document.getElementById('assessment_type').value;
        if(!assessType) {
             document.getElementById(listId).innerHTML = '<div class="text-center py-5 text-muted"><i class="fas fa-clipboard-list fa-2x mb-3 text-secondary opacity-50"></i><p>Select an assessment tab to view students.</p></div>';
             return;
        }
    }
    
    const dept = option.getAttribute('data-dept');
    const sem = option.getAttribute('data-sem');
    const subCode = option.value;
    
    // Params for API
    let apiParams = `dept=${dept}&sem=${sem}&subject_code=${subCode}`;
    
    if (type === 'scores') {
        const assessType = document.getElementById('assessment_type').value;
        apiParams += `&type=scores&assessment_type=${assessType}`;
    } else {
        apiParams += `&type=attendance`; 
    }
    
    // Loading State
    document.getElementById(listId).innerHTML = '<div class="text-center py-5"><div class="spinner-border text-primary" role="status"></div><p class="mt-2 text-muted fw-bold">Loading Class Data...</p></div>';

    // Fetch via fetch API
    fetch(`api_get_students.php?${apiParams}`)
        .then(response => response.json())
        .then(data => {
            if(data.length === 0) {
                document.getElementById(listId).innerHTML = '<div class="alert alert-warning m-3">No students found for this class.</div>';
                document.getElementById(btnId).style.display = 'none';
                return;
            }

            let html = '<table class="table table-hover align-middle mb-0">';
            if (type === 'scores') {
                html += `
                <thead class="bg-light sticky-top" style="z-index: 1;">
                    <tr>
                        <th class="ps-4 text-secondary text-uppercase text-xs fw-bold" style="width:15%">Roll No</th>
                        <th class="text-secondary text-uppercase text-xs fw-bold">Student Name</th>
                        <th class="text-secondary text-uppercase text-xs fw-bold" style="width:25%">Marks Obtained</th>
                    </tr>
                </thead>
                <tbody>`;
                
                data.forEach(student => {
                    const val = student.marks_obtained !== undefined ? student.marks_obtained : '';
                    // Generate a color avatar based on name
                    const initial = student.name.charAt(0);
                    const colors = ['primary', 'success', 'danger', 'warning', 'info', 'dark'];
                    const color = colors[student.id % colors.length];
                    
                    html += `
                        <tr>
                            <td class="ps-4 font-monospace small text-muted fw-bold">${student.roll_number}</td>
                            <td>
                                <div class="d-flex align-items-center">
                                    <div class="avatar-circle bg-${color} bg-opacity-10 text-${color} me-3 fw-bold rounded-circle d-flex align-items-center justify-content-center" style="width: 32px; height: 32px;">
                                        ${initial}
                                    </div>
                                    <div>
                                        <div class="fw-bold text-dark">${student.name}</div>
                                        <div class="text-xs text-muted">${student.year}</div>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <div class="input-group input-group-sm">
                                    <input type="number" step="1" name="marks[${student.id}]" value="${val}" 
                                           class="form-control form-control-lg fw-bold text-primary border-primary bg-light focus-white" 
                                           placeholder="-" min="0" max="100" style="max-width: 100px;">
                                    <span class="input-group-text bg-white text-muted border-start-0">/ ${document.getElementById('max_marks').value}</span>
                                </div>
                            </td>
                        </tr>
                    `;
                });
            } else {
                 // ... (attendance logic unchanged if needed)
            }
            html += '</tbody></table>';
            
            document.getElementById(listId).innerHTML = html;
            document.getElementById(btnId).style.display = 'block';
        })
        .catch(err => {
            console.error(err);
            document.getElementById(listId).innerHTML = '<div class="alert alert-danger m-3">Error loading students. Please try again.</div>';
        });
}
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
