<?php
// teacher/apply_teacher_leave.php - Teacher Leave Application
require_once '../includes/db_connect.php';
check_login(['teacher']);

$teacher_id = $_SESSION['profile_id'];
$teacher_name = $_SESSION['user_name'];

// Fetch teacher info
$t_query = $conn->query("SELECT * FROM teachers WHERE teacher_id = $teacher_id");
$teacher = $t_query->fetch_assoc();
$teacher_role = $teacher['teacher_role'] ?? 'Teacher';
$department = $teacher['department'];

// Handle form submission
$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_request'])) {
    if (!verify_csrf_token($_POST['csrf_token'])) {
        $error = "Invalid request. Please try again.";
    } else {
        $request_type = sanitize_input($_POST['request_type']);
        $from_date = sanitize_input($_POST['from_date']);
        $to_date = sanitize_input($_POST['to_date']);
        $reason = sanitize_input($_POST['reason']);
        
        // Validation
        if (empty($request_type) || empty($from_date) || empty($to_date) || empty($reason)) {
            $error = "All fields are required.";
        } elseif (strtotime($to_date) < strtotime($from_date)) {
            $error = "End date cannot be before start date.";
        } elseif (strtotime($from_date) < strtotime(date('Y-m-d'))) {
            $error = "Cannot apply for leave in the past.";
        } else {
            // Insert request - applicant_type = 'Teacher'
            $stmt = $conn->prepare("INSERT INTO leave_requests (applicant_type, teacher_id, request_type, from_date, to_date, reason, status, submitted_at) VALUES ('Teacher', ?, ?, ?, ?, ?, 'Pending', NOW())");
            $stmt->bind_param("issss", $teacher_id, $request_type, $from_date, $to_date, $reason);
            
            if ($stmt->execute()) {
                $success = "Your leave request has been submitted successfully.";
                if ($teacher_role == 'HOD' || $teacher_role == 'Principal') {
                    $success .= " It will be reviewed by the Principal.";
                } else {
                    $success .= " It will be reviewed by your Department HOD, then the Principal.";
                }
                $_POST = array();
            } else {
                $error = "Failed to submit request. Please try again.";
            }
            $stmt->close();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Apply Leave - Chendhuran SIS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;800&display=swap" rel="stylesheet">
    <link href="../includes/css/styles.css" rel="stylesheet">
</head>
<body>
<?php include '../includes/sidebar.php'; ?>

<main class="main-content">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h3 class="fw-bold mb-1">Apply for Leave / On-Duty</h3>
            <p class="text-muted mb-0">
                <i class="fas fa-user me-1"></i> <?php echo htmlspecialchars($teacher_name); ?> • 
                <span class="badge bg-primary"><?php echo $teacher_role; ?></span>
            </p>
        </div>
        <a href="my_teacher_leaves.php" class="btn btn-outline-primary">
            <i class="fas fa-list me-2"></i> My Leave Requests
        </a>
    </div>

    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="fas fa-check-circle me-2"></i><?php echo $success; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <i class="fas fa-exclamation-circle me-2"></i><?php echo $error; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="alert alert-info border-0 shadow-sm mb-4">
        <div class="d-flex align-items-start">
            <i class="fas fa-info-circle me-3 mt-1 text-info"></i>
            <div>
                <strong>Approval Workflow:</strong>
                <ul class="mb-0 mt-2 ps-3">
                    <?php if ($teacher_role == 'HOD' || $teacher_role == 'Principal'): ?>
                        <li>Your request will be sent directly to the <strong>Principal</strong> for approval</li>
                    <?php else: ?>
                        <li>Your request will be sent to your <strong>Department HOD</strong></li>
                        <li>If approved by HOD, it will be forwarded to the <strong>Principal</strong> for final approval</li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-8">
            <div class="glass-card">
                <div class="card-header bg-white border-bottom">
                    <h6 class="fw-bold mb-0">
                        <i class="fas fa-file-alt me-2 text-primary"></i> Leave Request Details
                    </h6>
                </div>
                <div class="card-body p-4">
                    <form method="POST" action="" id="leaveForm">
                        <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                        
                        <div class="mb-4">
                            <label class="form-label fw-semibold">Request Type <span class="text-danger">*</span></label>
                            <select name="request_type" class="form-select form-select-lg" required>
                                <option value="">Select request type</option>
                                <option value="Medical Leave">Medical Leave</option>
                                <option value="Personal Leave">Personal Leave (Casual Leave)</option>
                                <option value="On-Duty">On-Duty (Official Work)</option>
                            </select>
                        </div>

                        <div class="row mb-4">
                            <div class="col-md-6">
                                <label class="form-label fw-semibold">From Date <span class="text-danger">*</span></label>
                                <input type="date" name="from_date" class="form-control form-control-lg" 
                                       min="<?php echo date('Y-m-d'); ?>" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-semibold">To Date <span class="text-danger">*</span></label>
                                <input type="date" name="to_date" class="form-control form-control-lg" 
                                       min="<?php echo date('Y-m-d'); ?>" required>
                            </div>
                        </div>

                        <div class="mb-4">
                            <label class="form-label fw-semibold">Reason <span class="text-danger">*</span></label>
                            <textarea name="reason" class="form-control" rows="5" 
                                      placeholder="Please provide a detailed reason for your leave request..." 
                                      required></textarea>
                            <small class="text-muted">Minimum 20 characters</small>
                        </div>

                        <div class="d-grid gap-2 d-md-flex justify-content-md-between">
                            <a href="teacher_dashboard.php" class="btn btn-outline-secondary">
                                <i class="fas fa-arrow-left me-2"></i> Cancel
                            </a>
                            <button type="submit" name="submit_request" class="btn btn-primary btn-lg px-5">
                                <i class="fas fa-paper-plane me-2"></i> Submit Leave Request
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="glass-card">
                <div class="card-header bg-white border-bottom">
                    <h6 class="fw-bold mb-0">
                        <i class="fas fa-question-circle me-2 text-primary"></i> Leave Types
                    </h6>
                </div>
                <div class="card-body">
                    <h6 class="fw-semibold mb-2">Medical Leave</h6>
                    <p class="text-muted small mb-3">For health-related absences. Medical certificate required for leaves exceeding 2 days.</p>
                    
                    <h6 class="fw-semibold mb-2">Personal Leave</h6>
                    <p class="text-muted small mb-3">Casual leave for personal matters, family events, or emergencies.</p>
                    
                    <h6 class="fw-semibold mb-2">On-Duty</h6>
                    <p class="text-muted small mb-3">For official college work, training, workshops, or conferences.</p>
                    
                    <hr class="my-3">
                    
                    <h6 class="fw-semibold mb-2"><i class="fas fa-exclamation-triangle text-warning me-2"></i>Important</h6>
                    <ul class="text-muted small ps-3 mb-0">
                        <li>Apply at least 1-2 days in advance</li>
                        <li>Ensure proper work delegation</li>
                        <li>Contact HOD for urgent cases</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.getElementById('leaveForm').addEventListener('submit', function(e) {
    const fromDate = new Date(document.querySelector('input[name="from_date"]').value);
    const toDate = new Date(document.querySelector('input[name="to_date"]').value);
    const reason = document.querySelector('textarea[name="reason"]').value;
    
    if (toDate < fromDate) {
        e.preventDefault();
        alert('End date cannot be before start date!');
        return false;
    }
    
    if (reason.length < 20) {
        e.preventDefault();
        alert('Please provide a more detailed reason (at least 20 characters)');
        return false;
    }
});

setTimeout(function() {
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        const bsAlert = new bootstrap.Alert(alert);
        bsAlert.close();
    });
}, 5000);
</script>
</body>
</html>
