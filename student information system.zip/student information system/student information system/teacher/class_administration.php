<?php
// teacher/class_administration.php - Unified Class Administration
require_once '../includes/db_connect.php';
check_login(['teacher']);

$teacher_id = $_SESSION['profile_id'];

// Check permissions
$t_role_query = $conn->query("SELECT teacher_role FROM teachers WHERE teacher_id = $teacher_id");
$t_role = ($t_role_query && $t_role_query->num_rows > 0) ? $t_role_query->fetch_assoc()['teacher_role'] : 'Teacher';

if ($t_role != 'Class Mentor' && $t_role != 'HOD' && $t_role != 'Principal') {
    // Redirect unauthorized users
    header("Location: teacher_dashboard.php");
    exit;
}

$view = $_GET['view'] ?? 'leaves';

// DEFINE CONSTANT TO PREVENT FRAGMENTS FROM RENDERING FULL PAGE
define('INCLUDED_AS_FRAGMENT', true);

// HANDLE AJAX REQUESTS (Before HTML Output)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($view == 'leaves') {
        require 'leave_approvals.php';
        exit;
    }
}

// Pre-Include Logic (for POST handling)
if ($view == 'leaves') {
    // leave_approvals checks managed by AJAX calls usually
} elseif ($view == 'grievances') {
   // We will include it in the body. It uses meta-refresh for redirects, so it's safe-ish.
   // But theoretically, logic should be separate. For now, removing top-level inclusion to avoid double run/output.
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Class Administration - Chendhuran SIS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;800&display=swap" rel="stylesheet">
    <link href="../includes/css/styles.css" rel="stylesheet">
    <style>
        .nav-pills .nav-link {
            color: #4b5563;
            font-weight: 500;
            padding: 0.75rem 1.5rem;
            border-radius: 0.5rem;
            transition: all 0.2s;
        }
        .nav-pills .nav-link:hover {
            background-color: #f3f4f6;
            color: #111827;
        }
        .nav-pills .nav-link.active {
            background-color: #4f46e5;
            color: white;
            box-shadow: 0 4px 6px -1px rgba(79, 70, 229, 0.1), 0 2px 4px -1px rgba(79, 70, 229, 0.06);
        }
        .fade-in {
            animation: fadeIn 0.3s ease-in-out;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>
<?php include '../includes/sidebar.php'; ?>

<main class="main-content">
    
    <!-- Page Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h3 class="fw-bold mb-1">Class Administration</h3>
            <p class="text-muted mb-0">
                <?php 
                if ($t_role == 'Principal') {
                    echo 'Manage staff leaves and grievances';
                } else {
                    echo 'Manage student leaves and grievances';
                }
                ?>
            </p>
        </div>
        <div class="text-end">
            <span class="badge bg-white text-secondary border px-3 py-2 fw-normal">
                <i class="fas fa-user-tag me-1 text-primary"></i> Role: <strong><?php echo $t_role; ?></strong>
            </span>
        </div>
    </div>

    <!-- Navigation Tabs -->
    <div class="card border-0 shadow-sm mb-4">
        <div class="card-body p-2">
            <ul class="nav nav-pills nav-fill">
                <li class="nav-item">
                    <a class="nav-link <?php echo $view == 'leaves' ? 'active' : ''; ?>" href="?view=leaves">
                        <i class="fas fa-user-clock me-2"></i> 
                        <?php echo ($t_role == 'Principal') ? 'Staff Leaves' : 'Student Leaves'; ?>
                    </a>
                </li>
                <?php if ($t_role == 'HOD' || $t_role == 'Principal'): ?>
                <li class="nav-item">
                    <a class="nav-link <?php echo $view == 'grievances' ? 'active' : ''; ?>" href="?view=grievances">
                        <i class="fas fa-exclamation-circle me-2"></i> Grievances
                    </a>
                </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>

    <!-- Content Area -->
    <div id="admin-content">
        <?php 
        if ($view == 'leaves') {
            require 'leave_approvals.php';
        } elseif ($view == 'grievances') {
            if ($t_role == 'HOD' || $t_role == 'Principal') {
                include 'grievance_list.php';
            } else {
                echo "<div class='alert alert-danger'>Access Denied. Mentors cannot manage grievances.</div>";
            }
        }
        ?>
    </div>

</main>
<?php if (!defined('INCLUDED_AS_FRAGMENT')): // Safety check if we end structure here, but class_admin is main file ? 
// class_administration.php is main file. 
?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php endif; ?>
