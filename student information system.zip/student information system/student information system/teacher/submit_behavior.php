<?php
// teacher/submit_behavior.php - Comprehensive Behavior Rating System
require_once '../includes/db_connect.php';
require_once '../includes/year_helpers.php';
check_login(['teacher']);

$teacher_id = $_SESSION['profile_id'];
$message = '';
$error = '';

// Handle behavior submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_behavior'])) {
    $subject_code = sanitize_input($_POST['subject_code']);
    $recorded_date = sanitize_input($_POST['recorded_date']);
    
    $success_count = 0;
    $error_count = 0;
    
    foreach($_POST['students'] as $student_id => $ratings) {
        $discipline = intval($ratings['discipline'] ?? 3);
        $participation = intval($ratings['participation'] ?? 3);
        $attendance_behavior = intval($ratings['attendance_behavior'] ?? 3);
        $assignment = intval($ratings['assignment'] ?? 3);
        $conduct = intval($ratings['conduct'] ?? 3);
        $remarks = sanitize_input($ratings['remarks'] ?? '');
        
        // Calculate overall score (average)
        $overall_score = round(($discipline + $participation + $attendance_behavior + $assignment + $conduct) / 5, 1);
        
        // Check if record exists for this student and date
        $check = $conn->prepare("SELECT behavior_id FROM student_behavior WHERE student_id = ? AND recorded_date = ?");
        $check->bind_param("is", $student_id, $recorded_date);
        $check->execute();
        $existing = $check->get_result();
        
        if ($existing->num_rows > 0) {
            // Update existing - Match actual schema
            $behavior_tag = 'Average';
            if ($overall_score >= 4.5) $behavior_tag = 'Excellent';
            elseif ($overall_score >= 3.5) $behavior_tag = 'Good';
            elseif ($overall_score >= 2.5) $behavior_tag = 'Average';
            elseif ($overall_score >= 1.5) $behavior_tag = 'Poor';
            else $behavior_tag = 'Disruptive';
            
            $stmt = $conn->prepare("UPDATE student_behavior SET 
                discipline_rating = ?, 
                participation_rating = ?, 
                attendance_behavior_rating = ?, 
                assignment_rating = ?, 
                conduct_rating = ?,
                behavior_tag = ?,
                teacher_id = ?,
                comments = ?
                WHERE student_id = ? AND recorded_date = ?");
            $stmt->bind_param("iiiisissis", $discipline, $participation, $attendance_behavior, 
                             $assignment, $conduct, $behavior_tag, $teacher_id, $remarks, 
                             $student_id, $recorded_date);
        } else {
            // Insert new - Match actual table schema
            // Determine behavior_tag based on overall_score
            $behavior_tag = 'Average';
            if ($overall_score >= 4.5) $behavior_tag = 'Excellent';
            elseif ($overall_score >= 3.5) $behavior_tag = 'Good';
            elseif ($overall_score >= 2.5) $behavior_tag = 'Average';
            elseif ($overall_score >= 1.5) $behavior_tag = 'Poor';
            else $behavior_tag = 'Disruptive';
            
            $stmt = $conn->prepare("INSERT INTO student_behavior 
                (student_id, discipline_rating, participation_rating, attendance_behavior_rating, 
                 assignment_rating, conduct_rating, teacher_id, recorded_date, behavior_tag, comments) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("iiiiiissss", $student_id, $discipline, $participation, 
                             $attendance_behavior, $assignment, $conduct, 
                             $teacher_id, $recorded_date, $behavior_tag, $remarks);
        }
        
        if ($stmt->execute()) {
            $success_count++;
        } else {
            $error_count++;
        }
    }
    
    if ($success_count > 0) {
        $message = "<div class='alert alert-success'>✓ Behavior ratings saved for $success_count student(s).</div>";
    }
    if ($error_count > 0) {
        $error = "<div class='alert alert-danger'>⚠ Failed to save ratings for $error_count student(s).</div>";
    }
}

// Determine Active Semesters
$active_year_query = $conn->query("SELECT * FROM academic_years WHERE is_active = 1 LIMIT 1");
$active_semesters = [];
if ($active_year_query && $active_year_query->num_rows > 0) {
    $active_year = $active_year_query->fetch_assoc();
    $start = new DateTime($active_year['start_date']);
    $end = new DateTime($active_year['end_date']);
    $today = new DateTime();
    
    if ($today >= $start && $today <= $end) {
        $total_days = $start->diff($end)->days;
        $elapsed_days = $start->diff($today)->days;
        $progress = $total_days > 0 ? ($elapsed_days / $total_days) : 0;
        
        if ($progress < 0.5) {
            $active_semesters = [1, 3, 5];
        } else {
            $active_semesters = [2, 4, 6];
        }
    }
}

// Get teacher's subjects (Active Semester Only)
$sem_list = !empty($active_semesters) ? implode(',', $active_semesters) : '0';
$subjects = $conn->query("SELECT * FROM subjects WHERE (assigned_teacher_id = $teacher_id OR teacher_id = $teacher_id) AND semester IN ($sem_list) ORDER BY subject_name");

// Get students if subject selected
$students = null;
$selected_subject = $_GET['subject'] ?? '';
$selected_date = $_GET['date'] ?? date('Y-m-d');
$already_rated = false;
$rated_count = 0;

if ($selected_subject) {
    $sub_details = $conn->query("SELECT * FROM subjects WHERE subject_code = '$selected_subject'")->fetch_assoc();
    if ($sub_details) {
        $dept = $sub_details['department'] ?? '';
        $sem = $sub_details['semester'] ?? 0;
        
        // Check if ratings already exist for this date
        $check_existing = $conn->query("
            SELECT COUNT(*) as count 
            FROM student_behavior sb
            JOIN students s ON sb.student_id = s.student_id
            WHERE s.department = '$dept' 
            AND s.semester = $sem 
            AND sb.recorded_date = '$selected_date'
            AND sb.teacher_id = $teacher_id
        ");
        $existing_data = $check_existing->fetch_assoc();
        $rated_count = $existing_data['count'];
        
        if ($rated_count > 0) {
            $already_rated = true;
            $message = "<div class='alert alert-info'><i class='fas fa-info-circle me-2'></i>You have already rated <strong>$rated_count student(s)</strong> for this date. Ratings shown below are from your previous submission.</div>";
        }
        
        $students = $conn->query("SELECT * FROM students WHERE department = '$dept' AND semester = $sem ORDER BY roll_number");
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Behavior Assessment - Chendhuran SIS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="../includes/css/styles.css" rel="stylesheet">
    <style>
        .star-rating {
            display: inline-flex;
            gap: 5px;
            font-size: 1.2rem;
        }
        .star-rating input[type="radio"] {
            display: none;
        }
        .star-rating label {
            cursor: pointer;
            color: #ddd;
            transition: color 0.2s;
        }
        .star-rating input:checked ~ label,
        .star-rating label:hover,
        .star-rating label:hover ~ label {
            color: #ffc107;
        }
        .rating-card {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        .rating-row {
            display: grid;
            grid-template-columns: 150px 1fr 300px;
            gap: 15px;
            align-items: center;
            padding: 10px 0;
            border-bottom: 1px solid #dee2e6;
        }
        .rating-row:last-child {
            border-bottom: none;
        }
    </style>
</head>
<body>
<?php include '../includes/sidebar.php'; ?>

<main class="main-content">
    <div class="page-header">
        <div>
            <h4 class="mb-1"><i class="fas fa-star me-2"></i> Student Behavior Assessment</h4>
            <p class="text-muted mb-0 text-sm">Rate student behavior across 5 categories</p>
        </div>
    </div>

    <?php echo $message . $error; ?>

    <!-- Subject Selection -->
    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" class="row g-3 align-items-end">
                <div class="col-md-5">
                    <label class="form-label fw-bold">Select Subject</label>
                    <select name="subject" class="form-select" required onchange="this.form.submit()">
                        <option value="">-- Choose Subject --</option>
                        <?php while($sub = $subjects->fetch_assoc()): 
                            $year_label = get_year_label(get_year_from_semester($sub['semester']));
                        ?>
                            <option value="<?php echo $sub['subject_code']; ?>" 
                                    <?php if($selected_subject == $sub['subject_code']) echo 'selected'; ?>>
                                <?php echo $sub['subject_name']; ?> (<?php echo $year_label; ?> - Sem <?php echo $sub['semester']; ?>)
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-bold">Date</label>
                    <input type="date" name="date" class="form-control" value="<?php echo htmlspecialchars($selected_date); ?>" required>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100">Load Students</button>
                </div>
            </form>
        </div>
    </div>

    <?php if ($selected_subject && $students && $students->num_rows > 0): ?>
    <!-- Behavior Rating Form -->
    <form method="POST">
        <input type="hidden" name="subject_code" value="<?php echo $selected_subject; ?>">
        <input type="hidden" name="recorded_date" value="<?php echo $selected_date; ?>">
        <input type="hidden" name="submit_behavior" value="1">

        <div class="card">
            <div class="card-header bg-primary text-white">
                <h6 class="mb-0">Rate <?php echo $students->num_rows; ?> Students</h6>
            </div>
            <div class="card-body">
                <div class="alert alert-info mb-4">
                    <strong>Rating Categories:</strong> 1 = Poor | 2 = Below Average | 3 = Average | 4 = Good | 5 = Excellent
                </div>

                <?php while($student = $students->fetch_assoc()): 
                    // Get existing ratings if any
                    $existing_query = $conn->query("SELECT * FROM student_behavior WHERE student_id = {$student['student_id']} AND recorded_date = '$selected_date'");
                    $existing = $existing_query->num_rows > 0 ? $existing_query->fetch_assoc() : null;
                ?>
                <div class="rating-card">
                    <h6 class="fw-bold mb-3">
                        <i class="fas fa-user-circle me-2 text-primary"></i>
                        <?php echo htmlspecialchars($student['name']); ?> 
                        <small class="text-muted">(<?php echo $student['roll_number']; ?>)</small>
                    </h6>

                    <div class="rating-row">
                        <label class="fw-medium">Discipline:</label>
                        <div class="star-rating">
                            <?php for($i=5; $i>=1; $i--): ?>
                                <input type="radio" 
                                       id="disc_<?php echo $student['student_id']; ?>_<?php echo $i; ?>" 
                                       name="students[<?php echo $student['student_id']; ?>][discipline]" 
                                       value="<?php echo $i; ?>"
                                       <?php if(($existing['discipline_rating'] ?? 3) == $i) echo 'checked'; ?>>
                                <label for="disc_<?php echo $student['student_id']; ?>_<?php echo $i; ?>"><i class="fas fa-star"></i></label>
                            <?php endfor; ?>
                        </div>
                        <small class="text-muted">Follows rules, respectful behavior</small>
                    </div>

                    <div class="rating-row">
                        <label class="fw-medium">Participation:</label>
                        <div class="star-rating">
                            <?php for($i=5; $i>=1; $i--): ?>
                                <input type="radio" 
                                       id="part_<?php echo $student['student_id']; ?>_<?php echo $i; ?>" 
                                       name="students[<?php echo $student['student_id']; ?>][participation]" 
                                       value="<?php echo $i; ?>"
                                       <?php if(($existing['participation_rating'] ?? 3) == $i) echo 'checked'; ?>>
                                <label for="part_<?php echo $student['student_id']; ?>_<?php echo $i; ?>"><i class="fas fa-star"></i></label>
                            <?php endfor; ?>
                        </div>
                        <small class="text-muted">Active in class discussions</small>
                    </div>

                    <div class="rating-row">
                        <label class="fw-medium">Attendance:</label>
                        <div class="star-rating">
                            <?php for($i=5; $i>=1; $i--): ?>
                                <input type="radio" 
                                       id="att_<?php echo $student['student_id']; ?>_<?php echo $i; ?>" 
                                       name="students[<?php echo $student['student_id']; ?>][attendance_behavior]" 
                                       value="<?php echo $i; ?>"
                                       <?php if(($existing['attendance_behavior_rating'] ?? 3) == $i) echo 'checked'; ?>>
                                <label for="att_<?php echo $student['student_id']; ?>_<?php echo $i; ?>"><i class="fas fa-star"></i></label>
                            <?php endfor; ?>
                        </div>
                        <small class="text-muted">Punctuality and presence</small>
                    </div>

                    <div class="rating-row">
                        <label class="fw-medium">Assignments:</label>
                        <div class="star-rating">
                            <?php for($i=5; $i>=1; $i--): ?>
                                <input type="radio" 
                                       id="assign_<?php echo $student['student_id']; ?>_<?php echo $i; ?>" 
                                       name="students[<?php echo $student['student_id']; ?>][assignment]" 
                                       value="<?php echo $i; ?>"
                                       <?php if(($existing['assignment_rating'] ?? 3) == $i) echo 'checked'; ?>>
                                <label for="assign_<?php echo $student['student_id']; ?>_<?php echo $i; ?>"><i class="fas fa-star"></i></label>
                            <?php endfor; ?>
                        </div>
                        <small class="text-muted">Completion and quality</small>
                    </div>

                    <div class="rating-row">
                        <label class="fw-medium">Overall Conduct:</label>
                        <div class="star-rating">
                            <?php for($i=5; $i>=1; $i--): ?>
                                <input type="radio" 
                                       id="conduct_<?php echo $student['student_id']; ?>_<?php echo $i; ?>" 
                                       name="students[<?php echo $student['student_id']; ?>][conduct]" 
                                       value="<?php echo $i; ?>"
                                       <?php if(($existing['conduct_rating'] ?? 3) == $i) echo 'checked'; ?>>
                                <label for="conduct_<?php echo $student['student_id']; ?>_<?php echo $i; ?>"><i class="fas fa-star"></i></label>
                            <?php endfor; ?>
                        </div>
                        <small class="text-muted">General classroom behavior</small>
                    </div>

                    <div class="mt-3">
                        <label class="form-label fw-medium">Comments (Optional):</label>
                        <textarea name="students[<?php echo $student['student_id']; ?>][remarks]" 
                                  class="form-control form-control-sm" 
                                  rows="2" 
                                  placeholder="Any specific notes or observations..."><?php echo htmlspecialchars($existing['remarks'] ?? ''); ?></textarea>
                    </div>
                </div>
                <?php endwhile; ?>

                <div class="d-grid gap-2 mt-4">
                    <?php if($already_rated): ?>
                    <button type="submit" class="btn btn-warning btn-lg">
                        <i class="fas fa-edit me-2"></i> Update Existing Ratings (<?php echo $rated_count; ?> students)
                    </button>
                    <small class="text-muted text-center mt-2">
                        <i class="fas fa-info-circle me-1"></i> You have already submitted ratings for this date. Clicking will update the existing ratings.
                    </small>
                    <?php else: ?>
                    <button type="submit" class="btn btn-success btn-lg">
                        <i class="fas fa-save me-2"></i> Save All Behavior Ratings
                    </button>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </form>
    <?php elseif($selected_subject): ?>
    <div class="alert alert-warning">
        <i class="fas fa-info-circle me-2"></i> No students found for this subject.
    </div>
    <?php endif; ?>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
