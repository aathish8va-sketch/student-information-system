<?php
// teacher/grievance_list.php - Enhanced Grievance Management
require_once '../includes/db_connect.php';
check_login(['teacher', 'admin']);

$user_role = $_SESSION['role'];
$teacher_id = $_SESSION['profile_id'] ?? 0;
$my_teacher_role = ''; // Initialize to avoid warnings for Admin

// Filter Logic
// Filter Logic
$dept_filter = "";

if ($user_role == 'teacher') {
    // 1. Get Teacher Details (Role & Dept)
    $stmt = $conn->prepare("SELECT department, teacher_role FROM teachers WHERE teacher_id = ?");
    $stmt->bind_param("i", $teacher_id);
    $stmt->execute();
    $res = $stmt->get_result();
    $t_data = $res->fetch_assoc();
    $my_dept = $t_data['department'];
    $my_teacher_role = $t_data['teacher_role'];
    $my_name = $conn->real_escape_string($_SESSION['user_name']);

    // 2. Build Where Clauses
    // Always show grievances assigned specifically to this teacher
    $conditions = ["g.assigned_to = '$my_name'"];

    // If HOD, show grievances assigned to 'HOD' for their department
    if ($my_teacher_role == 'HOD') {
        $conditions[] = "(g.assigned_to = 'HOD' AND s.department = '$my_dept')";
        // Optional: Allow HOD to see ALL Pending grievances in their dept if unassigned? 
        // For now, stick to explicit assignment or "HOD" role assignment.
    }

    // If Principal, show ALL grievances (read-only view essentially)
    if ($my_teacher_role == 'Principal') {
        // Principal sees EVERYTHING generally
        $dept_filter = "WHERE 1=1"; 
    } else {
        $dept_filter = "WHERE (" . implode(' OR ', $conditions) . ")";
    }
    
} else {
    $dept_filter = "WHERE 1=1"; // Admin sees all
}

// Handle Status & Assignment Update
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_grievance'])) {
    $g_id = intval($_POST['grievance_id']);
    $new_status = sanitize_input($_POST['status']);
    $response = sanitize_input($_POST['response'] ?? '');
    
    // Determine what fields to update based on role
    if ($user_role == 'admin') {
        // Admin can update type (removed priority and assignment)
        $g_type = sanitize_input($_POST['grievance_type'] ?? '');
        
        // Set resolved_at if status is Closed
        $resolved_sql = "";
        if ($new_status == 'Closed' || $new_status == 'Resolved') {
            $resolved_sql = ", resolved_at=NOW()";
        }
        
        $sql = "UPDATE grievances SET status=?, admin_response=?, grievance_type=? $resolved_sql WHERE grievance_id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssi", $new_status, $response, $g_type, $g_id);
    } else {
        // HOD/Teacher updates - only status and response
        // Set resolved_at if status is Closed
        $resolved_sql = "";
        if ($new_status == 'Closed' || $new_status == 'Resolved') {
            $resolved_sql = ", resolved_at=NOW()";
        }
        
        $sql = "UPDATE grievances SET status=?, admin_response=? $resolved_sql WHERE grievance_id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssi", $new_status, $response, $g_id);
    }
    
    if($stmt->execute()) {
        echo "<meta http-equiv='refresh' content='0'>";
        exit;
    } else {
        $error = "Failed to update grievance: " . $stmt->error;
    }
    $stmt->close();
}

// Fetch Teachers for Admin (Grouped by Dept)
$teachers_by_dept = [];
if ($user_role == 'admin') {
    $teachers_res = $conn->query("SELECT name, department FROM teachers ORDER BY name");
    while($t = $teachers_res->fetch_assoc()) {
        $teachers_by_dept[$t['department']][] = $t;
    }
}

// Build department filter based on role
$dept_filter = "";
if($my_teacher_role == 'HOD') {
    // HOD sees only their department
    $my_dept_query = $conn->query("SELECT department FROM teachers WHERE teacher_id = {$_SESSION['profile_id']}");
    $my_dept = $my_dept_query->fetch_assoc()['department'];
    $dept_filter = "WHERE (g.department = '$my_dept' OR s.department = '$my_dept')";
} elseif($my_teacher_role == 'Principal') {
    // Principal sees all departments
    $dept_filter = "";
} else {
    // Regular teachers see nothing in this view
    $dept_filter = "WHERE 1=0";
}

// Add status filter
$status_filter = $_GET['status_filter'] ?? 'all';
if($status_filter != 'all') {
    // Determine if we need WHERE or AND
    $connector = (empty($dept_filter) || $dept_filter == "") ? "WHERE" : "AND";
    
    if($status_filter == 'resolved') {
        $dept_filter .= " $connector (g.status IN ('Resolved', 'Closed') OR g.status LIKE 'Resolved by%')";
    } elseif($status_filter == 'rejected') {
        $dept_filter .= " $connector (g.status LIKE '%Rejected%')";
    } else {
        $dept_filter .= " $connector g.status = '$status_filter'";
    }
}


// Fixed query with correct column names and teacher name resolution
$query = "SELECT g.*, 
                 COALESCE(s.name, t.name, 'Unknown') as student_name, 
                 COALESCE(s.roll_number, 'Faculty') as roll_number, 
                 COALESCE(s.department, g.department, 'N/A') as s_dept,
                 assigned_teacher.name as assigned_teacher_name
          FROM grievances g 
          LEFT JOIN students s ON g.student_id = s.student_id 
          LEFT JOIN teachers t ON g.teacher_id = t.teacher_id
          LEFT JOIN teachers assigned_teacher ON g.assigned_to = assigned_teacher.teacher_id
          $dept_filter 
          ORDER BY g.created_at DESC";
$result = $conn->query($query);

if (!$result) {
    die("Database Error: " . $conn->error . "<br>Query: $query");
}
?>
<?php if (!defined('INCLUDED_AS_FRAGMENT')): ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Grievance Desk - Chendhuran SIS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../includes/css/styles.css" rel="stylesheet">
    <style>
        .badge-critical { background: #dc2626; color: white; animation: pulse 2s infinite; }
        @keyframes pulse { 0% { opacity: 1; } 50% { opacity: 0.7; } 100% { opacity: 1; } }
        .action-form { display: none; }
        .action-form.show { display: block; }
    </style>
</head>
<body>
<?php include '../includes/sidebar.php'; ?>

<main class="main-content">
<?php endif; ?>

<?php if (defined('INCLUDED_AS_FRAGMENT')): ?>
<div class="fade-in">
<?php 
// Display any errors
if(isset($error)) {
    echo "<div class='alert alert-danger'><i class='fas fa-exclamation-circle me-2'></i>" . htmlspecialchars($error) . "</div>";
}
?>
<?php endif; ?>
    <div class="glass-header d-flex justify-content-between align-items-center">
        <div>
            <h4 class="fw-bold mb-1">Grievance Resolution Desk</h4>
            <p class="text-muted mb-0 small">Manage and track issues raised by students/staff.</p>
        </div>
        <div class="d-flex gap-2">
            <?php if($user_role == 'admin'): ?>
                <a href="../admin/admin_dashboard.php" class="btn btn-outline-secondary btn-sm"><i class="fas fa-arrow-left me-2"></i>Dashboard</a>
                <span class="badge bg-dark align-self-center">Admin Mode</span>
            <?php endif; ?>
        </div>
    </div>
    
    <?php
    // Get filter counts
    $pending_count = $resolved_count = $rejected_count = 0;
    if($my_teacher_role == 'HOD') {
        $pending_count = $conn->query("SELECT COUNT(*) FROM grievances WHERE department='$my_dept' AND status='Pending'")->fetch_row()[0];
        $resolved_count = $conn->query("SELECT COUNT(*) FROM grievances WHERE department='$my_dept' AND (status IN ('Resolved','Closed') OR status LIKE 'Resolved by%')")->fetch_row()[0];
        $rejected_count = $conn->query("SELECT COUNT(*) FROM grievances WHERE department='$my_dept' AND status LIKE '%Rejected%'")->fetch_row()[0];
    }
    $status_filter = $_GET['status_filter'] ?? 'all';
    ?>
    
    <!-- Filter Buttons -->
    <div class="d-flex justify-content-between align-items-center mb-3">
        <div class="btn-group" role="group">
            <a href="?view=grievances&status_filter=Pending" class="btn <?php echo $status_filter=='Pending'?'btn-warning':'btn-outline-warning'; ?>">
                <i class="fas fa-clock me-1"></i> Pending
                <?php if($pending_count > 0): ?>
                    <span class="badge bg-dark ms-1"><?php echo $pending_count; ?></span>
                <?php endif; ?>
            </a>
            <a href="?view=grievances&status_filter=resolved" class="btn <?php echo $status_filter=='resolved'?'btn-success':'btn-outline-success'; ?>">
                <i class="fas fa-check-circle me-1"></i> Resolved
                <?php if($resolved_count > 0): ?>
                    <span class="badge bg-dark ms-1"><?php echo $resolved_count; ?></span>
                <?php endif; ?>
            </a>
            <a href="?view=grievances&status_filter=rejected" class="btn <?php echo $status_filter=='rejected'?'btn-danger':'btn-outline-danger'; ?>">
                <i class="fas fa-times-circle me-1"></i> Rejected
                <?php if($rejected_count > 0): ?>
                    <span class="badge bg-dark ms-1"><?php echo $rejected_count; ?></span>
                <?php endif; ?>
            </a>
            <a href="?view=grievances&status_filter=all" class="btn <?php echo $status_filter=='all'?'btn-primary':'btn-outline-primary'; ?>">
                <i class="fas fa-list me-1"></i> All
            </a>
        </div>
    </div>

    <?php if($result && $result->num_rows > 0): ?>
        <div class="row">
        <?php while($row = $result->fetch_assoc()): 
             // Determine status color and border
             $status_config = match($row['status']) {
                'Pending' => ['color' => 'warning', 'border' => '#F59E0B', 'icon' => 'clock'],
                'In Progress' => ['color' => 'info', 'border' => '#3B82F6', 'icon' => 'spinner'],
                'Resolved', 'Closed' => ['color' => 'success', 'border' => '#10B981', 'icon' => 'check-circle'],
                'Rejected' => ['color' => 'danger', 'border' => '#EF4444', 'icon' => 'times-circle'],
                default => ['color' => 'secondary', 'border' => '#6B7280', 'icon' => 'info-circle']
            };
            $submitter_name = $row['student_name'] ?? 'Unknown';
            $submitter_type = ($row['roll_number'] != 'Faculty') ? 'Student' : 'Staff';
        ?>
            <div class="col-12 mb-2">
                <div class="card border-0 shadow-sm" style="border-left: 4px solid <?php echo $status_config['border']; ?> !important;">
                    <div class="card-body p-2">
                        <!-- Header Section -->
                        <div class="d-flex justify-content-between align-items-start mb-1">
                            <div class="flex-grow-1">
                                <div class="d-flex align-items-center gap-1 mb-1">
                                    <span class="badge bg-<?php echo $status_config['color']; ?>" style="font-size: 0.7rem; padding: 0.2rem 0.4rem;">
                                        <i class="fas fa-<?php echo $status_config['icon']; ?> me-1"></i>
                                        <?php echo htmlspecialchars($row['status'] ?: 'Pending'); ?>
                                    </span>
                                    <span class="badge bg-light text-dark border" style="font-size: 0.7rem; padding: 0.2rem 0.4rem;">
                                        <?php echo htmlspecialchars($row['grievance_type'] ?? 'General'); ?>
                                    </span>
                                    <?php if(!empty($row['subject_code'])): ?>
                                    <span class="badge bg-light text-secondary border" style="font-size: 0.7rem; padding: 0.2rem 0.4rem;">
                                        <?php echo htmlspecialchars($row['subject_code']); ?>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <small class="text-muted" style="font-size: 0.7rem;">#<?php echo $row['grievance_id']; ?></small>
                        </div>

                        <!-- Submitter Info -->
                        <div class="d-flex align-items-center gap-1 mb-1 text-muted" style="font-size: 0.75rem;">
                            <i class="fas fa-user-circle" style="font-size: 0.8rem;"></i>
                            <strong class="text-dark"><?php echo htmlspecialchars($submitter_name); ?></strong>
                            <span class="badge bg-light text-dark" style="font-size: 0.65rem; padding: 0.15rem 0.3rem;"><?php echo $submitter_type; ?></span>
                            <span>•</span>
                            <span><?php echo htmlspecialchars($row['s_dept']); ?></span>
                            <?php if($row['roll_number'] != 'Faculty'): ?>
                            <span>•</span>
                            <span><?php echo htmlspecialchars($row['roll_number']); ?></span>
                            <?php endif; ?>
                            <span>•</span>
                            <span><?php echo date('d M y', strtotime($row['created_at'])); ?></span>
                        </div>

                        <!-- Message Section -->
                        <div class="bg-light rounded p-2 mb-1" style="font-size: 0.8rem; line-height: 1.4;">
                            <?php echo htmlspecialchars($row['message']); ?>
                        </div>

                        <!-- Admin Response (if exists) -->
                        <?php if(!empty($row['admin_response'])): ?>
                        <div class="alert alert-info mb-1 py-1 px-2" style="font-size: 0.75rem;">
                            <div class="d-flex gap-1">
                                <i class="fas fa-reply" style="font-size: 0.7rem; margin-top: 2px;"></i>
                                <div class="flex-grow-1">
                                    <strong>Response:</strong>
                                    <?php echo htmlspecialchars($row['admin_response']); ?>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>

                        <!-- Resolution Form - Always Visible for Pending -->
                        <?php if($my_teacher_role == 'HOD' && ($row['status'] == 'Pending' || $row['status'] == 'In Progress')): ?>
                        <div class="border-top pt-2 mt-1" style="background: #f8f9fa; margin: -0.5rem; margin-top: 0.25rem; padding: 0.5rem !important;">
                            <form method="POST">
                                <input type="hidden" name="grievance_id" value="<?php echo $row['grievance_id']; ?>">
                                <input type="hidden" name="update_grievance" value="1">
                                
                                <div class="row g-1">
                                    <!-- Quick Action Buttons -->
                                    <div class="col-12">
                                        <label class="form-label fw-bold mb-1" style="font-size: 0.75rem;">
                                            <i class="fas fa-gavel me-1"></i> Action
                                        </label>
                                        <div class="d-grid gap-1">
                                            <input type="radio" class="btn-check" name="status" id="resolve<?php echo $row['grievance_id']; ?>" value="Resolved" required>
                                            <label class="btn btn-outline-success btn-sm" for="resolve<?php echo $row['grievance_id']; ?>" style="font-size: 0.8rem; padding: 0.3rem;">
                                                <i class="fas fa-check-circle me-1"></i> Resolve
                                            </label>
                                            
                                            <input type="radio" class="btn-check" name="status" id="progress<?php echo $row['grievance_id']; ?>" value="In Progress">
                                            <label class="btn btn-outline-info btn-sm" for="progress<?php echo $row['grievance_id']; ?>" style="font-size: 0.8rem; padding: 0.3rem;">
                                                <i class="fas fa-spinner me-1"></i> In Progress
                                            </label>
                                            
                                            <input type="radio" class="btn-check" name="status" id="reject<?php echo $row['grievance_id']; ?>" value="Rejected">
                                            <label class="btn btn-outline-danger btn-sm" for="reject<?php echo $row['grievance_id']; ?>" style="font-size: 0.8rem; padding: 0.3rem;">
                                                <i class="fas fa-times-circle me-1"></i> Reject
                                            </label>
                                        </div>
                                    </div>

                                    <!-- Response Textarea -->
                                    <div class="col-12">
                                        <label for="response<?php echo $row['grievance_id']; ?>" class="form-label fw-bold mb-1" style="font-size: 0.75rem;">
                                            <i class="fas fa-comment-dots me-1"></i> Response
                                        </label>
                                        <textarea 
                                            class="form-control form-control-sm" 
                                            id="response<?php echo $row['grievance_id']; ?>" 
                                            name="response" 
                                            rows="2" 
                                            placeholder="Your remarks..."
                                            required
                                            style="font-size: 0.8rem;"
                                        ><?php echo htmlspecialchars($row['admin_response'] ?? ''); ?></textarea>
                                    </div>

                                    <!-- Submit Button -->
                                    <div class="col-12">
                                        <button type="submit" class="btn btn-primary btn-sm w-100" style="font-size: 0.8rem; padding: 0.4rem;">
                                            <i class="fas fa-paper-plane me-1"></i> Submit
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>
        </div>
    <?php else: ?>
        <div class="card border-0 shadow-sm">
            <div class="card-body text-center py-5">
                <i class="fas fa-check-circle text-success fa-3x mb-3"></i>
                <p class="text-muted">No grievances found. All clear!</p>
            </div>
        </div>
    <?php endif; ?>
<?php if (defined('INCLUDED_AS_FRAGMENT')): ?>
</div>
<?php endif; ?>

<?php if (!defined('INCLUDED_AS_FRAGMENT')): ?>
</main>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php endif; ?>
