<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>404 Not Found - Chendhuran SIS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>body { background:#f8f9fa; height:100vh; display:flex; align-items:center; justify-content:center; }</style>
</head>
<body>
    <div class="text-center">
        <h1 class="display-1 fw-bold text-secondary">404</h1>
        <p class="fs-3">Page Not Found</p>
        <p class="lead">The page you are looking for does not exist.</p>
        <a href="index.php" class="btn btn-primary">Go Home</a>
    </div>
</body>
</html>
