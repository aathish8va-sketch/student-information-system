<?php
// admin_audit_logs.php - System Audit Viewer
require_once '../includes/db_connect.php';
check_login(['admin']);

// Pagination
$limit = 50;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$start = ($page - 1) * $limit;

// Fetch Logs
$tr_res = $conn->query("SELECT COUNT(*) FROM audit_logs");
$total_results = $tr_res ? $tr_res->fetch_row()[0] : 0;
$total_pages = ceil($total_results / $limit);

$sql = "SELECT a.*, u.email as user_email 
        FROM audit_logs a 
        LEFT JOIN users u ON a.user_id = u.user_id 
        ORDER BY a.created_at DESC LIMIT $start, $limit";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Audit Logs - Chendhuran SIS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="../includes/css/styles.css" rel="stylesheet">
</head>
<body>
<?php include '../includes/sidebar.php'; ?>

<main class="admin-main">
    <!-- Page Header -->
    <div class="page-header">
        <div>
            <h4 class="mb-1">System Audit Logs</h4>
            <p class="text-muted mb-0 text-sm">Track all system activities and user actions</p>
        </div>
        <div class="text-end">
            <span class="text-muted text-sm">Total Records: <?php echo number_format($total_results); ?></span>
        </div>
    </div>

    <!-- Results Info -->
    <div class="d-flex justify-content-between align-items-center mb-3">
        <span class="text-muted text-sm">Page <?php echo $page; ?> of <?php echo $total_pages; ?></span>
    </div>

    <!-- Data Table -->
    <div class="card">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th class="ps-4">ID</th>
                            <th>User</th>
                            <th>Action</th>
                            <th>Details</th>
                            <th>IP Address</th>
                            <th>Time</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($result && $result->num_rows > 0): ?>
                            <?php while($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td class="ps-4 text-muted"><?php echo $row['log_id']; ?></td>
                                <td class="fw-medium"><?php echo escape($row['user_email'] ?? 'System/Guest'); ?></td>
                                <td><span class="badge badge-soft-primary"><?php echo escape($row['action']); ?></span></td>
                                <td class="text-muted text-sm"><?php echo escape(substr($row['details'] ?? '', 0, 60)); ?><?php echo strlen($row['details'] ?? '') > 60 ? '...' : ''; ?></td>
                                <td><small class="text-muted font-monospace"><?php echo escape($row['ip_address']); ?></small></td>
                                <td class="text-muted text-sm"><?php echo date('M d, h:i A', strtotime($row['created_at'])); ?></td>
                            </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center py-5">
                                    <div class="empty-state">
                                        <i class="fas fa-history"></i>
                                        <p>No audit logs found</p>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Pagination -->
    <?php if($total_pages > 1): ?>
    <nav class="mt-4">
        <ul class="pagination justify-content-center">
            <li class="page-item <?php if($page <= 1) echo 'disabled'; ?>">
                <a class="page-link" href="?page=<?php echo $page - 1; ?>">Previous</a>
            </li>
            <?php for($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
                <li class="page-item <?php if($i == $page) echo 'active'; ?>">
                    <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                </li>
            <?php endfor; ?>
            <li class="page-item <?php if($page >= $total_pages) echo 'disabled'; ?>">
                <a class="page-link" href="?page=<?php echo $page + 1; ?>">Next</a>
            </li>
        </ul>
    </nav>
    <?php endif; ?>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
