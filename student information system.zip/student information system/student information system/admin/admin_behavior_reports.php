
<?php
// admin/admin_behavior_reports.php - Behavior Monitoring Dashboard
require_once '../includes/db_connect.php';
check_login(['admin']);

// Summary Stats
$total_assessments = $conn->query("SELECT COUNT(*) FROM student_behavior")->fetch_row()[0];
$students_assessed = $conn->query("SELECT COUNT(DISTINCT student_id) FROM student_behavior")->fetch_row()[0];

// Students Requiring Attention (Poor/Disruptive in last 30 days)
$at_risk = $conn->query("SELECT sb.*, s.name, s.roll_number, s.department, s.semester, t.name as teacher_name,
                         (sb.discipline_rating + sb.participation_rating + sb.attendance_behavior_rating + 
                          sb.assignment_rating + sb.conduct_rating) / 5 as avg_score
                         FROM student_behavior sb
                         JOIN students s ON sb.student_id = s.student_id
                         LEFT JOIN teachers t ON sb.teacher_id = t.teacher_id
                         WHERE sb.behavior_tag IN ('Poor', 'Disruptive')
                            AND sb.recorded_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
                         ORDER BY avg_score ASC, sb.recorded_date DESC
                         LIMIT 20");

// Recent Activity
$recent = $conn->query("SELECT sb.*, s.name, s.roll_number, s.department, t.name as teacher_name,
                        (sb.discipline_rating + sb.participation_rating + sb.attendance_behavior_rating + 
                         sb.assignment_rating + sb.conduct_rating) / 5 as avg_score
                        FROM student_behavior sb
                        JOIN students s ON sb.student_id = s.student_id
                        LEFT JOIN teachers t ON sb.teacher_id = t.teacher_id
                        ORDER BY sb.recorded_date DESC
                        LIMIT 10");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Behavior Monitoring - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../includes/css/styles.css" rel="stylesheet">
</head>
<body>
<?php include '../includes/sidebar.php'; ?>

<main class="admin-main">
    <div class="page-header">
        <div>
            <h4 class="mb-1"><i class="fas fa-user-shield me-2"></i>Behavior Monitoring</h4>
            <p class="text-muted mb-0 text-sm">Students requiring attention & recent activity</p>
        </div>
    </div>

    <!-- Summary Stats -->
    <div class="row g-4 mb-4">
        <div class="col-md-6">
            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="bg-primary bg-opacity-10 p-3 rounded me-3">
                            <i class="fas fa-clipboard-check fa-2x text-primary"></i>
                        </div>
                        <div>
                            <small class="text-muted text-uppercase">Total Assessments</small>
                            <h3 class="fw-bold mb-0"><?php echo $total_assessments; ?></h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="bg-warning bg-opacity-10 p-3 rounded me-3">
                            <i class="fas fa-users fa-2x text-warning"></i>
                        </div>
                        <div>
                            <small class="text-muted text-uppercase">Students Assessed</small>
                            <h3 class="fw-bold mb-0"><?php echo $students_assessed; ?></h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Students Requiring Attention -->
    <div class="card border-0 shadow-sm mb-4">
        <div class="card-header bg-white border-bottom">
            <h6 class="fw-bold mb-0 text-danger"><i class="fas fa-exclamation-triangle me-2"></i>Students Requiring Attention (Last 30 Days)</h6>
        </div>
        <div class="card-body p-0">
            <?php if($at_risk && $at_risk->num_rows > 0): ?>
            <div class="table-responsive">
                <table class="table table-hover mb-0 align-middle">
                    <thead class="table-light">
                        <tr>
                            <th class="ps-4">Student</th>
                            <th>Dept/Sem</th>
                            <th>Assessment Date</th>
                            <th>Rated By</th>
                            <th class="text-center">Avg Score</th>
                            <th>Tag</th>
                            <th>Key Issues</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($r = $at_risk->fetch_assoc()): ?>
                        <tr>
                            <td class="ps-4">
                                <div class="fw-bold"><?php echo htmlspecialchars($r['name']); ?></div>
                                <small class="text-muted"><?php echo $r['roll_number']; ?></small>
                            </td>
                            <td>
                                <span class="badge bg-light text-dark"><?php echo $r['department']; ?></span><br>
                                <small>Sem <?php echo $r['semester']; ?></small>
                            </td>
                            <td><?php echo date('M d, Y', strtotime($r['recorded_date'])); ?></td>
                            <td><?php echo htmlspecialchars($r['teacher_name'] ?? 'N/A'); ?></td>
                            <td class="text-center">
                                <span class="badge bg-danger"><?php echo number_format($r['avg_score'], 1); ?>/5</span>
                            </td>
                            <td>
                                <span class="badge bg-dark"><?php echo $r['behavior_tag']; ?></span>
                            </td>
                            <td>
                                <?php
                                $issues = [];
                                if($r['discipline_rating'] <= 2) $issues[] = 'Discipline';
                                if($r['participation_rating'] <= 2) $issues[] = 'Participation';
                                if($r['conduct_rating'] <= 2) $issues[] = 'Conduct';
                                echo !empty($issues) ? implode(', ', $issues) : '-';
                                ?>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="text-center py-5">
                <i class="fas fa-check-circle fa-3x text-success mb-3"></i>
                <p class="text-muted">No students requiring immediate attention!</p>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Recent Activity -->
    <div class="card border-0 shadow-sm">
        <div class="card-header bg-white border-bottom">
            <h6 class="fw-bold mb-0"><i class="fas fa-history me-2"></i>Recent Assessments</h6>
        </div>
        <div class="card-body p-0">
            <?php if($recent && $recent->num_rows > 0): ?>
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead class="table-light">
                        <tr>
                            <th class="ps-4">Student</th>
                            <th>Date</th>
                            <th>Teacher</th>
                            <th>Score</th>
                            <th>Tag</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($r = $recent->fetch_assoc()): 
                            $badge = match($r['behavior_tag']) {
                                'Excellent' => 'bg-success',
                                'Good' => 'bg-primary',
                                'Average' => 'bg-warning text-dark',
                                default => 'bg-danger'
                            };
                        ?>
                        <tr>
                            <td class="ps-4">
                                <div class="fw-medium"><?php echo htmlspecialchars($r['name']); ?></div>
                                <small class="text-muted"><?php echo $r['roll_number']; ?> • <?php echo $r['department']; ?></small>
                            </td>
                            <td><small><?php echo date('M d, Y', strtotime($r['recorded_date'])); ?></small></td>
                            <td><?php echo htmlspecialchars($r['teacher_name'] ?? 'N/A'); ?></td>
                            <td><span class="badge bg-light text-dark"><?php echo number_format($r['avg_score'], 1); ?>/5</span></td>
                            <td><span class="badge <?php echo $badge; ?>"><?php echo $r['behavior_tag']; ?></span></td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="text-center py-5">
                <i class="fas fa-star fa-3x text-muted mb-3"></i>
                <p class="text-muted">No behavior assessments recorded yet.</p>
            </div>
            <?php endif; ?>
        </div>
    </div>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
