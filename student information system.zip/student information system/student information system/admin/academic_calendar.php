<?php
// admin/academic_calendar.php - Academic Year & Holiday Management
require_once '../includes/db_connect.php';
check_login(['admin']);

// ==========================================
// 1. GLOBAL STATE & LOGIC
// ==========================================
$message = '';
$error = '';

// Get Active/Selected Academic Year
$default_year = $conn->query("SELECT * FROM academic_years WHERE is_active=1 LIMIT 1")->fetch_assoc();
$selected_year_id = isset($_GET['year']) ? intval($_GET['year']) : ($default_year['year_id'] ?? 0);

// Fetch Selected Year Data
$curr_year = null;
if($selected_year_id) {
    $curr_year = $conn->query("SELECT * FROM academic_years WHERE year_id=$selected_year_id")->fetch_assoc();
}

// ==========================================
// 2. ACTIONS
// ==========================================

// A. SAVE ACADEMIC YEAR DATES
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['save_year'])) {
    $y_start = sanitize_input($_POST['start_date']);
    $y_end = sanitize_input($_POST['end_date']);
    $y_id = intval($_POST['year_id']);
    
    if ($y_start && $y_end) {
        $stmt = $conn->prepare("UPDATE academic_years SET start_date=?, end_date=? WHERE year_id=?");
        $stmt->bind_param("ssi", $y_start, $y_end, $y_id);
        if($stmt->execute()) $message = "Academic Year schedule updated.";
        // Refresh data
        $curr_year['start_date'] = $y_start;
        $curr_year['end_date'] = $y_end;
    }
}

// A2. SAVE SEMESTER DATES (New Feature)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['save_semesters'])) {
    $odd_start = sanitize_input($_POST['odd_start']);
    $odd_end = sanitize_input($_POST['odd_end']);
    $even_start = sanitize_input($_POST['even_start']);
    $even_end = sanitize_input($_POST['even_end']);
    $year_name = sanitize_input($_POST['year_name']);
    
    // Naming Convention: "Odd Semester 2025-2026"
    $odd_name = "Odd Semester $year_name";
    $even_name = "Even Semester $year_name";
    
    // Update/Insert Odd
    $conn->query("DELETE FROM semester_dates WHERE period_name = '$odd_name'");
    $conn->query("INSERT INTO semester_dates (period_name, start_date, end_date, is_active) VALUES ('$odd_name', '$odd_start', '$odd_end', 0)");
    
    // Update/Insert Even
    $conn->query("DELETE FROM semester_dates WHERE period_name = '$even_name'");
    $conn->query("INSERT INTO semester_dates (period_name, start_date, end_date, is_active) VALUES ('$even_name', '$even_start', '$even_end', 0)");
    
    $message = "Semester dates for $year_name have been saved.";
}

// B. SET ACTIVE YEAR
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['set_active'])) {
    $y_id = intval($_POST['year_id']);
    $conn->query("UPDATE academic_years SET is_active=0"); // Reset all
    $conn->query("UPDATE academic_years SET is_active=1 WHERE year_id=$y_id"); // Set new
    $message = "Active Academic Year updated.";
    // Refresh to reflect change
    $default_year = $conn->query("SELECT * FROM academic_years WHERE is_active=1 LIMIT 1")->fetch_assoc();
    $curr_year = $conn->query("SELECT * FROM academic_years WHERE year_id=$y_id")->fetch_assoc();
}

// C. ADD HOLIDAY
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_holiday'])) {
    $h_date = sanitize_input($_POST['holiday_date']);
    $desc = sanitize_input($_POST['description']);
    
    // Validation: Check if date falls within year
    if ($curr_year && ($h_date < $curr_year['start_date'] || $h_date > $curr_year['end_date'])) {
        $error = "Warning: Date $h_date is outside the selected academic year range.";
    }
    
    // Insert anyway (allow flexibility but warn)
    $stmt = $conn->prepare("INSERT IGNORE INTO academic_holidays (holiday_date, description) VALUES (?, ?)");
    $stmt->bind_param("ss", $h_date, $desc);
    if($stmt->execute()) {
        if(!$error) $message = "Holiday added.";
    }
}

// D. DELETE HOLIDAY
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_holiday'])) {
    $hid = intval($_POST['holiday_id']);
    $conn->query("DELETE FROM academic_holidays WHERE holiday_id=$hid");
    $message = "Holiday deleted.";
}

// ==========================================
// 3. FETCH DATA
// ==========================================

// All Years
$all_years = $conn->query("SELECT * FROM academic_years ORDER BY year_name DESC");

// Holidays for selected year
$holidays_res = null;
$odd_sem = null;
$even_sem = null;
if ($curr_year) {
    $s = $curr_year['start_date'];
    $e = $curr_year['end_date'];
    $holidays_res = $conn->query("SELECT * FROM academic_holidays WHERE holiday_date BETWEEN '$s' AND '$e' ORDER BY holiday_date");

    // Fetch Semesters
    $y_name = $curr_year['year_name'];
    $odd_sem = $conn->query("SELECT * FROM semester_dates WHERE period_name = 'Odd Semester $y_name'")->fetch_assoc();
    $even_sem = $conn->query("SELECT * FROM semester_dates WHERE period_name = 'Even Semester $y_name'")->fetch_assoc();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Academic Calendar</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../includes/css/styles.css" rel="stylesheet">
</head>
<body>
<?php include '../includes/sidebar.php'; ?>

<main class="main-content">
    
    <!-- Header -->
    <div class="glass-header mb-4">
        <div class="d-flex justify-content-between align-items-center">
             <h4 class="fw-bold mb-0">Academic Calendar</h4>
        </div>
    </div>

    <div class="container-fluid">
        <?php if($message): ?><div class="alert alert-success alert-dismissible fade show"><?php echo $message; ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div><?php endif; ?>
        <?php if($error): ?><div class="alert alert-danger alert-dismissible fade show"><?php echo $error; ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div><?php endif; ?>

        <!-- HELP INFO -->
        <div class="alert alert-light border shadow-sm mb-4">
            <div class="d-flex gap-3 align-items-center">
                <i class="fas fa-info-circle text-primary fs-4"></i>
                <div>
                    <strong>How to allow attendance for a new academic year:</strong><br>
                    <small>1. Select the year (e.g. 2025-2026). 2. Verify Start/End Dates. 3. Click <strong>"Set as Current Active Year"</strong>.</small>
                </div>
            </div>
        </div>

        <!-- ROW 1: ACADEMIC YEAR CONFIGURATION (Full Width Horizontal) -->
        <div class="row g-4 mb-4">
            <div class="col-12">
                <div class="card shadow-sm border-0">
                    <div class="card-header bg-white fw-bold d-flex justify-content-between align-items-center">
                        <span><i class="fas fa-cog me-2 text-primary"></i>Year Configuration</span>
                        <?php if($curr_year && $curr_year['is_active']): ?>
                            <span class="badge bg-success"><i class="fas fa-check-circle me-1"></i>Active Year</span>
                        <?php endif; ?>
                    </div>
                    <div class="card-body">
                        <div class="row g-3 align-items-end">
                            <!-- Select Year -->
                            <div class="col-md-3">
                                <label class="small text-muted fw-bold mb-1">Select Year</label>
                                <div class="dropdown w-100">
                                    <button class="btn btn-outline-secondary w-100 dropdown-toggle d-flex justify-content-between align-items-center bg-white" type="button" data-bs-toggle="dropdown">
                                        <?php echo $curr_year ? $curr_year['year_name'] : 'Select Year'; ?>
                                    </button>
                                    <ul class="dropdown-menu w-100">
                                        <?php 
                                        $all_years->data_seek(0); 
                                        while($y = $all_years->fetch_assoc()): 
                                        ?>
                                        <li><a class="dropdown-item d-flex justify-content-between" href="?year=<?php echo $y['year_id']; ?>">
                                            <span><?php echo $y['year_name']; ?></span>
                                            <?php if($y['is_active']): ?><span class="badge bg-success">Active</span><?php endif; ?>
                                        </a></li>
                                        <?php endwhile; ?>
                                    </ul>
                                </div>
                            </div>

                            <?php if($curr_year): ?>
                            <!-- Config Form (Horizontal Inputs) -->
                            <div class="col-md-9">
                                <form method="POST" class="row g-3 align-items-end">
                                    <input type="hidden" name="year_id" value="<?php echo $curr_year['year_id']; ?>">
                                    
                                    <div class="col-md-3">
                                        <label class="small text-muted fw-bold mb-1">Start Date</label>
                                        <input type="date" name="start_date" class="form-control" value="<?php echo $curr_year['start_date']; ?>">
                                    </div>
                                    <div class="col-md-3">
                                        <label class="small text-muted fw-bold mb-1">End Date</label>
                                        <input type="date" name="end_date" class="form-control" value="<?php echo $curr_year['end_date']; ?>">
                                    </div>
                                    <div class="col-md-3">
                                        <button type="submit" name="save_year" class="btn btn-primary w-100">
                                            <i class="fas fa-save me-1"></i> Update
                                        </button>
                                    </div>
                                    <div class="col-md-3">
                                        <?php if(!$curr_year['is_active']): ?>
                                            <button type="submit" name="set_active" class="btn btn-outline-success w-100">
                                                <i class="fas fa-check me-1"></i> Set Active
                                            </button>
                                        <?php else: ?>
                                            <button type="button" class="btn btn-success w-100 disabled" disabled>
                                                <i class="fas fa-check-double me-1"></i> Active
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </form>
                            </div>
                            <?php else: ?>
                            <div class="col-md-9 d-flex align-items-center text-muted"> <i class="fas fa-arrow-left me-2"></i> Please select a year to configure dates.</div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ROW 2: Semesters & Holidays -->
        <div class="row g-4 mb-5">
            <!-- Semester Configuration -->
            <div class="col-md-4">
                <div class="card shadow-sm border-0 h-100">
                    <div class="card-header bg-white fw-bold">Semester Schedule</div>
                    <div class="card-body">
                         <?php if($curr_year): ?>
                        <form method="POST">
                            <input type="hidden" name="year_name" value="<?php echo $curr_year['year_name']; ?>">
                            
                            <h6 class="text-primary small fw-bold text-uppercase border-bottom pb-2 mb-3">Odd Semester</h6>
                            <div class="mb-2">
                                <label class="small text-muted">Start Date</label>
                                <input type="date" name="odd_start" class="form-control form-control-sm" value="<?php echo $odd_sem['start_date'] ?? ''; ?>" required>
                            </div>
                            <div class="mb-3">
                                <label class="small text-muted">End Date</label>
                                <input type="date" name="odd_end" class="form-control form-control-sm" value="<?php echo $odd_sem['end_date'] ?? ''; ?>" required>
                            </div>

                            <h6 class="text-primary small fw-bold text-uppercase border-bottom pb-2 mb-3">Even Semester</h6>
                            <div class="mb-2">
                                <label class="small text-muted">Start Date</label>
                                <input type="date" name="even_start" class="form-control form-control-sm" value="<?php echo $even_sem['start_date'] ?? ''; ?>" required>
                            </div>
                            <div class="mb-3">
                                <label class="small text-muted">End Date</label>
                                <input type="date" name="even_end" class="form-control form-control-sm" value="<?php echo $even_sem['end_date'] ?? ''; ?>" required>
                            </div>

                            <button type="submit" name="save_semesters" class="btn btn-outline-primary w-100 btn-sm">
                                <i class="fas fa-calendar-check me-2"></i>Save Semesters
                            </button>
                        </form>
                        <?php else: ?>
                            <p class="text-muted small text-center mt-5">Select a year first.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Holidays List -->
            <div class="col-md-8">
                <div class="card shadow-sm border-0 h-100">
                    <div class="card-header bg-white d-flex justify-content-between align-items-center">
                        <span class="fw-bold">Holidays (<?php echo $curr_year ? $curr_year['year_name'] : '-'; ?>)</span>
                        <?php if($curr_year): ?>
                        <span class="badge bg-light text-dark border">
                            <?php echo date('M Y', strtotime($curr_year['start_date'])); ?> - 
                            <?php echo date('M Y', strtotime($curr_year['end_date'])); ?>
                        </span>
                        <?php endif; ?>
                    </div>
                    <div class="card-body d-flex flex-column">
                        <?php if($curr_year): ?>
                        <!-- Add Form -->
                        <form method="POST" class="row g-2 mb-3 bg-light p-2 rounded mx-0">
                            <div class="col-md-4">
                                <input type="date" name="holiday_date" class="form-control form-control-sm" required 
                                       min="<?php echo $curr_year['start_date']; ?>" max="<?php echo $curr_year['end_date']; ?>">
                            </div>
                            <div class="col-md-6">
                                <input type="text" name="description" class="form-control form-control-sm" placeholder="Holiday Name (e.g. Diwali)" required>
                            </div>
                            <div class="col-md-2">
                                <button type="submit" name="add_holiday" class="btn btn-success btn-sm w-100">Add</button>
                            </div>
                        </form>

                        <!-- List -->
                        <div class="flex-grow-1 overflow-auto" style="max-height: 400px;">
                            <table class="table table-hover align-middle mb-0">
                                <thead class="table-light sticky-top"><tr><th>Date</th><th>Day</th><th>Occasion</th><th></th></tr></thead>
                                <tbody>
                                    <?php if($holidays_res && $holidays_res->num_rows > 0): ?>
                                        <?php while($h = $holidays_res->fetch_assoc()): ?>
                                        <tr>
                                            <td class="text-nowrap fw-bold"><?php echo date('d M Y', strtotime($h['holiday_date'])); ?></td>
                                            <td class="text-muted small"><?php echo date('l', strtotime($h['holiday_date'])); ?></td>
                                            <td><?php echo $h['description']; ?></td>
                                            <td class="text-end">
                                                <form method="POST" onsubmit="return confirm('Delete?');">
                                                    <input type="hidden" name="holiday_id" value="<?php echo $h['holiday_id']; ?>">
                                                    <button class="btn btn-link text-danger p-0 btn-sm"><i class="fas fa-trash-alt"></i></button>
                                                </form>
                                            </td>
                                        </tr>
                                        <?php endwhile; ?>
                                    <?php else: ?>
                                        <tr><td colspan="4" class="text-center text-muted py-5">
                                            <i class="fas fa-umbrella-beach fa-2x mb-3 d-block text-secondary opacity-50"></i>
                                            No holidays added for this academic year yet.
                                        </td></tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        <?php else: ?>
                            <div class="text-center text-muted py-5">
                                <i class="fas fa-arrow-left fa-2x mb-3 d-block text-secondary opacity-50"></i>
                                Please select an academic year to manage holidays.
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

    </div>
</main>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
