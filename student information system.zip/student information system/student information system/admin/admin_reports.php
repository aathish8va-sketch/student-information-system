<?php
// admin_reports.php - Reports with Filters & Data Export
require_once '../includes/db_connect.php';
require_once '../includes/year_helpers.php';
check_login(['admin']);

// Get filter parameters
$filter_year = isset($_GET['year']) ? intval($_GET['year']) : 0;
$filter_dept = $_GET['department'] ?? '';
$filter_semester = $_GET['semester'] ?? '';
$filter_date_from = $_GET['date_from'] ?? '';
$filter_date_to = $_GET['date_to'] ?? '';

// CSV Export Logic with Filters
if (isset($_GET['type'])) {
    $type = $_GET['type'];
    
    if ($type == 'students') {
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="students_' . date('Y-m-d') . '.csv"');
        
        $output = fopen('php://output', 'w');
        fputcsv($output, ['ID', 'Roll Number', 'Name', 'Department', 'Year', 'Semester', 'Email']);
        
        $where = [];
        if ($filter_dept) $where[] = "s.department = '" . $conn->real_escape_string($filter_dept) . "'";
        if ($filter_semester) $where[] = "s.semester = " . intval($filter_semester);
        
        $where_clause = count($where) > 0 ? 'WHERE ' . implode(' AND ', $where) : '';
        
        $sql = "SELECT s.student_id, s.roll_number, s.name, s.department, s.semester, u.email 
                FROM students s 
                LEFT JOIN users u ON s.student_id = u.profile_id AND u.role = 'student'
                $where_clause
                ORDER BY s.department, s.roll_number";
        $res = $conn->query($sql);
        while($row = $res->fetch_assoc()) {
            // Calculate Year
            $sem = $row['semester'];
            $year_num = ceil($sem / 2);
            $suffix = ($year_num == 1) ? 'st' : (($year_num == 2) ? 'nd' : (($year_num == 3) ? 'rd' : 'th'));
            $year_str = "{$year_num}{$suffix} Year";
            
            // Insert Year into array explicitly in correct order
            $csv_row = [
                $row['student_id'],
                $row['roll_number'],
                $row['name'],
                $row['department'],
                $year_str,
                $row['semester'],
                $row['email']
            ];
            fputcsv($output, $csv_row);
        }
        fclose($output);
        exit();
        
    } elseif ($type == 'teachers') {
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="teachers_' . date('Y-m-d') . '.csv"');
        
        $output = fopen('php://output', 'w');
        fputcsv($output, ['ID', 'Name', 'Department', 'Email']);
        
        $where = $filter_dept ? "WHERE t.department = '" . $conn->real_escape_string($filter_dept) . "'" : '';
        
        $sql = "SELECT t.teacher_id, t.name, t.department, u.email 
                FROM teachers t 
                LEFT JOIN users u ON t.teacher_id = u.profile_id AND u.role = 'teacher'
                $where
                ORDER BY t.department, t.name";
        $res = $conn->query($sql);
        while($row = $res->fetch_assoc()) {
            fputcsv($output, $row);
        }
        fclose($output);
        exit();
        
    } elseif ($type == 'scores') {
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="scores_' . date('Y-m-d') . '.csv"');
        
        $output = fopen('php://output', 'w');
        fputcsv($output, ['Student Name', 'Roll No', 'Dept', 'Semester', 'Subject Code', 'Subject Name', 'Assessment Type', 'Marks Obtained', 'Max Marks', 'Percentage', 'Date']);
        
        $where = [];
        if ($filter_dept) $where[] = "s.department = '" . $conn->real_escape_string($filter_dept) . "'";
        if ($filter_semester) $where[] = "s.semester = " . intval($filter_semester);
        if ($filter_date_from) $where[] = "DATE(sc.recorded_at) >= '" . $conn->real_escape_string($filter_date_from) . "'";
        if ($filter_date_to) $where[] = "DATE(sc.recorded_at) <= '" . $conn->real_escape_string($filter_date_to) . "'";
        
        $where_clause = count($where) > 0 ? 'WHERE ' . implode(' AND ', $where) : '';
        
        $sql = "SELECT 
                    s.name, s.roll_number, s.department, s.semester,
                    sc.subject_code, sub.subject_name, sc.assessment_type, 
                    sc.marks_obtained, sc.max_marks,
                    ROUND((sc.marks_obtained/sc.max_marks)*100, 2) as percentage,
                    sc.recorded_at
                FROM scores sc
                JOIN students s ON sc.student_id = s.student_id
                LEFT JOIN subjects sub ON sc.subject_code = sub.subject_code
                $where_clause
                ORDER BY s.department, s.roll_number, sc.recorded_at DESC";
        $res = $conn->query($sql);
        while($row = $res->fetch_assoc()) {
            fputcsv($output, $row);
        }
        fclose($output);
        exit();
        
    } elseif ($type == 'attendance') {
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="attendance_' . date('Y-m-d') . '.csv"');
        
        $output = fopen('php://output', 'w');
        fputcsv($output, ['Student Name', 'Roll No', 'Department', 'Subject Code', 'Date', 'Status']);
        
        $where = [];
        if ($filter_dept) $where[] = "s.department = '" . $conn->real_escape_string($filter_dept) . "'";
        if ($filter_date_from) $where[] = "a.date >= '" . $conn->real_escape_string($filter_date_from) . "'";
        if ($filter_date_to) $where[] = "a.date <= '" . $conn->real_escape_string($filter_date_to) . "'";
        
        $where_clause = count($where) > 0 ? 'WHERE ' . implode(' AND ', $where) : '';
        
        $sql = "SELECT 
                    s.name, s.roll_number, s.department,
                    a.subject_code, a.date, a.status
                FROM attendance a
                JOIN students s ON a.student_id = s.student_id
                $where_clause
                ORDER BY a.date DESC, s.department, s.roll_number";
        $res = $conn->query($sql);
        while($row = $res->fetch_assoc()) {
            fputcsv($output, $row);
        }
        fclose($output);
        exit();
        
    } elseif ($type == 'grievances') {
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="grievances_' . date('Y-m-d') . '.csv"');
        
        $output = fopen('php://output', 'w');
        fputcsv($output, ['ID', 'Category', 'Student Name', 'Department', 'Subject', 'Description', 'Status', 'Priority', 'Created At']);
        
        $where = [];
        if ($filter_dept) $where[] = "g.department = '" . $conn->real_escape_string($filter_dept) . "'";
        if ($filter_date_from) $where[] = "DATE(g.created_at) >= '" . $conn->real_escape_string($filter_date_from) . "'";
        if ($filter_date_to) $where[] = "DATE(g.created_at) <= '" . $conn->real_escape_string($filter_date_to) . "'";
        
        $where_clause = count($where) > 0 ? 'WHERE ' . implode(' AND ', $where) : '';
        
        $sql = "SELECT 
                    g.grievance_id, g.grievance_type, s.name, g.department, g.subject_code, 
                    g.message, g.status, g.priority, g.created_at
                FROM grievances g
                JOIN students s ON g.student_id = s.student_id
                $where_clause
                ORDER BY g.created_at DESC";
        $res = $conn->query($sql);
        while($row = $res->fetch_assoc()) {
            fputcsv($output, $row);
        }
        fclose($output);
        exit();
    }
}

// Get summary statistics (filtered)
// Build WHERE clauses properly
$student_where = [];
if ($filter_dept) $student_where[] = "department = '" . $conn->real_escape_string($filter_dept) . "'";
if ($filter_semester) $student_where[] = "semester = " . intval($filter_semester);
$student_filter = count($student_where) > 0 ? 'WHERE ' . implode(' AND ', $student_where) : '';

$total_students = $conn->query("SELECT COUNT(*) FROM students $student_filter")->fetch_row()[0] ?? 0;

$teacher_filter = $filter_dept ? "WHERE department = '" . $conn->real_escape_string($filter_dept) . "'" : '';
$total_teachers = $conn->query("SELECT COUNT(*) FROM teachers $teacher_filter")->fetch_row()[0] ?? 0;

// Scores - join with students for filtering
$score_where = [];
if ($filter_dept || $filter_semester) {
    $score_where[] = "sc.student_id IN (SELECT student_id FROM students $student_filter)";
}
$score_filter = count($score_where) > 0 ? 'WHERE ' . implode(' AND ', $score_where) : '';
$total_scores = $conn->query("SELECT COUNT(*) FROM scores sc $score_filter")->fetch_row()[0] ?? 0;

// Attendance - join with students for filtering
$att_where = [];
if ($filter_dept || $filter_semester) {
    $att_where[] = "a.student_id IN (SELECT student_id FROM students $student_filter)";
}
$att_filter = count($att_where) > 0 ? 'WHERE ' . implode(' AND ', $att_where) : '';
$total_attendance = $conn->query("SELECT COUNT(*) FROM attendance a $att_filter")->fetch_row()[0] ?? 0;

// Grievances
$griev_filter = $filter_dept ? "WHERE department = '" . $conn->real_escape_string($filter_dept) . "'" : '';
$total_grievances = $conn->query("SELECT COUNT(*) FROM grievances $griev_filter")->fetch_row()[0] ?? 0;

// Behavior Assessment Statistics (filtered by year/semester if selected)
$behavior_where = [];
if ($filter_year || $filter_semester) {
    $behavior_where[] = "sb.student_id IN (SELECT student_id FROM students $student_filter)";
}
$behavior_filter = count($behavior_where) > 0 ? 'WHERE ' . implode(' AND ', $behavior_where) : '';

$behavior_by_tag = $conn->query("
    SELECT behavior_tag, COUNT(*) as count 
    FROM student_behavior sb 
    $behavior_filter 
    GROUP BY behavior_tag 
    ORDER BY FIELD(behavior_tag, 'Excellent', 'Good', 'Average', 'Poor', 'Disruptive')
");

$total_behavior_assessments = $conn->query("SELECT COUNT(*) FROM student_behavior sb $behavior_filter")->fetch_row()[0] ?? 0;


$departments = ['Civil', 'Computer', 'EEE', 'Mechanical', 'ECE', 'Textile Technology', 'Science and Humanities'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports & Export - Chendhuran SIS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="../includes/css/styles.css" rel="stylesheet">
</head>
<body>
<?php include '../includes/sidebar.php'; ?>

<main class="admin-main">
    <!-- Page Header -->
    <div class="page-header">
        <div>
            <h4 class="mb-1">Reports & Data Export</h4>
            <p class="text-muted mb-0 text-sm">Filter and download system data in CSV format</p>
        </div>
    </div>

    <!-- Filter Panel (Redesigned) -->
    <div class="bg-white p-3 rounded shadow-sm border mb-4">
        <form method="GET" class="row g-2 align-items-end">
            <div class="col-lg-2 col-md-4">
                <label class="form-label small text-muted mb-1">Department</label>
                <select name="department" class="form-select form-select-sm fw-bold border-0 bg-light">
                    <option value="">All Departments</option>
                    <?php foreach($departments as $d): ?>
                        <option value="<?php echo $d; ?>" <?php if($filter_dept==$d) echo 'selected'; ?>><?php echo $d; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-lg-2 col-md-4">
                <label class="form-label small text-muted mb-1">Year</label>
                <select name="year" id="yearSelect" class="form-select form-select-sm fw-bold border-0 bg-light" onchange="updateSemesters()">
                    <option value="">All Years</option>
                    <?php for($y=1; $y<=3; $y++): ?>
                        <option value="<?php echo $y; ?>" <?php if($filter_year==$y) echo 'selected'; ?>>
                            <?php echo get_year_label($y); ?>
                        </option>
                    <?php endfor; ?>
                </select>
            </div>
            <div class="col-lg-2 col-md-4">
                <label class="form-label small text-muted mb-1">Semester</label>
                <select name="semester" id="semesterSelect" class="form-select form-select-sm fw-bold border-0 bg-light">
                    <option value="">All Semesters</option>
                    <?php for($i=1; $i<=6; $i++): ?>
                        <option value="<?php echo $i; ?>" <?php if($filter_semester==$i) echo 'selected'; ?>>
                            Semester <?php echo $i; ?>
                        </option>
                    <?php endfor; ?>
                </select>
            </div>
            <div class="col-lg-2 col-md-6">
                <label class="form-label small text-muted mb-1">From</label>
                <input type="date" name="date_from" class="form-control form-control-sm border-0 bg-light" value="<?php echo htmlspecialchars($filter_date_from); ?>">
            </div>
            <div class="col-lg-2 col-md-6">
                <label class="form-label small text-muted mb-1">To</label>
                <input type="date" name="date_to" class="form-control form-control-sm border-0 bg-light" value="<?php echo htmlspecialchars($filter_date_to); ?>">
            </div>
            <div class="col-lg-2 col-md-12">
                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-primary btn-sm flex-fill">
                        <i class="fas fa-filter"></i> Apply
                    </button>
                    <a href="admin_reports.php" class="btn btn-light btn-sm text-secondary flex-fill" title="Reset Filters">
                        <i class="fas fa-undo me-1"></i> Reset
                    </a>
                </div>
            </div>
        </form>
    </div>

    <!-- Active Filters Display -->
    <?php if($filter_dept || $filter_semester || $filter_date_from || $filter_date_to): ?>
    <div class="alert alert-info mb-4">
        <strong><i class="fas fa-info-circle me-2"></i> Active Filters:</strong>
        <?php if($filter_dept): ?><span class="badge bg-primary me-2"><?php echo $filter_dept; ?></span><?php endif; ?>
        <?php if($filter_semester): ?><span class="badge bg-primary me-2">Semester <?php echo $filter_semester; ?></span><?php endif; ?>
        <?php if($filter_date_from): ?><span class="badge bg-primary me-2">From: <?php echo $filter_date_from; ?></span><?php endif; ?>
        <?php if($filter_date_to): ?><span class="badge bg-primary me-2">To: <?php echo $filter_date_to; ?></span><?php endif; ?>
    </div>
    <?php endif; ?>

    <!-- Export Cards -->
    <div class="row g-4">
        <!-- Students Export -->
        <div class="col-md-6 col-lg-4">
            <div class="card h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center mb-3">
                        <div class="stat-icon blue me-3">
                            <i class="fas fa-user-graduate"></i>
                        </div>
                        <div>
                            <h5 class="mb-0 fw-bold">Students</h5>
                            <small class="text-muted"><?php echo number_format($total_students); ?> records</small>
                        </div>
                    </div>
                    <p class="text-muted text-sm mb-3">Student directory filtered by your criteria.</p>
                    <a href="?type=students&department=<?php echo urlencode($filter_dept); ?>&semester=<?php echo urlencode($filter_semester); ?>" class="btn btn-primary w-100">
                        <i class="fas fa-download me-2"></i> Download CSV
                    </a>
                </div>
            </div>
        </div>

        <!-- Teachers Export -->
        <div class="col-md-6 col-lg-4">
            <div class="card h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center mb-3">
                        <div class="stat-icon purple me-3">
                            <i class="fas fa-chalkboard-teacher"></i>
                        </div>
                        <div>
                            <h5 class="mb-0 fw-bold">Teachers</h5>
                            <small class="text-muted"><?php echo number_format($total_teachers); ?> records</small>
                        </div>
                    </div>
                    <p class="text-muted text-sm mb-3">Faculty directory filtered by department.</p>
                    <a href="?type=teachers&department=<?php echo urlencode($filter_dept); ?>" class="btn btn-secondary w-100">
                        <i class="fas fa-download me-2"></i> Download CSV
                    </a>
                </div>
            </div>
        </div>

        <!-- Scores Export -->
        <div class="col-md-6 col-lg-4">
            <div class="card h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center mb-3">
                        <div class="stat-icon green me-3">
                            <i class="fas fa-chart-bar"></i>
                        </div>
                        <div>
                            <h5 class="mb-0 fw-bold">Marks & Scores</h5>
                            <small class="text-muted"><?php echo number_format($total_scores); ?> records</small>
                        </div>
                    </div>
                    <p class="text-muted text-sm mb-3">Scores filtered by dept, semester & date range.</p>
                    <a href="?type=scores&department=<?php echo urlencode($filter_dept); ?>&semester=<?php echo urlencode($filter_semester); ?>&date_from=<?php echo urlencode($filter_date_from); ?>&date_to=<?php echo urlencode($filter_date_to); ?>" class="btn btn-success w-100">
                        <i class="fas fa-download me-2"></i> Download CSV
                    </a>
                </div>
            </div>
        </div>

        <!-- Attendance Export -->
        <div class="col-md-6 col-lg-4">
            <div class="card h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center mb-3">
                        <div class="stat-icon orange me-3" style="background: #fff3cd; color: #856404;">
                            <i class="fas fa-calendar-check"></i>
                        </div>
                        <div>
                            <h5 class="mb-0 fw-bold">Attendance</h5>
                            <small class="text-muted"><?php echo number_format($total_attendance); ?> records</small>
                        </div>
                    </div>
                    <p class="text-muted text-sm mb-3">Attendance records filtered by your criteria.</p>
                    <a href="?type=attendance&department=<?php echo urlencode($filter_dept); ?>&date_from=<?php echo urlencode($filter_date_from); ?>&date_to=<?php echo urlencode($filter_date_to); ?>" class="btn btn-warning w-100">
                        <i class="fas fa-download me-2"></i> Download CSV
                    </a>
                </div>
            </div>
        </div>

        <!-- Grievances Export -->
        <div class="col-md-6 col-lg-4">
            <div class="card h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center mb-3">
                        <div class="stat-icon red me-3">
                            <i class="fas fa-exclamation-triangle"></i>
                        </div>
                        <div>
                            <h5 class="mb-0 fw-bold">Grievances</h5>
                            <small class="text-muted"><?php echo number_format($total_grievances); ?> records</small>
                        </div>
                    </div>
                    <p class="text-muted text-sm mb-3">Grievances filtered by department & date.</p>
                    <a href="?type=grievances&department=<?php echo urlencode($filter_dept); ?>&date_from=<?php echo urlencode($filter_date_from); ?>&date_to=<?php echo urlencode($filter_date_to); ?>" class="btn btn-danger w-100">
                        <i class="fas fa-download me-2"></i> Download CSV
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Behavior Assessment Reports -->
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-star me-2"></i> Behavior Assessment Analytics
        </div>
        <div class="card-body">
            <div class="row g-4">
                <!-- Total Assessments -->
                <div class="col-md-3">
                    <div class="text-center">
                        <h3 class="fw-bold text-primary mb-1"><?php echo number_format($total_behavior_assessments); ?></h3>
                        <small class="text-muted text-uppercase">Total Assessments</small>
                    </div>
                </div>

                <!-- Behavior Distribution -->
                <div class="col-md-9">
                    <div class="row g-2">
                        <?php
                        $tag_colors = [
                            'Excellent' => 'success',
                            'Good' => 'primary',
                            'Average' => 'warning',
                            'Poor' => 'danger',
                            'Disruptive' => 'dark'
                        ];

                        $behavior_data = [];
                        while($b = $behavior_by_tag->fetch_assoc()) {
                            $behavior_data[$b['behavior_tag']] = $b['count'];
                        }

                        foreach($tag_colors as $tag => $color):
                            $count = $behavior_data[$tag] ?? 0;
                            $percentage = $total_behavior_assessments > 0 ? round(($count / $total_behavior_assessments) * 100) : 0;
                        ?>
                        <div class="col">
                            <div class="card border-0 bg-<?php echo $color; ?> bg-opacity-10">
                                <div class="card-body text-center p-3">
                                    <h5 class="fw-bold mb-1 text-<?php echo $color; ?>"><?php echo $count; ?></h5>
                                    <small class="text-muted d-block"><?php echo $tag; ?></small>
                                    <small class="badge bg-<?php echo $color; ?> mt-1"><?php echo $percentage; ?>%</small>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Info Notice -->
    <div class="alert alert-light border mt-4">
        <i class="fas fa-lightbulb me-2 text-warning"></i>
        <strong>Tip:</strong> Use filters to download only the data you need. Record counts update based on your filter selections.
    </div>
</main>

<script>
// Year-Semester Cascade Filter
function updateSemesters() {
    const year = document.getElementById('yearSelect').value;
    const semesterSelect = document.getElementById('semesterSelect');
    
    // Clear current options except "All Semesters"
    semesterSelect.innerHTML = '<option value="">All Semesters</option>';
    
    if (year) {
        // Add semesters for selected year
        const yearInt = parseInt(year);
        const sem1 = (yearInt * 2) - 1;
        const sem2 = yearInt * 2;
        
        semesterSelect.innerHTML += `<option value="${sem1}">Semester ${sem1}</option>`;
        semesterSelect.innerHTML += `<option value="${sem2}">Semester ${sem2}</option>`;
    } else {
        // Show all semesters if no year selected
        for(let i = 1; i <= 6; i++) {
            semesterSelect.innerHTML += `<option value="${i}">Semester ${i}</option>`;
        }
    }
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    // If year is pre-selected, update semesters
    const yearSelect = document.getElementById('yearSelect');
    if (yearSelect.value) {
        updateSemesters();
        // Re-select the filtered semester if it was set
        const currentSem = '<?php echo $filter_semester; ?>';
        if (currentSem) {
            document.getElementById('semesterSelect').value = currentSem;
        }
    }
});
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
