<?php
// admin_student_affairs.php - Unified Student Affairs Management
require_once '../includes/db_connect.php';
check_login(['admin']);

$tab = $_GET['tab'] ?? 'grievances';
$message = '';
$error = '';
$csrf_token = generate_csrf_token();


// ===============================================
// LOGIC: TAB 1 - GRIEVANCES (Modified from teacher/grievance_list.php)
// ===============================================
if ($tab == 'grievances') {
    // Admin sees ALL grievances or filters? Usually all.
    $g_filter = $_GET['g_status'] ?? 'Pending';
    
    // Handle Logic: Admin is READ-ONLY for Grievances
    // (No POST updates here)
    
    // Fetch
    $where_g = "1=1";
    if($g_filter != 'All') $where_g .= " AND status='$g_filter'";
    
    // Grievances Query - Include BOTH student and teacher grievances
    $g_sql = "SELECT g.*, 
                     s.name as student_name, 
                     s.roll_number, 
                     s.department as student_dept,
                     t.name as teacher_name,
                     t.department as teacher_dept,
                     COALESCE(s.name, t.name, 'Unknown') as submitter_name,
                     COALESCE(s.department, t.department, 'Unknown') as department
              FROM grievances g
              LEFT JOIN students s ON g.student_id = s.student_id
              LEFT JOIN teachers t ON g.teacher_id = t.teacher_id";
    
    if ($g_filter != 'All') {
        $g_sql .= " WHERE g.status = '$g_filter'";
    }
    
    $g_sql .= " ORDER BY g.created_at DESC";
    $grievances = $conn->query($g_sql);
}


// ===============================================
// LOGIC: TAB 2 - FEEDBACK (From admin_feedback_view.php)
// ===============================================
if ($tab == 'feedback') {
    $f_filter = $_GET['f_cat'] ?? '';
    
    $where_f = "1=1";
    if ($f_filter) $where_f .= " AND feedback_type='$f_filter'";
    
    
    // Fetch with proper joins and column names
    // Schema: feedback(feedback_id, student_id, feedback_type, subject, teacher_id, rating, comments, created_at...)
    $feedbacks = $conn->query("SELECT f.*, s.name as student_name, s.department, t.name as teacher_name 
                               FROM feedback f 
                               JOIN students s ON f.student_id = s.student_id 
                               LEFT JOIN teachers t ON f.teacher_id = t.teacher_id
                               WHERE $where_f 
                               ORDER BY f.created_at DESC");
    
    // Stats
    $avg = $conn->query("SELECT AVG(rating) FROM feedback")->fetch_row()[0];
    $avg_rating = $avg ? $avg : 0;
}


// ===============================================
// LOGIC: TAB 3 - BEHAVIOR (From admin_behavior_reports.php)
// ===============================================
if ($tab == 'behavior') {
    // Add Report logic disabled - View Only for reports
    $reports = $conn->query("SELECT sb.*, s.name, s.roll_number, s.department 
                             FROM student_behavior sb 
                             JOIN students s ON sb.student_id = s.student_id 
                             ORDER BY sb.recorded_date DESC");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Affairs - Chendhuran SIS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../includes/css/styles.css" rel="stylesheet">
    <style>
        .nav-tabs .nav-link { color: #6b7280; font-weight: 500; padding: 1rem 1.5rem; }
        .nav-tabs .nav-link.active { color: #4f46e5; border-bottom: 3px solid #4f46e5; font-weight: 600; background:none;}
        .rating-star { color: #fbbf24; }
    </style>
</head>
<body>
<?php include '../includes/sidebar.php'; ?>

<main class="main-content">
    
    <div class="glass-header mb-0 pb-0 rounded-bottom-0">
        <div class="d-flex justify-content-between align-items-center mb-3">
             <h4 class="fw-bold mb-0">Student Affairs</h4>
        </div>

        <ul class="nav nav-tabs">
            <li class="nav-item"><a class="nav-link <?php echo $tab == 'grievances' ? 'active' : ''; ?>" href="?tab=grievances"><i class="fas fa-clipboard-check me-2"></i>Grievance Desk</a></li>
            <li class="nav-item"><a class="nav-link <?php echo $tab == 'feedback' ? 'active' : ''; ?>" href="?tab=feedback"><i class="fas fa-comments me-2"></i>Feedback</a></li>
            <li class="nav-item"><a class="nav-link <?php echo $tab == 'behavior' ? 'active' : ''; ?>" href="?tab=behavior"><i class="fas fa-exclamation-circle me-2"></i>Behavior Reports</a></li>
        </ul>
    </div>

    <div class="glass-card rounded-top-0 border-top-0 p-4">
        <?php if($message): ?><div class="alert alert-success alert-dismissible fade show"><?php echo $message; ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div><?php endif; ?>

        <!-- TAB 1: GRIEVANCES -->
        <?php if ($tab == 'grievances'): ?>
            <div class="d-flex justify-content-end mb-3">
                <div class="btn-group btn-group-sm">
                    <a href="?tab=grievances&g_status=Pending" class="btn <?php echo $g_filter=='Pending'?'btn-primary':'btn-outline-secondary'; ?>">Pending</a>
                    <a href="?tab=grievances&g_status=Resolved" class="btn <?php echo $g_filter=='Resolved'?'btn-primary':'btn-outline-secondary'; ?>">Resolved</a>
                    <a href="?tab=grievances&g_status=All" class="btn <?php echo $g_filter=='All'?'btn-primary':'btn-outline-secondary'; ?>">All</a>
                </div>
            </div>
            
            <div class="table-responsive">
                <table class="table table-hover align-middle bg-white border rounded">
                    <thead class="table-light">
                        <tr>
                            <th>Date</th>
                            <th>Student</th>
                            <th>Issue</th>
                            <th>Status</th>
                            <th>HOD Action</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($grievances && $grievances->num_rows > 0): ?>
                        <?php while($g = $grievances->fetch_assoc()): ?>
                        <?php
                            // Removed priority logic - not needed anymore
                            
                            // Status Data
                            $status_color = match($g['status']) {
                                'Pending' => 'warning text-dark',
                                'In Progress' => 'info',
                                'Resolved', 'Closed' => 'success',
                                'Rejected' => 'danger',
                                default => 'secondary'
                            };
                        ?>
                        <tr>
                            <!-- Date -->
                            <td>
                                <div class="fw-bold"><?php echo date('M d', strtotime($g['created_at'])); ?></div>
                                <div class="text-xs text-muted"><?php echo date('h:i A', strtotime($g['created_at'])); ?></div>
                            </td>

                            <!-- Submitter (Student or Teacher) -->
                            <td>
                                <div class="fw-bold"><?php echo $g['submitter_name']; ?></div>
                                <div class="text-xs text-muted">
                                    <?php 
                                    if(!empty($g['student_name'])) {
                                        echo $g['student_dept'] . ' • ' . $g['roll_number'];
                                    } else {
                                        echo '<span class="badge bg-warning text-dark">Faculty</span> • ' . $g['teacher_dept'];
                                    }
                                    ?>
                                </div>
                            </td>

                            <!-- Issue -->
                            <td width="35%">
                                <div class="d-flex align-items-center gap-2 mb-1">
                                    <span class="badge bg-light text-dark border"><?php echo $g['category'] ?? 'General'; ?></span>
                                    <?php if(!empty($g['subject_code'])): ?>
                                        <span class="badge bg-light text-secondary border"><?php echo htmlspecialchars($g['subject_code']); ?></span>
                                    <?php endif; ?>
                                </div>
                                <p class="mb-0 text-sm small text-dark" style="white-space: pre-wrap; line-height: 1.4;"><?php 
                                    $full_msg = !empty($g['message']) ? $g['message'] : ($g['description'] ?? '');
                                    echo htmlspecialchars(mb_strimwidth($full_msg, 0, 100, "...")); 
                                ?></p>
                            </td>

                            <!-- Status -->
                            <td>
                                <span class="badge bg-<?php echo $status_color; ?> text-white"><?php echo $g['status']; ?></span>
                            </td>

                            <!-- HOD Action Taken -->
                            <td>
                                <?php if(!empty($g['admin_response'])): ?>
                                    <div class="p-2 bg-success bg-opacity-10 rounded border-start border-3 border-success">
                                        <small class="fw-bold text-success d-block mb-1">Action Taken:</small>
                                        <small class="text-dark"><?php echo htmlspecialchars(mb_strimwidth($g['admin_response'], 0, 80, "...")); ?></small>
                                    </div>
                                <?php else: ?>
                                    <span class="text-muted small fst-italic">No action recorded</span>
                                <?php endif; ?>
                            </td>

                            <!-- Action -->
                            <td>
                                <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#gModal<?php echo $g['grievance_id']; ?>">
                                    View
                                </button>
                                
                                <!-- Resolution Modal -->
                                <div class="modal fade" id="gModal<?php echo $g['grievance_id']; ?>" tabindex="-1">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h6 class="modal-title">Grievance #<?php echo $g['grievance_id']; ?> (View Only)</h6>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                            </div>
                                            <div class="modal-body">
                                                <!-- Details Header -->
                                                <div class="bg-light p-3 rounded mb-3">
                                                    <div class="d-flex justify-content-between mb-2">
                                                        <span class="badge bg-<?php echo $status_color; ?> text-white"><?php echo $g['status']; ?></span>
                                                        <small class="text-muted"><?php echo date('d M Y, h:i A', strtotime($g['created_at'])); ?></small>
                                                    </div>
                                                    <div class="mb-1"><strong>From:</strong> <?php echo $g['student_name']; ?> (<?php echo $g['student_dept']; ?>)</div>
                                                    <div class="mb-1"><strong>To:</strong> <?php echo $g['department']; ?></div>
                                                    <div class="mb-1"><strong>Subject:</strong> <?php echo $g['subject_code']; ?></div>
                                                </div>

                                                <!-- Message Body -->
                                                <div class="mb-3">
                                                    <label class="form-label small fw-bold text-uppercase text-muted">Grievance Details</label>
                                                    <div class="p-3 border rounded bg-white" style="white-space: pre-wrap; max-height: 200px; overflow-y: auto;"><?php 
                                                        echo htmlspecialchars($full_msg); 
                                                    ?></div>
                                                </div>
                                                
                                                <hr>

                                                <?php if(!empty($g['admin_response'])): ?>
                                                <div class="mb-3">
                                                    <label class="form-label small fw-bold text-uppercase text-muted">Action Taken By HOD</label>
                                                    <div class="p-3 border rounded bg-light" style="white-space: pre-wrap;"><?php echo htmlspecialchars($g['admin_response']); ?></div>
                                                </div>
                                                <?php endif; ?>
                                                
                                                <div class="alert alert-secondary small mb-0">
                                                    <i class="fas fa-info-circle me-1"></i> Action can only be taken by the HOD of <?php echo $g['department']; ?>.
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                        <?php else: ?>
                            <tr><td colspan="6" class="text-center text-muted py-4">No grievances found.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>


        <!-- TAB 2: FEEDBACK -->
        <?php if ($tab == 'feedback'): ?>
            <div class="row mb-4">
                <div class="col-md-3">
                    <div class="card bg-light border-0">
                        <div class="card-body text-center">
                            <h2 class="fw-bold text-primary mb-0"><?php echo number_format($avg_rating, 1); ?></h2>
                            <div class="text-xs text-muted">Average Rating</div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="table-responsive">
                <table class="table table-hover align-middle bg-white border rounded">
                     <thead class="table-light"><tr><th>Date</th><th>Student</th><th>Category</th><th>Rating</th><th>Comments</th></tr></thead>
                     <tbody>
                          <?php if($feedbacks && $feedbacks->num_rows > 0): ?>
                          <?php while($f = $feedbacks->fetch_assoc()): ?>
                          <tr>
                              <td class="text-nowrap small text-muted"><?php echo date('d M', strtotime($f['created_at'])); ?></td>
                              <td><?php echo $f['student_name']; ?><br><small class="text-muted"><?php echo $f['department']; ?></small></td>
                              <td>
                                <span class="badge bg-light text-dark border"><?php echo $f['feedback_type']; ?></span>
                                <div class="small text-muted mt-1">
                                    <?php 
                                    if($f['feedback_type'] == 'Faculty' && !empty($f['teacher_name'])) echo "Prof. " . $f['teacher_name'];
                                    elseif(!empty($f['subject'])) echo $f['subject'];
                                    ?>
                                </div>
                              </td>
                              <td class="text-nowrap">
                                  <div class="d-flex align-items-center">
                                      <span class="fw-bold me-2 text-primary"><?php echo $f['rating']; ?>/5</span>
                                      <div>
                                      <?php for($i=1;$i<=5;$i++) echo ($i<=$f['rating']) ? '<i class="fas fa-star rating-star"></i>' : '<i class="far fa-star text-muted" style="opacity:0.3"></i>'; ?>
                                      </div>
                                  </div>
                              </td>
                              <td><small><?php echo nl2br(htmlspecialchars($f['comments'])); ?></small></td>
                          </tr>
                          <?php endwhile; ?>
                          <?php else: ?>
                            <tr><td colspan="5" class="text-center text-muted py-4">No feedback records found.</td></tr>
                          <?php endif; ?>
                     </tbody>
                </table>
            </div>
        <?php endif; ?>


        <!-- TAB 3: BEHAVIOR -->
        <?php if ($tab == 'behavior'): ?>
            <div class="table-responsive">
                 <table class="table table-hover align-middle bg-white border rounded">
                     <thead class="table-light"><tr><th>Date</th><th>Student</th><th>Tag</th><th>Ratings (Disc/Part/Cond)</th></tr></thead>
                     <tbody>
                         <?php if($reports && $reports->num_rows > 0): ?>
                         <?php while($b = $reports->fetch_assoc()): ?>
                         <tr>
                             <td class="small text-muted"><?php echo date('d M Y', strtotime($b['recorded_date'])); ?></td>
                             <td>
                                 <span class="fw-bold"><?php echo $b['name']; ?></span><br>
                                 <small class="text-muted"><?php echo $b['department']; ?></small>
                             </td>
                             <td>
                                <?php 
                                $tag = $b['behavior_tag'];
                                $badge = 'bg-secondary';
                                if($tag=='Excellent') $badge='bg-success';
                                elseif($tag=='Good') $badge='bg-primary';
                                elseif($tag=='Poor') $badge='bg-danger';
                                elseif($tag=='Disruptive') $badge='bg-dark';
                                ?>
                                <span class="badge <?php echo $badge; ?>"><?php echo $tag; ?></span>
                             </td>
                             <td>
                                <small class="d-flex gap-3">
                                    <span title="Discipline">Disc: <strong><?php echo $b['discipline_rating']; ?></strong></span>
                                    <span title="Participation">Part: <strong><?php echo $b['participation_rating']; ?></strong></span>
                                    <span title="Conduct">Cond: <strong><?php echo $b['conduct_rating']; ?></strong></span>
                                </small>
                             </td>
                         </tr>
                         <?php endwhile; ?>
                         <?php else: ?>
                            <tr><td colspan="4" class="text-center text-muted py-4">No behavior records found.</td></tr>
                         <?php endif; ?>
                     </tbody>
                 </table>
            </div>

            <div class="alert alert-info small mt-3">
                <i class="fas fa-info-circle me-1"></i> Behavior records are currently generated via Teacher assessments.
            </div>

        <?php endif; ?>

    </div>
</main>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
