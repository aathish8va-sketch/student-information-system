<?php
// Simple working admin users page
require_once '../includes/db_connect.php';
check_login(['admin']);

$msg = '';
$err = '';

// Handle bulk delete
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'delete_selected') {
    if (isset($_POST['selected_users']) && is_array($_POST['selected_users'])) {
        $ids = $_POST['selected_users'];
        $count = 0;
        
        $conn->begin_transaction();
        try {
            foreach ($ids as $user_id) {
                $user_id = intval($user_id);
                // Get profile info first
                $u_res = $conn->query("SELECT role, profile_id FROM users WHERE user_id = $user_id");
                if ($u_res && $row = $u_res->fetch_assoc()) {
                    $pid = $row['profile_id'];
                    
                    // Delete profile and related data
                    if ($row['role'] == 'student') {
                        // Delete related student data first to avoid FK constraint errors
                        $conn->query("DELETE FROM scores WHERE student_id = $pid");
                        $conn->query("DELETE FROM attendance WHERE student_id = $pid");
                        $conn->query("DELETE FROM student_behavior WHERE student_id = $pid");
                        $conn->query("DELETE FROM leave_requests WHERE student_id = $pid");
                        // Finally delete student profile
                        $conn->query("DELETE FROM students WHERE student_id = $pid");
                    } elseif ($row['role'] == 'teacher') {
                        // Unassign from students
                        $conn->query("UPDATE students SET class_teacher_id = NULL WHERE class_teacher_id = $pid");
                        // Delete teacher profile
                        $conn->query("DELETE FROM teachers WHERE teacher_id = $pid");
                    }
                    // Delete user (cascade should handle this but being explicit)
                    $conn->query("DELETE FROM users WHERE user_id = $user_id");
                    $count++;
                }
            }
            $conn->commit();
            $msg = "Successfully deleted $count users.";
        } catch (Exception $e) {
            $conn->rollback();
            $err = "Error deleting users: " . $e->getMessage();
        }
    }
}

// Handle add user
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_user'])) {
    $name = sanitize_input($_POST['name']);
    $email = sanitize_input($_POST['email']);
    $role = sanitize_input($_POST['role']);
    $dept = sanitize_input($_POST['department'] ?? '');
    $password = password_hash('123456', PASSWORD_DEFAULT);
    
    try {
        $conn->begin_transaction();
        
        // Create profile first
        $profile_id = 0;
        if ($role == 'student') {
            $semester = intval($_POST['semester'] ?? 1);
            $roll = 'S' . date('Y') . rand(1000, 9999);
            $conn->query("INSERT INTO students (name, roll_number, department, semester) VALUES ('$name', '$roll', '$dept', $semester)");
            $profile_id = $conn->insert_id;
        } elseif ($role == 'teacher') {
            $conn->query("INSERT INTO teachers (name, department) VALUES ('$name', '$dept')");
            $profile_id = $conn->insert_id;
        }
        
        // Create user
        $conn->query("INSERT INTO users (email, password_hash, role, profile_id) VALUES ('$email', '$password', '$role', $profile_id)");
        
        $conn->commit();
        $msg = "User created! Email: $email, Password: 123456";
    } catch (Exception $e) {
        $conn->rollback();
        $err = "Error: " . $e->getMessage();
    }
}

// Calculate Stats for Top Cards
$stats = [
    'total' => $conn->query("SELECT COUNT(*) FROM users")->fetch_row()[0],
    'students' => $conn->query("SELECT COUNT(*) FROM users WHERE role='student'")->fetch_row()[0],
    'teachers' => $conn->query("SELECT COUNT(*) FROM users WHERE role='teacher'")->fetch_row()[0],
    'inactive' => $conn->query("SELECT COUNT(*) FROM users WHERE is_active=0")->fetch_row()[0]
];
?>
<!DOCTYPE html>
<html>
<head>
    <title>User Directory - Chendhuran SIS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../includes/css/styles.css" rel="stylesheet">
</head>
<body>
<?php include '../includes/sidebar.php'; ?>

<main class="admin-main">
    <!-- Header & Stats -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="mb-1">User Directory</h2>
            <p class="text-muted mb-0">Manage students, teachers, and system access.</p>
        </div>
        <button class="btn btn-primary" type="button" data-bs-toggle="collapse" data-bs-target="#addUserForm">
            <i class="fas fa-plus me-2"></i>Add New User
        </button>
    </div>

    <!-- Stats Row -->
    <div class="row g-3 mb-4">
        <div class="col-md-3">
            <div class="card bg-primary text-white h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-title mb-1">Total Users</h6>
                            <h3 class="mb-0"><?php echo $stats['total']; ?></h3>
                        </div>
                        <i class="fas fa-users fa-2x opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-success text-white h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-title mb-1">Students</h6>
                            <h3 class="mb-0"><?php echo $stats['students']; ?></h3>
                        </div>
                        <i class="fas fa-user-graduate fa-2x opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-info text-white h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-title mb-1">Teachers</h6>
                            <h3 class="mb-0"><?php echo $stats['teachers']; ?></h3>
                        </div>
                        <i class="fas fa-chalkboard-teacher fa-2x opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-secondary text-white h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-title mb-1">Debarred</h6>
                            <h3 class="mb-0"><?php echo $stats['inactive']; ?></h3>
                        </div>
                        <i class="fas fa-user-slash fa-2x opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php if($msg): ?>
        <div class="alert alert-success d-flex align-items-center"><i class="fas fa-check-circle me-2"></i><?php echo $msg; ?></div>
    <?php endif; ?>
    
    <?php if($err): ?>
        <div class="alert alert-danger d-flex align-items-center"><i class="fas fa-exclamation-circle me-2"></i><?php echo $err; ?></div>
    <?php endif; ?>
    
    <!-- Collapsible Add User Form -->
    <div class="collapse mb-4" id="addUserForm">
        <div class="card border-primary shadow-sm">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0"><i class="fas fa-user-plus me-2"></i>Add New User</h5>
            </div>
            <div class="card-body">
                <form method="POST">
                    <div class="row g-3">
                        <div class="col-md-3">
                            <label class="form-label">Full Name</label>
                            <input type="text" name="name" class="form-control" placeholder="e.g. John Doe" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Email Address</label>
                            <input type="email" name="email" class="form-control" placeholder="email@chendhuran.in" required>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Role</label>
                            <select name="role" class="form-select" required>
                                <option value="student">Student</option>
                                <option value="teacher">Teacher</option>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Department</label>
                            <select name="department" class="form-select">
                                <option value="Computer">Computer</option>
                                <option value="Civil">Civil</option>
                                <option value="EEE">EEE</option>
                                <option value="Mechanical">Mechanical</option>
                                <option value="ECE">ECE</option>
                                <option value="Textile Technology">Textile Technology</option>
                                <option value="Science and Humanities">Science and Humanities</option>
                            </select>
                        </div>
                        <div class="col-md-2 d-flex align-items-end">
                            <button type="submit" name="add_user" class="btn btn-primary w-100">
                                <i class="fas fa-save me-2"></i>Save User
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Main Content Card (Filters & Table) -->
    <div class="card shadow-sm">
        <div class="card-header bg-white py-3">
            <div class="row g-3 align-items-center">
                <!-- Search -->
                <div class="col-md-4">
                    <form method="GET" class="d-flex">
                        <input type="text" name="search" class="form-control me-2" placeholder="Search by name/email..." value="<?php echo htmlspecialchars($_GET['search'] ?? ''); ?>">
                        
                        <!-- Hidden inputs to preserve other filters when searching -->
                        <?php if(!empty($_GET['department'])): ?><input type="hidden" name="department" value="<?php echo htmlspecialchars($_GET['department']); ?>"><?php endif; ?>
                        <?php if(!empty($_GET['year'])): ?><input type="hidden" name="year" value="<?php echo htmlspecialchars($_GET['year']); ?>"><?php endif; ?>
                        <?php if(!empty($_GET['status'])): ?><input type="hidden" name="status" value="<?php echo htmlspecialchars($_GET['status']); ?>"><?php endif; ?>
                        <?php if(!empty($_GET['role'])): ?><input type="hidden" name="role" value="<?php echo htmlspecialchars($_GET['role']); ?>"><?php endif; ?>
                        
                        <button type="submit" class="btn btn-outline-primary"><i class="fas fa-search"></i></button>
                    </form>
                </div>

                <!-- Filters -->
                <div class="col-md-8">
                    <form method="GET" id="filterForm" class="row g-2 justify-content-end">
                        <input type="hidden" name="search" value="<?php echo htmlspecialchars($_GET['search'] ?? ''); ?>">
                        
                        <div class="col-auto">
                            <select name="role" class="form-select form-select-sm" onchange="this.form.submit()">
                                <option value="">All Roles</option>
                                <option value="student" <?php echo ($_GET['role'] ?? '') == 'student' ? 'selected' : ''; ?>>Student</option>
                                <option value="teacher" <?php echo ($_GET['role'] ?? '') == 'teacher' ? 'selected' : ''; ?>>Teacher</option>
                                <option value="admin" <?php echo ($_GET['role'] ?? '') == 'admin' ? 'selected' : ''; ?>>Admin</option>
                            </select>
                        </div>
                        <div class="col-auto">
                            <select name="department" class="form-select form-select-sm" onchange="this.form.submit()">
                                <option value="">All Departments</option>
                                <option value="Computer" <?php echo ($_GET['department'] ?? '') == 'Computer' ? 'selected' : ''; ?>>Computer</option>
                                <option value="Civil" <?php echo ($_GET['department'] ?? '') == 'Civil' ? 'selected' : ''; ?>>Civil</option>
                                <option value="EEE" <?php echo ($_GET['department'] ?? '') == 'EEE' ? 'selected' : ''; ?>>EEE</option>
                                <option value="Mechanical" <?php echo ($_GET['department'] ?? '') == 'Mechanical' ? 'selected' : ''; ?>>Mechanical</option>
                                <option value="ECE" <?php echo ($_GET['department'] ?? '') == 'ECE' ? 'selected' : ''; ?>>ECE</option>
                                <option value="Textile Technology" <?php echo ($_GET['department'] ?? '') == 'Textile Technology' ? 'selected' : ''; ?>>Textile</option>
                                <option value="Science and Humanities" <?php echo ($_GET['department'] ?? '') == 'Science and Humanities' ? 'selected' : ''; ?>>Sci & Hum</option>
                            </select>
                        </div>
                        <div class="col-auto">
                            <select name="year" class="form-select form-select-sm" onchange="this.form.submit()">
                                <option value="">Year</option>
                                <option value="1" <?php echo ($_GET['year'] ?? '') == '1' ? 'selected' : ''; ?>>1st</option>
                                <option value="2" <?php echo ($_GET['year'] ?? '') == '2' ? 'selected' : ''; ?>>2nd</option>
                                <option value="3" <?php echo ($_GET['year'] ?? '') == '3' ? 'selected' : ''; ?>>3rd</option>
                            </select>
                        </div>
                        <div class="col-auto">
                            <select name="status" class="form-select form-select-sm" onchange="this.form.submit()">
                                <option value="">Status</option>
                                <option value="active" <?php echo ($_GET['status'] ?? '') == 'active' ? 'selected' : ''; ?>>Active</option>
                                <option value="inactive" <?php echo ($_GET['status'] ?? '') == 'inactive' ? 'selected' : ''; ?>>Debarred / Inactive</option>
                            </select>
                        </div>
                        <div class="col-auto">
                             <a href="admin_users.php" class="btn btn-outline-secondary btn-sm" title="Reset Filters"><i class="fas fa-undo"></i></a>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="card-body p-0">
            <!-- Loading Users Query (Moved here for logic flow) -->
            <?php
            $where_clauses = ["1=1"];
            if (!empty($_GET['search'])) {
                $search = $conn->real_escape_string($_GET['search']);
                $where_clauses[] = "(u.email LIKE '%$search%' OR s.name LIKE '%$search%' OR t.name LIKE '%$search%')";
            }
            if (!empty($_GET['department'])) {
                $dept = $conn->real_escape_string($_GET['department']);
                $where_clauses[] = "(s.department = '$dept' OR t.department = '$dept')";
            }
            if (!empty($_GET['role'])) {
                $role = $conn->real_escape_string($_GET['role']);
                $where_clauses[] = "u.role = '$role'";
            }
            if (!empty($_GET['year'])) {
                $year = intval($_GET['year']);
                if ($year == 1) $sem_clause = "s.semester IN (1, 2)";
                elseif ($year == 2) $sem_clause = "s.semester IN (3, 4)";
                elseif ($year == 3) $sem_clause = "s.semester IN (5, 6)";
                $where_clauses[] = $sem_clause;
            }
            if (!empty($_GET['status'])) {
                $status = $_GET['status'];
                if ($status == 'active') $where_clauses[] = "u.is_active = 1";
                elseif ($status == 'inactive') $where_clauses[] = "u.is_active = 0";
            }
            $where_sql = implode(' AND ', $where_clauses);
            $users = $conn->query("
                SELECT u.*, 
                       s.name as student_name, s.department as s_dept, s.semester,
                       t.name as teacher_name, t.department as t_dept
                FROM users u
                LEFT JOIN students s ON u.profile_id = s.student_id AND u.role = 'student'
                LEFT JOIN teachers t ON u.profile_id = t.teacher_id AND u.role = 'teacher'
                WHERE $where_sql
                ORDER BY u.created_at DESC
            ");
            ?>
            
             <form method="POST" id="bulkForm" onsubmit="return confirm('Are you sure you want to delete the selected users? This action cannot be undone.');">
                <input type="hidden" name="action" value="delete_selected">

                <!-- Toolbar Actions (Select All / Delete) -->
                <div class="p-3 bg-light border-bottom d-flex justify-content-between align-items-center">
                    <div class="form-check d-flex align-items-center mb-0">
                        <input class="form-check-input me-2" type="checkbox" id="selectAll" onclick="toggleAll(this)">
                        <label class="form-check-label fw-bold" for="selectAll" style="cursor: pointer;">Select All Rows</label>
                        <span class="text-muted ms-2 small">(<?php echo $users->num_rows; ?> found)</span>
                    </div>
                    <button type="submit" class="btn btn-danger btn-sm" id="deleteBtn" disabled>
                        <i class="fas fa-trash me-2"></i>Delete Selected
                    </button>
                </div>

                <div class="table-responsive">
                    <table class="table table-hover mb-0 align-middle">
                        <thead class="bg-light">
                            <tr>
                                <th width="40"></th> <!-- Checkbox column -->
                                <th>User Info</th>
                                <th>Role</th>
                                <th>Department</th>
                                <th>Year</th>
                                <th>Status</th>
                                <th>Joined</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($u = $users->fetch_assoc()): 
                                $name = $u['role'] == 'student' ? $u['student_name'] : 
                                       ($u['role'] == 'teacher' ? $u['teacher_name'] : 'Admin');
                                $dept = $u['role'] == 'student' ? $u['s_dept'] : 
                                       ($u['role'] == 'teacher' ? ($u['t_dept'] ?: 'Not Assigned') : 'System');
                                
                                // Calculate Year
                                $year_display = '-';
                                if ($u['role'] == 'student' && $u['semester']) {
                                    if ($u['semester'] <= 2) $year_display = '1st Year';
                                    elseif ($u['semester'] <= 4) $year_display = '2nd Year';
                                    else $year_display = '3rd Year';
                                }
                                
                                // Status Badge
                                $status_text = 'Active';
                                $status_class = 'bg-success bg-opacity-10 text-success';
                                
                                if (!($u['is_active'] ?? 1)) {
                                    if ($u['role'] == 'student') {
                                        $status_text = 'Debarred';
                                        $status_class = 'bg-danger bg-opacity-10 text-danger';
                                    } else {
                                        $status_text = 'Inactive';
                                        $status_class = 'bg-secondary bg-opacity-10 text-secondary';
                                    }
                                }
                                
                                $status_badge = "<span class=\"badge $status_class px-3 rounded-pill\">$status_text</span>";
                                
                                $avatar_initial = strtoupper(substr($name ?? 'U', 0, 1));
                                $role_badge_class = $u['role'] == 'student' ? 'bg-info bg-opacity-10 text-info' : 
                                                   ($u['role'] == 'teacher' ? 'bg-warning bg-opacity-10 text-warning' : 'bg-primary bg-opacity-10 text-primary');
                            ?>
                            <tr>
                                <td>
                                    <?php if($u['role'] != 'admin'): ?>
                                    <div class="form-check">
                                        <input class="form-check-input user-checkbox" type="checkbox" name="selected_users[]" value="<?php echo $u['user_id']; ?>" onclick="updateDeleteBtn()">
                                    </div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="avatar-sm rounded-circle bg-light d-flex align-items-center justify-content-center me-3 text-primary fw-bold" style="width: 35px; height: 35px;">
                                            <?php echo $avatar_initial; ?>
                                        </div>
                                        <div>
                                            <div class="fw-bold text-dark"><?php echo htmlspecialchars($name); ?></div>
                                            <div class="small text-muted"><?php echo htmlspecialchars($u['email']); ?></div>
                                        </div>
                                    </div>
                                </td>
                                <td><span class="badge <?php echo $role_badge_class; ?> rounded-pill px-3"><?php echo ucfirst($u['role']); ?></span></td>
                                <td class="text-muted"><?php echo htmlspecialchars($dept); ?></td>
                                <td><?php echo $year_display; ?></td>
                                <td><?php echo $status_badge; ?></td>
                                <td class="text-muted small"><?php echo date('M d, Y', strtotime($u['created_at'])); ?></td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </form>
        </div>
    </div>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
function toggleAll(source) {
    const checkboxes = document.querySelectorAll('.user-checkbox');
    checkboxes.forEach(cb => cb.checked = source.checked);
    updateDeleteBtn();
}

function updateDeleteBtn() {
    const checkedCount = document.querySelectorAll('.user-checkbox:checked').length;
    const deleteBtn = document.getElementById('deleteBtn');
    if (checkedCount > 0) {
        deleteBtn.removeAttribute('disabled');
        deleteBtn.innerHTML = `<i class="fas fa-trash me-2"></i>Delete Selected (${checkedCount})`;
    } else {
        deleteBtn.setAttribute('disabled', 'disabled');
        deleteBtn.innerHTML = `<i class="fas fa-trash me-2"></i>Delete Selected`;
    }
}
</script>
