<?php
// admin_subjects.php - Manage Subjects & Faculty
require_once '../includes/db_connect.php';
check_login(['admin']);

// Filters
$dept = $_GET['dept'] ?? 'Computer'; 
$sem = isset($_GET['sem']) ? $_GET['sem'] : 1; // Allow 'all'

$departments = ['Civil', 'Computer', 'EEE', 'Mechanical', 'ECE', 'Textile Technology', 'Science and Humanities'];
$all_semesters = [1, 2, 3, 4, 5, 6];

$message = '';
$error = '';
$csrf_token = generate_csrf_token();

// Logic
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_subject'])) {
    $code = sanitize_input($_POST['code']);
    $name = sanitize_input($_POST['name']);
    $credits = intval($_POST['credits']);
    $type = sanitize_input($_POST['type']);
    
    $check = $conn->query("SELECT subject_id FROM subjects WHERE subject_code='$code'");
    if($check->num_rows > 0) $error = "Subject Code exists.";
    else {
        // Default to sem 1 if 'all' is selected during adding
        $add_sem = ($sem == 'all') ? 1 : intval($sem);
        $stmt = $conn->prepare("INSERT INTO subjects (subject_code, subject_name, department, semester, credits, subject_type) VALUES (?,?,?,?,?,?)");
        $stmt->bind_param("sssiss", $code, $name, $dept, $add_sem, $credits, $type);
        if($stmt->execute()) $message = "Subject added.";
    }
}
elseif ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['assign_faculty'])) {
    $sub_code = sanitize_input($_POST['subject_code']);
    $teacher_id = intval($_POST['teacher_id']);
    $val = ($teacher_id > 0) ? $teacher_id : "NULL";
    $conn->query("UPDATE subjects SET teacher_id = $val, assigned_teacher_id = $val WHERE subject_code = '$sub_code'");
    $message = "Faculty updated.";
}
elseif ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_subject'])) {
    $sid = intval($_POST['subject_id']);
    $conn->query("DELETE FROM subjects WHERE subject_id=$sid");
    $message = "Subject deleted.";
}

// Data Fetch
$search_q = isset($_GET['search']) ? sanitize_input($_GET['search']) : '';
$search_sql = "";
if($search_q) {
    $search_sql = " AND (s.subject_name LIKE '%$search_q%' OR s.subject_code LIKE '%$search_q%' OR t.name LIKE '%$search_q%')";
}

// Sem SQL
$sem_sql = ($sem == 'all') ? "" : "AND s.semester=" . intval($sem);

$subjects_res = $conn->query("SELECT s.*, t.name as teacher_name FROM subjects s LEFT JOIN teachers t ON s.teacher_id = t.teacher_id WHERE s.department='$dept' $sem_sql $search_sql ORDER BY s.semester, s.subject_code");

$dept_teachers = [];
$tr = $conn->query("SELECT teacher_id, name, teacher_role FROM teachers WHERE department='$dept' OR teacher_role='Principal' ORDER BY name");
while($t=$tr->fetch_assoc()) $dept_teachers[] = $t;

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Subjects - Chendhuran SIS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../includes/css/styles.css" rel="stylesheet">
</head>
<body>
<?php include '../includes/sidebar.php'; ?>

<main class="main-content">
    
    <div class="glass-header mb-0 rounded-bottom-0 pb-3">
        <div class="d-flex justify-content-between align-items-center mb-3">
             <h4 class="fw-bold mb-0">Manage Subjects</h4>
        </div>
        
        <!-- Filters -->
         <div class="d-flex gap-3 align-items-center p-3 bg-white rounded shadow-sm border">
            <div class="d-flex align-items-center gap-2">
                <i class="fas fa-filter text-muted"></i>
                <label class="fw-bold small">Department:</label>
                <select class="form-select form-select-sm" onchange="location.href='?dept='+this.value+'&sem=<?php echo $sem; ?>'" style="max-width: 200px;">
                    <?php foreach($departments as $d): ?>
                    <option value="<?php echo $d; ?>" <?php echo ($dept == $d) ? 'selected' : ''; ?>>
                        <?php echo $d; ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="vr"></div>
            <div class="d-flex align-items-center gap-2">
                <label class="fw-bold small">Semester:</label>
                <select class="form-select form-select-sm" style="width: 140px;" onchange="location.href='?dept=<?php echo $dept; ?>&sem='+this.value">
                    <option value="all" <?php echo $sem=='all'?'selected':''; ?>>All Semesters</option>
                    <?php foreach($all_semesters as $s): ?>
                    <option value="<?php echo $s; ?>" <?php echo $sem==$s?'selected':''; ?>>Sem <?php echo $s; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="vr"></div>
            <!-- Search -->
            <form method="GET" class="d-flex align-items-center gap-2">
                <input type="hidden" name="dept" value="<?php echo $dept; ?>">
                <input type="hidden" name="sem" value="<?php echo $sem; ?>">
                <div class="input-group input-group-sm">
                     <span class="input-group-text bg-light"><i class="fas fa-search text-muted"></i></span>
                     <input type="text" name="search" class="form-control text-start" placeholder="Search..." value="<?php echo htmlspecialchars($search_q); ?>">
                </div>
            </form>
        </div>
    </div>

    <div class="glass-card rounded-top-0 border-top-0 p-4">
        <?php if($message): ?><div class="alert alert-success alert-dismissible fade show"><?php echo $message; ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div><?php endif; ?>
        <?php if($error): ?><div class="alert alert-danger alert-dismissible fade show"><?php echo $error; ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div><?php endif; ?>

        <!-- Content -->
         <div class="row">
            <div class="col-12">
                <div class="block-header d-flex justify-content-between mb-3">
                    <span class="text-secondary fw-bold text-uppercase small"><i class="fas fa-book me-2"></i>Curriculum: <?php echo $dept; ?> - <?php echo ($sem == 'all') ? 'All Sems' : "Sem $sem"; ?></span>
                    <button class="btn btn-sm btn-outline-primary py-0" data-bs-toggle="collapse" data-bs-target="#addSubForm"><i class="fas fa-plus me-1"></i>Add Subject</button>
                </div>
                
                <!-- Add Subject (Collapsible) -->
                <div class="collapse mb-3" id="addSubForm">
                    <div class="card card-body bg-light border-0">
                        <form method="POST" class="row g-2 align-items-end">
                            <div class="col-md-2">
                                <label class="small text-muted">Code</label>
                                <input type="text" name="code" class="form-control form-control-sm" required>
                            </div>
                            <div class="col-md-3">
                                <label class="small text-muted">Name</label>
                                <input type="text" name="name" class="form-control form-control-sm" required>
                            </div>
                            <div class="col-md-2">
                                <label class="small text-muted">Type</label>
                                <select name="type" class="form-select form-select-sm">
                                    <option>Theory</option><option>Practical</option><option>Project</option>
                                </select>
                            </div>
                            <div class="col-md-1">
                                <label class="small text-muted">Credits</label>
                                <input type="number" name="credits" class="form-control form-control-sm" value="3">
                            </div>
                            <div class="col-md-2">
                                <button type="submit" name="add_subject" class="btn btn-primary btn-sm w-100">Add</button>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Subjects List -->
                <div class="card border-0 shadow-sm">
                    <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light"><tr><th>Code</th><th>Subject Name</th><th>Type</th><th>Faculty</th><th>Action</th></tr></thead>
                        <tbody>
                            <?php if($subjects_res->num_rows > 0): ?>
                                <?php while($s = $subjects_res->fetch_assoc()): ?>
                                <tr>
                                    <td class="fw-bold text-primary"><?php echo $s['subject_code']; ?></td>
                                    <td><?php echo $s['subject_name']; ?></td>
                                    <td>
                                        <span class="badge <?php echo $s['subject_type']=='Practical'?'bg-warning text-dark':'bg-secondary'; ?> user-select-none">
                                            <?php echo $s['subject_type']; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <form method="POST" class="d-flex align-items-center">
                                            <input type="hidden" name="subject_code" value="<?php echo $s['subject_code']; ?>">
                                            <input type="hidden" name="assign_faculty" value="1">
                                            <select name="teacher_id" class="form-select form-select-sm" onchange="this.form.submit()" style="min-width: 150px;">
                                                <option value="0" class="text-muted">-- Unassigned --</option>
                                                <?php foreach($dept_teachers as $dt): ?>
                                                    <option value="<?php echo $dt['teacher_id']; ?>" <?php echo $s['teacher_id']==$dt['teacher_id']?'selected':''; ?>>
                                                        <?php echo $dt['name']; ?> <?php if(isset($dt['teacher_role']) && $dt['teacher_role'] == 'Principal') echo '(Principal)'; ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                        </form>
                                    </td>
                                    <td>
                                        <form method="POST" onsubmit="return confirm('Delete Subject?');">
                                            <input type="hidden" name="subject_id" value="<?php echo $s['subject_id']; ?>">
                                            <button type="submit" name="delete_subject" class="btn btn-light btn-sm text-danger"><i class="fas fa-trash"></i></button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr><td colspan="5" class="text-center py-4 text-muted">No subjects defined for <?php echo $dept; ?> Sem <?php echo $sem; ?>.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
