<?php
// admin/admin_teacher_assignments.php - Teacher Role Management (Role-First Design)
require_once '../includes/db_connect.php';
check_login(['admin']);

// Handle AJAX requests
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    
    if (!verify_csrf_token($_POST['csrf_token'])) {
        echo json_encode(['success' => false, 'message' => 'Invalid request']);
        exit;
    }
    
    $action = $_POST['action'];
    
    if ($action == 'update_teacher_role') {
        $teacher_id = (int)$_POST['teacher_id'];
        $role = sanitize_input($_POST['role']);
        
        // Validate Principal uniqueness
        if ($role == 'Principal') {
            $existing_principal = $conn->query("SELECT teacher_id, name FROM teachers WHERE teacher_role = 'Principal' AND teacher_id != $teacher_id");
            if ($existing_principal && $existing_principal->num_rows > 0) {
                $principal = $existing_principal->fetch_assoc();
               echo json_encode([
                    'success' => false,
                    'message' => "A Principal already exists: {$principal['name']}. Please remove them first."
                ]);
                exit;
            }
        }
        
        // Validate HOD uniqueness per department
        if ($role == 'HOD') {
            $teacher_dept_query = $conn->query("SELECT department FROM teachers WHERE teacher_id = $teacher_id");
            if ($teacher_dept_query && $teacher_dept_query->num_rows > 0) {
                $teacher_dept = $teacher_dept_query->fetch_assoc()['department'];
                
                $existing_hod = $conn->query("SELECT teacher_id, name FROM teachers WHERE teacher_role = 'HOD' AND department = '$teacher_dept' AND teacher_id != $teacher_id");
                if ($existing_hod && $existing_hod->num_rows > 0) {
                    $hod = $existing_hod->fetch_assoc();
                    echo json_encode([
                        'success' => false,
                        'message' => "HOD for $teacher_dept already exists: {$hod['name']}."
                    ]);
                    exit;
                }
            }
        }
        
        $stmt = $conn->prepare("UPDATE teachers SET teacher_role = ? WHERE teacher_id = ?");
        $stmt->bind_param("si", $role, $teacher_id);
        $success = $stmt->execute();
        $stmt->close();
        
        if ($success) {
            log_activity($_SESSION['user_id'], 'UPDATE_TEACHER_ROLE', "Set teacher ID $teacher_id role to $role");
        }
        
        echo json_encode([
            'success' => $success,
            'message' => $success ? 'Role updated successfully' : 'Failed to update role'
        ]);
        exit;
    }
}

// Fetch data
$departments = ['Civil', 'Computer', 'EEE', 'Mechanical', 'ECE', 'Textile Technology', 'Science and Humanities'];

// Get current principal
$principal_query = $conn->query("SELECT teacher_id, name, department FROM teachers WHERE teacher_role = 'Principal'");
$current_principal = $principal_query && $principal_query->num_rows > 0 ? $principal_query->fetch_assoc() : null;

// Get all teachers
$all_teachers = $conn->query("SELECT teacher_id, name, department, teacher_role FROM teachers ORDER BY name");

// Get HODs by department
$hods = [];
$hod_query = $conn->query("SELECT teacher_id, name, department FROM teachers WHERE teacher_role = 'HOD' ORDER BY department");
while ($hod_query && $hod = $hod_query->fetch_assoc()) {
    $hods[$hod['department']] = $hod;
}

// Get department for default view
$selected_dept = $_GET['dept'] ?? 'Computer';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Teacher Role Management - Chendhuran SIS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;800&display=swap" rel="stylesheet">
    <link href="../includes/css/styles.css" rel="stylesheet">
</head>
<body>
<?php include '../includes/sidebar.php'; ?>

<main class="main-content">
    <!-- Header with Action Button -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h3 class="fw-bold mb-1">Teacher Role Management</h3>
            <p class="text-muted mb-0">Configure roles and permissions for your teaching staff</p>
        </div>
        <a href="admin_class_mentor_assignments.php" class="btn btn-primary btn-lg">
            <i class="fas fa-users-cog me-2"></i>Assign Class Mentors by Year
        </a>
    </div>

    <!-- Top Row: Principal & Quick Stats -->
    <div class="row g-4 mb-4">
        <!-- Principal Card -->
        <div class="col-md-8">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center mb-3">
                        <div class="rounded-circle bg-danger bg-opacity-10 p-3 me-3">
                            <i class="fas fa-crown fa-2x text-danger"></i>
                        </div>
                        <div>
                            <h5 class="fw-bold mb-0">Principal</h5>
                            <small class="text-muted">Institutional Head</small>
                        </div>
                    </div>
                    
                    <?php if ($current_principal): ?>
                        <div class="alert alert-success border-success mb-3">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <strong><?php echo htmlspecialchars($current_principal['name']); ?></strong>
                                    <br>
                                    <small class="text-muted"><?php echo $current_principal['department']; ?> Department</small>
                                </div>
                                <button class="btn btn-sm btn-outline-danger" onclick="removePrincipal()">
                                    <i class="fas fa-times me-1"></i>Remove
                                </button>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-warning border-warning mb-3">
                            <i class="fas fa-exclamation-triangle me-2"></i>No Principal assigned yet
                        </div>
                    <?php endif; ?>
                    
                    <select class="form-select" id="principalSelect" onchange="assignPrincipal(this.value)">
                        <option value="">-- Select Principal --</option>
                        <?php 
                        $all_teachers->data_seek(0);
                        while ($t = $all_teachers->fetch_assoc()): 
                            $selected = ($current_principal && $current_principal['teacher_id'] == $t['teacher_id']) ? 'selected' : '';
                        ?>
                            <option value="<?php echo $t['teacher_id']; ?>" <?php echo $selected; ?>>
                                <?php echo htmlspecialchars($t['name']); ?> (<?php echo $t['department']; ?>)
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
            </div>
        </div>

        <!-- Quick Stats -->
        <div class="col-md-4">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body">
                    <h6 class="fw-bold mb-3">Quick Stats</h6>
                    <div class="mb-3">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <span class="text-muted">Total Teachers</span>
                            <span class="badge bg-primary fs-6">
                                <?php echo $all_teachers->num_rows; ?>
                            </span>
                        </div>
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <span class="text-muted">HODs Assigned</span>
                            <span class="badge bg-success fs-6">
                                <?php echo count($hods); ?>/<?php echo count($departments); ?>
                            </span>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="text-muted">Class Mentors</span>
                            <span class="badge bg-warning fs-6">
                                <?php 
                                $all_teachers->data_seek(0);
                                $cm_count = 0;
                                while ($t = $all_teachers->fetch_assoc()) {
                                    if ($t['teacher_role'] == 'Class Mentor') $cm_count++;
                                }
                                echo $cm_count;
                                ?>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- HOD Section - Compact Table -->
    <div class="card border-0 shadow-sm mb-4">
        <div class="card-header bg-white border-bottom py-3">
            <div class="d-flex align-items-center">
                <div class="rounded-circle bg-success bg-opacity-10 p-2 me-3">
                    <i class="fas fa-user-tie text-success"></i>
                </div>
                <div>
                    <h5 class="fw-bold mb-0">Heads of Department</h5>
                    <small class="text-muted">One HOD per department</small>
                </div>
            </div>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead class="table-light">
                        <tr>
                            <th width="25%">Department</th>
                            <th width="35%">Current HOD</th>
                            <th width="35%">Assign HOD</th>
                            <th width="5%"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($departments as $dept): 
                            $current_hod = $hods[$dept] ?? null;
                        ?>
                        <tr>
                            <td class="fw-semibold"><?php echo $dept; ?></td>
                            <td>
                                <?php if ($current_hod): ?>
                                    <span class="text-success">
                                        <i class="fas fa-check-circle me-1"></i>
                                        <?php echo htmlspecialchars($current_hod['name']); ?>
                                    </span>
                                <?php else: ?>
                                    <span class="text-muted">
                                        <i class="fas fa-minus-circle me-1"></i>Not assigned
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <select class="form-select form-select-sm" onchange="assignHOD('<?php echo $dept; ?>', this.value)">
                                    <option value="">-- Select Teacher --</option>
                                    <?php 
                                    $all_teachers->data_seek(0);
                                    while ($t = $all_teachers->fetch_assoc()): 
                                        if ($t['department'] == $dept):
                                            if ($t['teacher_role'] == 'Teacher' || $t['teacher_role'] == 'Class Mentor' || 
                                                ($current_hod && $current_hod['teacher_id'] == $t['teacher_id'])):
                                                $selected = ($current_hod && $current_hod['teacher_id'] == $t['teacher_id']) ? 'selected' : '';
                                    ?>
                                                <option value="<?php echo $t['teacher_id']; ?>" <?php echo $selected; ?>>
                                                    <?php echo htmlspecialchars($t['name']); ?>
                                                </option>
                                    <?php 
                                            endif;
                                        endif;
                                    endwhile; 
                                    ?>
                                </select>
                            </td>
                            <td>
                                <?php if ($current_hod): ?>
                                    <button class="btn btn-sm btn-outline-danger" onclick="removeHOD('<?php echo $dept; ?>')">
                                        <i class="fas fa-times"></i>
                                    </button>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Class Mentors & Department Staff Side by Side -->
    <div class="row g-4">
        <!-- Class Mentors -->
        <div class="col-md-6">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-header bg-white border-bottom py-3">
                    <div class="d-flex align-items-center justify-content-between">
                        <div class="d-flex align-items-center">
                            <div class="rounded-circle bg-warning bg-opacity-10 p-2 me-3">
                                <i class="fas fa-user-graduate text-warning"></i>
                            </div>
                            <div>
                                <h5 class="fw-bold mb-0">Class Mentors</h5>
                                <small class="text-muted"><?php echo $cm_count; ?> assigned</small>
                            </div>
                        </div>
                        <select class="form-select w-auto form-select-sm" onchange="window.location.href='?cm_dept=' + this.value + '&dept=<?php echo $selected_dept; ?>'">
                            <option value="">All Departments</option>
                            <?php 
                            $cm_dept_filter = $_GET['cm_dept'] ?? '';
                            foreach ($departments as $d): 
                            ?>
                                <option value="<?php echo $d; ?>" <?php echo $cm_dept_filter == $d ? 'selected' : ''; ?>>
                                    <?php echo $d; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="card-body" style="max-height: 400px; overflow-y: auto;">
                    <?php
                    // Pre-fetch assigned years for all mentors
                    $mentor_assignments = [];
                    $assign_query = $conn->query("
                        SELECT class_teacher_id, MAX(semester) as max_sem 
                        FROM students 
                        WHERE class_teacher_id IS NOT NULL 
                        GROUP BY class_teacher_id
                    ");
                    if ($assign_query) {
                        while ($row = $assign_query->fetch_assoc()) {
                            $sem = $row['max_sem'];
                            $year = ceil($sem / 2);
                            $mentor_assignments[$row['class_teacher_id']] = $year;
                        }
                    }

                    $all_teachers->data_seek(0);
                    $has_mentors = false;
                    while ($t = $all_teachers->fetch_assoc()):
                        if ($t['teacher_role'] == 'Class Mentor'):
                            // Apply Filter
                            if (!empty($cm_dept_filter) && $t['department'] != $cm_dept_filter) continue;
                            
                            $has_mentors = true;
                            $assigned_year = $mentor_assignments[$t['teacher_id']] ?? '?';
                    ?>

                    <div class="d-flex justify-content-between align-items-center p-3 mb-2 border rounded">
                        <div>
                            <div class="fw-semibold">
                                <?php echo htmlspecialchars($t['name']); ?>
                                <span class="badge bg-info text-dark ms-2" style="font-size: 0.75em;">Year <?php echo $assigned_year; ?></span>
                            </div>
                            <small class="text-muted"><?php echo $t['department']; ?></small>
                        </div>
                        <button class="btn btn-sm btn-outline-secondary" onclick="updateTeacherRole(<?php echo $t['teacher_id']; ?>, 'Teacher')" title="Remove Role">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                    <?php 
                        endif;
                    endwhile; 
                    
                    if (!$has_mentors):
                    ?>
                    <div class="text-center py-4 text-muted">
                        <i class="fas fa-info-circle fa-2x mb-2"></i>
                        <p class="mb-0">No Class Mentors found</p>
                        <?php if(!empty($cm_dept_filter)): ?>
                            <small>In <?php echo $cm_dept_filter; ?></small>
                        <?php else: ?>
                            <small>Assign from Department Staff →</small>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Department Staff -->
        <div class="col-md-6">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-header bg-white border-bottom py-3">
                    <div class="d-flex align-items-center justify-content-between">
                        <div class="d-flex align-items-center">
                            <div class="rounded-circle bg-secondary bg-opacity-10 p-2 me-3">
                                <i class="fas fa-users text-secondary"></i>
                            </div>
                            <h5 class="fw-bold mb-0">Department Staff</h5>
                        </div>
                        <select class="form-select w-auto form-select-sm" onchange="window.location.href='?dept=' + this.value">
                            <?php foreach ($departments as $d): ?>
                                <option value="<?php echo $d; ?>" <?php echo $selected_dept == $d ? 'selected' : ''; ?>>
                                    <?php echo $d; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="card-body" style="max-height: 400px; overflow-y: auto;">
                    <?php
                    $dept_teachers = $conn->query("
                        SELECT teacher_id, name, teacher_role 
                        FROM teachers 
                        WHERE department = '$selected_dept' 
                        ORDER BY CASE WHEN teacher_role = 'HOD' THEN 0 ELSE 1 END, name
                    ");
                    
                    if ($dept_teachers && $dept_teachers->num_rows > 0):
                        while ($teacher = $dept_teachers->fetch_assoc()):
                            // Show HOD badge for HODs, Teacher for everyone else
                            $display_role = ($teacher['teacher_role'] == 'HOD') ? 'HOD' : 'Teacher';
                            $badge_color = ($teacher['teacher_role'] == 'HOD') ? 'success' : 'secondary';
                    ?>
                        <div class="d-flex justify-content-between align-items-center p-2 mb-2 border-bottom">
                            <div class="flex-grow-1">
                                <div class="fw-semibold"><?php echo htmlspecialchars($teacher['name']); ?></div>
                                <span class="badge bg-<?php echo $badge_color; ?> badge-sm"><?php echo $display_role; ?></span>
                            </div>
                        </div>
                    <?php 
                        endwhile;
                    else: 
                    ?>
                        <div class="text-center py-4 text-muted">
                            <i class="fas fa-users-slash fa-2x mb-2"></i>
                            <p>No teachers in this department</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
const csrfToken = '<?php echo generate_csrf_token(); ?>';

function assignPrincipal(teacherId) {
    if (!teacherId) {
        alert('Please select a teacher');
        return;
    }
    
    if (!confirm('Assign this teacher as Principal?')) {
        location.reload();
        return;
    }
    
    updateTeacherRole(teacherId, 'Principal');
}

function removePrincipal() {
    const principalSelect = document.getElementById('principalSelect');
    const teacherId = principalSelect.value;
    
    if (!confirm('Remove current Principal?')) return;
    
    updateTeacherRole(teacherId, 'Teacher');
}

function assignHOD(department, teacherId) {
    if (!teacherId) return;
    
    if (!confirm(`Assign this teacher as HOD for ${department}?`)) {
        location.reload();
        return;
    }
    
    updateTeacherRole(teacherId, 'HOD');
}

function removeHOD(department) {
    const row = event.target.closest('tr');
    const select = row.querySelector('select');
    const teacherId = select.value;
    
    if (!confirm(`Remove HOD for ${department}?`)) return;
    
    updateTeacherRole(teacherId, 'Teacher');
}

function updateTeacherRole(teacherId, role) {
    const formData = new FormData();
    formData.append('action', 'update_teacher_role');
    formData.append('teacher_id', teacherId);
    formData.append('role', role);
    formData.append('csrf_token', csrfToken);
    
    fetch('admin_teacher_assignments.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            location.reload();
        } else {
            alert('Error: ' + data.message);
            location.reload();
        }
    })
    .catch(error => {
        alert('Network error occurred');
        console.error(error);
        location.reload();
    });
}

function bulkAssignClassMentor(event) {
    event.preventDefault();
    
    const form = event.target;
    const formData = new FormData(form);
    formData.append('action', 'bulk_assign');
    formData.append('csrf_token', csrfToken);
    
    const dept = formData.get('department');
    const sem = formData.get('semester');
    
    if (!confirm(`Assign this class mentor to ALL students in ${dept} Semester ${sem}?`)) {
        return;
    }
    
    fetch('admin_teacher_assignments.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        alert(data.message);
        if (data.success) {
            form.reset();
            location.reload();
        }
    })
    .catch(error => {
        alert('Network error occurred');
        console.error(error);
    });
}
</script>
</body>
</html>
