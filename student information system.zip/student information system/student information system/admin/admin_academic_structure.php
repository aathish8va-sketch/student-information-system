<?php
// admin_academic_structure.php - Academic Calendar & Curriculum
require_once '../includes/db_connect.php';
check_login(['admin']);

// ==========================================
// 1. GLOBAL STATE & LOGIC
// ==========================================
$message = '';
$error = '';

// Get Active/Selected Academic Year
$default_year = $conn->query("SELECT * FROM academic_years WHERE is_active=1 LIMIT 1")->fetch_assoc();
$selected_year_id = isset($_GET['year']) ? intval($_GET['year']) : ($default_year['year_id'] ?? 0);

// Fetch Selected Year Data
$curr_year = null;
if($selected_year_id) {
    $curr_year = $conn->query("SELECT * FROM academic_years WHERE year_id=$selected_year_id")->fetch_assoc();
}

// Curriculum Filters
$dept = $_GET['dept'] ?? 'CSE'; // Default Department
$sem = isset($_GET['sem']) ? intval($_GET['sem']) : 1; // Default Semester for Curriculum
$departments = ['CSE', 'MECH', 'CIVIL', 'EEE', 'ECE'];
$all_semesters = [1, 2, 3, 4, 5, 6];

// ==========================================
// 2. ACTIONS
// ==========================================

// A. SAVE ACADEMIC YEAR DATES
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['save_year'])) {
    $y_start = sanitize_input($_POST['start_date']);
    $y_end = sanitize_input($_POST['end_date']);
    $y_id = intval($_POST['year_id']);
    
    if ($y_start && $y_end) {
        $stmt = $conn->prepare("UPDATE academic_years SET start_date=?, end_date=? WHERE year_id=?");
        $stmt->bind_param("ssi", $y_start, $y_end, $y_id);
        if($stmt->execute()) $message = "Academic Year schedule updated.";
    }
}

// B. SET ACTIVE YEAR
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['set_active'])) {
    $y_id = intval($_POST['year_id']);
    $conn->query("UPDATE academic_years SET is_active=0"); // Reset all
    $conn->query("UPDATE academic_years SET is_active=1 WHERE year_id=$y_id"); // Set new
    $message = "Active Academic Year updated.";
    // Refresh to reflect change
    $default_year = $conn->query("SELECT * FROM academic_years WHERE is_active=1 LIMIT 1")->fetch_assoc();
    $curr_year = $conn->query("SELECT * FROM academic_years WHERE year_id=$y_id")->fetch_assoc();
}

// C. ADD HOLIDAY
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_holiday'])) {
    $h_date = sanitize_input($_POST['holiday_date']);
    $desc = sanitize_input($_POST['description']);
    
    // Validation: Check if date falls within year
    if ($curr_year && ($h_date < $curr_year['start_date'] || $h_date > $curr_year['end_date'])) {
        $error = "Warning: Date $h_date is outside the selected academic year range.";
    }
    
    // Insert anyway (allow flexibility but warn)
    $stmt = $conn->prepare("INSERT IGNORE INTO academic_holidays (holiday_date, description) VALUES (?, ?)");
    $stmt->bind_param("ss", $h_date, $desc);
    if($stmt->execute()) {
        if(!$error) $message = "Holiday added.";
    }
}

// D. DELETE HOLIDAY
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_holiday'])) {
    $hid = intval($_POST['holiday_id']);
    $conn->query("DELETE FROM academic_holidays WHERE holiday_id=$hid");
    $message = "Holiday deleted.";
}

// E. ADD SUBJECT (Curriculum)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_subject'])) {
    $code = sanitize_input($_POST['code']);
    $name = sanitize_input($_POST['name']);
    $credits = intval($_POST['credits']);
    $type = sanitize_input($_POST['type']);
    
    $check = $conn->query("SELECT subject_id FROM subjects WHERE subject_code='$code'");
    if($check->num_rows > 0) $error = "Subject Code exists.";
    else {
        $stmt = $conn->prepare("INSERT INTO subjects (subject_code, subject_name, department, semester, credits, subject_type) VALUES (?,?,?,?,?,?)");
        $stmt->bind_param("sssiss", $code, $name, $dept, $sem, $credits, $type);
        if($stmt->execute()) $message = "Subject added.";
    }
}

// F. DELETE SUBJECT
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_subject'])) {
    $sid = intval($_POST['subject_id']);
    $conn->query("DELETE FROM subjects WHERE subject_id=$sid");
    $message = "Subject deleted.";
}

// F. ASSIGN FACULTY
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['assign_faculty'])) {
    $sub_code = sanitize_input($_POST['subject_code']);
    $teacher_id = intval($_POST['teacher_id']);
    $val = ($teacher_id > 0) ? $teacher_id : "NULL";
    $conn->query("UPDATE subjects SET teacher_id = $val, assigned_teacher_id = $val WHERE subject_code = '$sub_code'"); // Synced columns
    $message = "Faculty updated.";
}

// G. BULK UNASSIGN FACULTY
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['clear_faculty'])) {
    $c_dept = sanitize_input($_POST['dept']);
    $c_sem = intval($_POST['sem']);
    $conn->query("UPDATE subjects SET teacher_id = NULL, assigned_teacher_id = NULL WHERE department = '$c_dept' AND semester = $c_sem");
    $message = "All faculty assignments cleared for $c_dept Sem $c_sem.";
}

// ==========================================
// 3. FETCH DATA
// ==========================================

// All Years
$all_years = $conn->query("SELECT * FROM academic_years ORDER BY year_name DESC");

// Holidays for selected year
$holidays_res = null;
if ($curr_year) {
    $s = $curr_year['start_date'];
    $e = $curr_year['end_date'];
    $holidays_res = $conn->query("SELECT * FROM academic_holidays WHERE holiday_date BETWEEN '$s' AND '$e' ORDER BY holiday_date");
}

// Subjects
$search_q = isset($_GET['search']) ? sanitize_input($_GET['search']) : '';
$search_sql = "";
if($search_q) {
    $search_sql = " AND (s.subject_name LIKE '%$search_q%' OR s.subject_code LIKE '%$search_q%' OR t.name LIKE '%$search_q%')";
}

$subjects_res = $conn->query("SELECT s.*, t.name as teacher_name FROM subjects s LEFT JOIN teachers t ON s.teacher_id = t.teacher_id WHERE s.department='$dept' AND s.semester=$sem $search_sql ORDER BY s.subject_code");

// Teachers (Dept + Principal)
$dept_teachers = [];
$tr = $conn->query("SELECT teacher_id, name, teacher_role FROM teachers WHERE department='$dept' OR teacher_role='Principal' ORDER BY name");
while($t=$tr->fetch_assoc()) $dept_teachers[] = $t;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Academic Configuration</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../includes/css/styles.css" rel="stylesheet">
</head>
<body>
<?php include '../includes/sidebar.php'; ?>

<main class="main-content">
    
    <!-- Header -->
    <div class="glass-header mb-4">
        <div class="d-flex justify-content-between align-items-center">
             <h4 class="fw-bold mb-0">Academic Configuration</h4>
        </div>
    </div>

    <div class="container-fluid">
        <?php if($message): ?><div class="alert alert-success alert-dismissible fade show"><?php echo $message; ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div><?php endif; ?>
        <?php if($error): ?><div class="alert alert-danger alert-dismissible fade show"><?php echo $error; ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div><?php endif; ?>

        <!-- ROW 1: ACADEMIC CALENDAR -->
        <h5 class="text-secondary fw-bold mb-3"><i class="fas fa-calendar-alt me-2"></i>Academic Calendar</h5>
        <div class="row g-4 mb-5">
            
            <!-- 1. ACADEMIC YEAR CONFIGURATION (Row 1) -->
            <div class="col-12">
                <div class="card shadow-sm border-0">
                    <div class="card-header bg-white fw-bold d-flex justify-content-between align-items-center">
                        <span><i class="fas fa-cog me-2 text-primary"></i>Year Configuration</span>
                        <?php if($curr_year && $curr_year['is_active']): ?>
                            <span class="badge bg-success"><i class="fas fa-check-circle me-1"></i>Active Year</span>
                        <?php endif; ?>
                    </div>
                    <div class="card-body">
                        <div class="row g-3 align-items-end">
                            <!-- Select Year -->
                            <div class="col-md-3">
                                <label class="small text-muted fw-bold mb-1">Select Year</label>
                                <div class="dropdown w-100">
                                    <button class="btn btn-outline-secondary w-100 dropdown-toggle d-flex justify-content-between align-items-center bg-white" type="button" data-bs-toggle="dropdown">
                                        <?php echo $curr_year ? $curr_year['year_name'] : 'Select Year'; ?>
                                    </button>
                                    <ul class="dropdown-menu w-100">
                                        <?php 
                                        $all_years->data_seek(0); 
                                        while($y = $all_years->fetch_assoc()): 
                                        ?>
                                        <li><a class="dropdown-item d-flex justify-content-between" href="?year=<?php echo $y['year_id']; ?>&dept=<?php echo $dept; ?>&sem=<?php echo $sem; ?>">
                                            <span><?php echo $y['year_name']; ?></span>
                                            <?php if($y['is_active']): ?><span class="badge bg-success">Active</span><?php endif; ?>
                                        </a></li>
                                        <?php endwhile; ?>
                                    </ul>
                                </div>
                            </div>

                            <?php if($curr_year): ?>
                            <!-- Config Form -->
                            <div class="col-md-9">
                                <form method="POST" class="row g-3 align-items-end">
                                    <input type="hidden" name="year_id" value="<?php echo $curr_year['year_id']; ?>">
                                    
                                    <div class="col-md-3">
                                        <label class="small text-muted fw-bold mb-1">Start Date</label>
                                        <input type="date" name="start_date" class="form-control" value="<?php echo $curr_year['start_date']; ?>">
                                    </div>
                                    <div class="col-md-3">
                                        <label class="small text-muted fw-bold mb-1">End Date</label>
                                        <input type="date" name="end_date" class="form-control" value="<?php echo $curr_year['end_date']; ?>">
                                    </div>
                                    <div class="col-md-3">
                                        <button type="submit" name="save_year" class="btn btn-primary w-100">
                                            <i class="fas fa-save me-1"></i> Update
                                        </button>
                                    </div>
                                    <div class="col-md-3">
                                        <?php if(!$curr_year['is_active']): ?>
                                            <button type="submit" name="set_active" class="btn btn-outline-success w-100">
                                                <i class="fas fa-check me-1"></i> Set Active
                                            </button>
                                        <?php else: ?>
                                            <button type="button" class="btn btn-success w-100 disabled" disabled>
                                                <i class="fas fa-check-double me-1"></i> Active
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </form>
                            </div>
                            <?php else: ?>
                            <div class="col-md-9 d-flex align-items-center text-muted"> <i class="fas fa-arrow-left me-2"></i> Please select a year to configure dates.</div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- 2. Holidays List (Row 2) -->
            <div class="col-12">
                <div class="card shadow-sm border-0 h-100">
                    <div class="card-header bg-white d-flex justify-content-between align-items-center">
                        <span class="fw-bold">Holidays (<?php echo $curr_year ? $curr_year['year_name'] : '-'; ?>)</span>
                        <?php if($curr_year): ?>
                        <span class="badge bg-light text-dark border">
                            <?php echo date('M Y', strtotime($curr_year['start_date'])); ?> - 
                            <?php echo date('M Y', strtotime($curr_year['end_date'])); ?>
                        </span>
                        <?php endif; ?>
                    </div>
                    <div class="card-body d-flex flex-column">
                        <?php if($curr_year): ?>
                        <!-- Add Form -->
                        <form method="POST" class="row g-2 mb-3 bg-light p-2 rounded mx-0">
                            <div class="col-md-4">
                                <input type="date" name="holiday_date" class="form-control form-control-sm" required 
                                       min="<?php echo $curr_year['start_date']; ?>" max="<?php echo $curr_year['end_date']; ?>">
                            </div>
                            <div class="col-md-6">
                                <input type="text" name="description" class="form-control form-control-sm" placeholder="Holiday Name (e.g. Diwali)" required>
                            </div>
                            <div class="col-md-2">
                                <button type="submit" name="add_holiday" class="btn btn-success btn-sm w-100">Add</button>
                            </div>
                        </form>

                        <!-- List -->
                        <div class="flex-grow-1 overflow-auto" style="max-height: 250px;">
                            <table class="table table-hover align-middle mb-0">
                                <thead class="table-light sticky-top"><tr><th>Date</th><th>Day</th><th>Occasion</th><th></th></tr></thead>
                                <tbody>
                                    <?php if($holidays_res && $holidays_res->num_rows > 0): ?>
                                        <?php while($h = $holidays_res->fetch_assoc()): ?>
                                        <tr>
                                            <td class="text-nowrap fw-bold"><?php echo date('d M Y', strtotime($h['holiday_date'])); ?></td>
                                            <td class="text-muted small"><?php echo date('l', strtotime($h['holiday_date'])); ?></td>
                                            <td><?php echo $h['description']; ?></td>
                                            <td class="text-end">
                                                <form method="POST" onsubmit="return confirm('Delete?');">
                                                    <input type="hidden" name="holiday_id" value="<?php echo $h['holiday_id']; ?>">
                                                    <button class="btn btn-link text-danger p-0 btn-sm"><i class="fas fa-trash-alt"></i></button>
                                                </form>
                                            </td>
                                        </tr>
                                        <?php endwhile; ?>
                                    <?php else: ?>
                                        <tr><td colspan="4" class="text-center text-muted py-4">No holidays added for this academic year yet.</td></tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        <?php else: ?>
                            <div class="text-center text-muted py-5">Please select an academic year first.</div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- ROW 2: CURRICULUM / SUBJECTS -->
        <h5 class="text-secondary fw-bold mb-3"><i class="fas fa-book me-2"></i>Curriculum Management</h5>
        <div class="card border-0 shadow-sm mb-5">
            <div class="card-header bg-white py-3">
                <div class="row align-items-center">
                    <div class="col-md-6 d-flex gap-2 align-items-center">
                         <!-- Dept Filter -->
                         <div class="dropdown">
                            <button class="btn btn-outline-secondary dropdown-toggle btn-sm" type="button" data-bs-toggle="dropdown">
                                Dept: <?php echo $dept; ?>
                            </button>
                            <ul class="dropdown-menu">
                                <?php foreach($departments as $d): ?>
                                <li><a class="dropdown-item" href="?year=<?php echo $selected_year_id; ?>&dept=<?php echo $d; ?>&sem=<?php echo $sem; ?>"><?php echo $d; ?></a></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                        <!-- Sem Filter -->
                         <div class="dropdown">
                            <button class="btn btn-outline-secondary dropdown-toggle btn-sm" type="button" data-bs-toggle="dropdown">
                                Semester <?php echo $sem; ?>
                            </button>
                            <ul class="dropdown-menu">
                                <?php foreach($all_semesters as $s): ?>
                                <li><a class="dropdown-item" href="?year=<?php echo $selected_year_id; ?>&dept=<?php echo $dept; ?>&sem=<?php echo $s; ?>">Semester <?php echo $s; ?></a></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                        
                        <!-- Search Bar -->
                        <form method="GET" class="d-flex gap-2 ms-2">
                            <input type="hidden" name="year" value="<?php echo $selected_year_id; ?>">
                            <input type="hidden" name="dept" value="<?php echo $dept; ?>">
                            <input type="hidden" name="sem" value="<?php echo $sem; ?>">
                            <div class="input-group input-group-sm">
                                <span class="input-group-text bg-white border-end-0"><i class="fas fa-search text-muted"></i></span>
                                <input type="text" name="search" class="form-control border-start-0" placeholder="Search..." value="<?php echo htmlspecialchars($search_q); ?>">
                            </div>
                        </form>
                        </div>
                    <div class="col-md-6 text-end">
                        <form method="POST" onsubmit="return confirm('Are you sure you want to REMOVE ALL teachers from subjects in <?php echo $dept; ?> Sem <?php echo $sem; ?>? This cannot be undone.');" style="display:inline-block;">
                            <input type="hidden" name="dept" value="<?php echo $dept; ?>">
                            <input type="hidden" name="sem" value="<?php echo $sem; ?>">
                            <button type="submit" name="clear_faculty" class="btn btn-outline-danger btn-sm me-2">
                                <i class="fas fa-users-slash me-1"></i>Reset Teachers
                            </button>
                        </form>
                        <button class="btn btn-primary btn-sm" data-bs-toggle="collapse" data-bs-target="#addSubForm"><i class="fas fa-plus me-1"></i>Add Subject</button>
                    </div>
                </div>
            </div>

            <!-- Add Subject Form -->
            <div class="collapse" id="addSubForm">
                <div class="card-body bg-light border-bottom">
                    <form method="POST" class="row g-2 align-items-end">
                        <div class="col-md-2">
                            <label class="small text-muted">Code</label>
                            <input type="text" name="code" class="form-control form-control-sm" required>
                        </div>
                        <div class="col-md-3">
                            <label class="small text-muted">Name</label>
                            <input type="text" name="name" class="form-control form-control-sm" required>
                        </div>
                        <div class="col-md-2">
                            <label class="small text-muted">Type</label>
                            <select name="type" class="form-select form-select-sm">
                                <option>Theory</option><option>Practical</option><option>Project</option>
                            </select>
                        </div>
                        <div class="col-md-1">
                            <label class="small text-muted">Credits</label>
                            <input type="number" name="credits" class="form-control form-control-sm" value="3">
                        </div>
                        <div class="col-md-2">
                            <button type="submit" name="add_subject" class="btn btn-success btn-sm w-100">Save</button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Subject List -->
             <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light"><tr><th>Code</th><th>Subject Name</th><th>Type</th><th>Faculty Assigned</th><th>Action</th></tr></thead>
                    <tbody>
                        <?php if($subjects_res->num_rows > 0): ?>
                            <?php while($s = $subjects_res->fetch_assoc()): ?>
                            <tr>
                                <td class="fw-bold text-primary"><?php echo $s['subject_code']; ?></td>
                                <td><?php echo $s['subject_name']; ?></td>
                                <td>
                                    <span class="badge <?php echo $s['subject_type']=='Practical'?'bg-pink':'bg-secondary'; ?> user-select-none">
                                        <?php echo $s['subject_type']; ?>
                                    </span>
                                </td>
                                <td>
                                    <form method="POST" class="d-flex align-items-center">
                                        <input type="hidden" name="subject_code" value="<?php echo $s['subject_code']; ?>">
                                        <input type="hidden" name="assign_faculty" value="1">
                                        <select name="teacher_id" class="form-select form-select-sm border-0 py-0 shadow-none" onchange="this.form.submit()" style="width: 200px; background: transparent;">
                                            <option value="0" class="text-muted">-- Unassigned --</option>
                                            <?php foreach($dept_teachers as $dt): ?>
                                                <option value="<?php echo $dt['teacher_id']; ?>" <?php echo $s['teacher_id']==$dt['teacher_id']?'selected':''; ?>>
                                                    <?php echo $dt['name']; ?> <?php if($dt['teacher_role'] == 'Principal') echo '(Principal)'; ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </form>
                                </td>
                                <td>
                                    <form method="POST" onsubmit="return confirm('Delete Subject?');">
                                        <input type="hidden" name="subject_id" value="<?php echo $s['subject_id']; ?>">
                                        <button type="submit" name="delete_subject" class="btn btn-light btn-sm text-danger"><i class="fas fa-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr><td colspan="5" class="text-center py-5 text-muted">No subjects found for <?php echo $dept; ?> Sem <?php echo $sem; ?>.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</main>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
