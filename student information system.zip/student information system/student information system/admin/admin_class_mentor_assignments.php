<?php
// admin/admin_class_mentor_assignments.php - Class Mentor Assignment by Year
require_once '../includes/db_connect.php';
check_login(['admin']);

// Handle AJAX requests
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    
    if (!verify_csrf_token($_POST['csrf_token'])) {
        echo json_encode(['success' => false, 'message' => 'Invalid request']);
        exit;
    }
    
    $action = $_POST['action'];
    
    if ($action == 'assign_mentor') {
        $department = sanitize_input($_POST['department']);
        $year = (int)$_POST['year'];
        $teacher_id = (int)$_POST['teacher_id'];
        
        // Determine semester range based on year
        $semester_range = [];
        switch ($year) {
            case 1:
                $semester_range = [1, 2];
                break;
            case 2:
                $semester_range = [3, 4];
                break;
            case 3:
                $semester_range = [5, 6];
                break;
            default:
                echo json_encode(['success' => false, 'message' => 'Invalid year']);
                exit;
        }
        
        // Check if this teacher is already assigned to another year in this department
        $check_query = $conn->prepare("
            SELECT DISTINCT 
                CASE 
                    WHEN semester IN (1,2) THEN 1
                    WHEN semester IN (3,4) THEN 2
                    WHEN semester IN (5,6) THEN 3
                END as assigned_year
            FROM students 
            WHERE department = ? 
            AND class_teacher_id = ?
            AND semester IN (1,2,3,4,5,6)
        ");
        $check_query->bind_param("si", $department, $teacher_id);
        $check_query->execute();
        $result = $check_query->get_result();
        
        while ($row = $result->fetch_assoc()) {
            if ($row['assigned_year'] != $year && $row['assigned_year'] !== null) {
                echo json_encode([
                    'success' => false, 
                    'message' => "This teacher is already assigned to Year {$row['assigned_year']} in $department department. Please remove that assignment first."
                ]);
                $check_query->close();
                exit;
            }
        }
        $check_query->close();
        
        // Get the previous mentor for this year/department (if any)
        $prev_mentor_query = $conn->prepare("
            SELECT DISTINCT class_teacher_id 
            FROM students 
            WHERE department = ? 
            AND semester IN (?, ?)
            AND class_teacher_id IS NOT NULL
        ");
        $prev_mentor_query->bind_param("sii", $department, $semester_range[0], $semester_range[1]);
        $prev_mentor_query->execute();
        $prev_result = $prev_mentor_query->get_result();
        $previous_mentor_id = null;
        if ($prev_row = $prev_result->fetch_assoc()) {
            $previous_mentor_id = $prev_row['class_teacher_id'];
        }
        $prev_mentor_query->close();
        
        // Assign new mentor to all students in this year
        $update_students = $conn->prepare("
            UPDATE students 
            SET class_teacher_id = ? 
            WHERE department = ? 
            AND semester IN (?, ?)
        ");
        $update_students->bind_param("isii", $teacher_id, $department, $semester_range[0], $semester_range[1]);
        $success = $update_students->execute();
        $affected_rows = $update_students->affected_rows;
        $update_students->close();
        
        if ($success) {
            // Set new teacher's role to Class Mentor
            $update_role = $conn->prepare("UPDATE teachers SET teacher_role = 'Class Mentor' WHERE teacher_id = ?");
            $update_role->bind_param("i", $teacher_id);
            $update_role->execute();
            $update_role->close();
            
            // Check if previous mentor should be reverted to 'Teacher'
            if ($previous_mentor_id && $previous_mentor_id != $teacher_id) {
                // Check if previous mentor is still assigned to any students
                $check_prev = $conn->prepare("
                    SELECT COUNT(*) as student_count,
                    (SELECT teacher_role FROM teachers WHERE teacher_id = ?) as current_role
                    FROM students 
                    WHERE class_teacher_id = ?
                ");
                $check_prev->bind_param("ii", $previous_mentor_id, $previous_mentor_id);
                $check_prev->execute();
                $prev_result = $check_prev->get_result();
                $prev_data = $prev_result->fetch_assoc();
                $check_prev->close();
                
                // If no students assigned and role is Class Mentor, revert to Teacher
                if ($prev_data['student_count'] == 0 && $prev_data['current_role'] == 'Class Mentor') {
                    $revert_role = $conn->prepare("UPDATE teachers SET teacher_role = 'Teacher' WHERE teacher_id = ?");
                    $revert_role->bind_param("i", $previous_mentor_id);
                    $revert_role->execute();
                    $revert_role->close();
                }
            }
            
            log_activity($_SESSION['user_id'], 'ASSIGN_CLASS_MENTOR', "Assigned teacher ID $teacher_id to Year $year in $department ($affected_rows students)");
            
            echo json_encode([
                'success' => true,
                'message' => "Successfully assigned mentor to $affected_rows students in Year $year"
            ]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to update student assignments']);
        }
        exit;
    }
    
    if ($action == 'remove_mentor') {
        $department = sanitize_input($_POST['department']);
        $year = (int)$_POST['year'];
        
        $semester_range = [];
        switch ($year) {
            case 1:
                $semester_range = [1, 2];
                break;
            case 2:
                $semester_range = [3, 4];
                break;
            case 3:
                $semester_range = [5, 6];
                break;
        }
        
        // Get current mentor
        $get_mentor = $conn->prepare("
            SELECT DISTINCT class_teacher_id 
            FROM students 
            WHERE department = ? 
            AND semester IN (?, ?)
            AND class_teacher_id IS NOT NULL
        ");
        $get_mentor->bind_param("sii", $department, $semester_range[0], $semester_range[1]);
        $get_mentor->execute();
        $mentor_result = $get_mentor->get_result();
        $mentor_id = null;
        if ($mentor_row = $mentor_result->fetch_assoc()) {
            $mentor_id = $mentor_row['class_teacher_id'];
        }
        $get_mentor->close();
        
        // Remove assignment
        $remove_stmt = $conn->prepare("
            UPDATE students 
            SET class_teacher_id = NULL 
            WHERE department = ? 
            AND semester IN (?, ?)
        ");
        $remove_stmt->bind_param("sii", $department, $semester_range[0], $semester_range[1]);
        $success = $remove_stmt->execute();
        $remove_stmt->close();
        
        if ($success && $mentor_id) {
            // Check if mentor should be reverted
            $check_remaining = $conn->prepare("SELECT COUNT(*) as count FROM students WHERE class_teacher_id = ?");
            $check_remaining->bind_param("i", $mentor_id);
            $check_remaining->execute();
            $remaining_result = $check_remaining->get_result();
            $remaining_data = $remaining_result->fetch_assoc();
            $check_remaining->close();
            
            if ($remaining_data['count'] == 0) {
                $revert = $conn->prepare("UPDATE teachers SET teacher_role = 'Teacher' WHERE teacher_id = ? AND teacher_role = 'Class Mentor'");
                $revert->bind_param("i", $mentor_id);
                $revert->execute();
                $revert->close();
            }
            
            log_activity($_SESSION['user_id'], 'REMOVE_CLASS_MENTOR', "Removed mentor from Year $year in $department");
        }
        
        echo json_encode(['success' => $success, 'message' => $success ? 'Mentor removed successfully' : 'Failed to remove mentor']);
        exit;
    }
}

// Fetch departments
$departments = ['Civil', 'Computer', 'EEE', 'Mechanical', 'ECE', 'Textile Technology', 'Science and Humanities'];

// Get current assignments for ALL departments
$all_assignments = [];
foreach ($departments as $dept) {
    $all_assignments[$dept] = [];
    for ($year = 1; $year <= 3; $year++) {
        $sem_start = ($year - 1) * 2 + 1;
        $sem_end = $sem_start + 1;
        
        $query = $conn->prepare("
            SELECT 
                s.class_teacher_id,
                t.name as teacher_name,
                COUNT(s.student_id) as student_count
            FROM students s
            LEFT JOIN teachers t ON s.class_teacher_id = t.teacher_id
            WHERE s.department = ?
            AND s.semester IN (?, ?)
            GROUP BY s.class_teacher_id, t.name
            LIMIT 1
        ");
        $query->bind_param("sii", $dept, $sem_start, $sem_end);
        $query->execute();
        $result = $query->get_result();
        
        if ($row = $result->fetch_assoc()) {
            $all_assignments[$dept][$year] = [
                'teacher_id' => $row['class_teacher_id'],
                'teacher_name' => $row['teacher_name'],
                'student_count' => $row['student_count']
            ];
        } else {
            $all_assignments[$dept][$year] = null;
        }
        $query->close();
    }
}

// Get all teachers grouped by department
$all_teachers = [];
foreach ($departments as $dept) {
    $teachers_query = $conn->prepare("
        SELECT teacher_id, name, teacher_role 
        FROM teachers 
        WHERE department = ? 
        AND teacher_role NOT IN ('Principal', 'HOD')
        ORDER BY name
    ");
    $teachers_query->bind_param("s", $dept);
    $teachers_query->execute();
    $result = $teachers_query->get_result();
    
    $all_teachers[$dept] = [];
    while ($teacher = $result->fetch_assoc()) {
        $all_teachers[$dept][] = $teacher;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Class Mentor Assignments - Chendhuran SIS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;800&display=swap" rel="stylesheet">
    <link href="../includes/css/styles.css" rel="stylesheet">
</head>
<body>
<?php include '../includes/sidebar.php'; ?>

<main class="main-content">
    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h3 class="fw-bold mb-1">Class Mentor Assignments</h3>
            <p class="text-muted mb-0">Assign one mentor per year group in each department</p>
        </div>
        <a href="admin_teacher_assignments.php" class="btn btn-outline-secondary">
            <i class="fas fa-arrow-left me-2"></i>Back to Roles
        </a>
    </div>

    <!-- All Departments Table -->
    <?php foreach ($departments as $dept): 
        $dept_assignments = $all_assignments[$dept];
        $dept_teachers = $all_teachers[$dept];
    ?>
    <div class="card border-0 shadow-sm mb-4">
        <div class="card-header bg-white border-bottom">
            <h5 class="mb-0 fw-bold">
                <i class="fas fa-building me-2 text-primary"></i><?php echo $dept; ?> Department
            </h5>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead class="table-light">
                        <tr>
                            <th width="15%">Year</th>
                            <th width="35%">Current Mentor</th>
                            <th width="40%">Assign Mentor</th>
                            <th width="10%">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php for ($year = 1; $year <= 3; $year++): 
                            $assignment = $dept_assignments[$year];
                            $sem_start = ($year - 1) * 2 + 1;
                            $sem_end = $sem_start + 1;
                        ?>
                        <tr>
                            <td class="align-middle">
                                <div class="d-flex align-items-center">
                                    <div class="rounded-circle bg-primary bg-opacity-10 p-2 me-2">
                                        <i class="fas fa-graduation-cap text-primary"></i>
                                    </div>
                                    <div>
                                        <strong>Year <?php echo $year; ?></strong>
                                        <br>
                                        <small class="text-muted">Sem <?php echo $sem_start; ?>-<?php echo $sem_end; ?></small>
                                    </div>
                                </div>
                            </td>
                            <td class="align-middle">
                                <?php if ($assignment && $assignment['teacher_id']): ?>
                                    <div class="d-flex align-items-center">
                                        <i class="fas fa-check-circle text-success me-2"></i>
                                        <div>
                                            <strong><?php echo htmlspecialchars($assignment['teacher_name']); ?></strong>
                                            <br>
                                            <small class="text-muted">
                                                <i class="fas fa-users me-1"></i><?php echo $assignment['student_count']; ?> students
                                            </small>
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <span class="text-muted">
                                        <i class="fas fa-minus-circle me-1"></i>Not assigned
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td class="align-middle">
                                <select class="form-select" id="mentor-<?php echo $dept; ?>-year-<?php echo $year; ?>" onchange="assignMentor('<?php echo $dept; ?>', <?php echo $year; ?>, this.value)">
                                    <option value="">-- Select Teacher --</option>
                                    <?php 
                                    foreach ($dept_teachers as $teacher):
                                        $is_selected = ($assignment && $assignment['teacher_id'] == $teacher['teacher_id']);
                                        
                                        $check_other = $conn->query("
                                            SELECT DISTINCT 
                                                CASE 
                                                    WHEN semester IN (1,2) THEN 1
                                                    WHEN semester IN (3,4) THEN 2
                                                    WHEN semester IN (5,6) THEN 3
                                                END as assigned_year
                                            FROM students 
                                            WHERE department = '$dept' 
                                            AND class_teacher_id = {$teacher['teacher_id']}
                                        ");
                                        
                                        $is_assigned_elsewhere = false;
                                        while ($check_row = $check_other->fetch_assoc()) {
                                            if ($check_row['assigned_year'] != $year && $check_row['assigned_year'] !== null) {
                                                $is_assigned_elsewhere = true;
                                                break;
                                            }
                                        }
                                    ?>
                                        <option value="<?php echo $teacher['teacher_id']; ?>" 
                                            <?php echo $is_selected ? 'selected' : ''; ?>
                                            <?php echo ($is_assigned_elsewhere && !$is_selected) ? 'disabled' : ''; ?>>
                                            <?php echo htmlspecialchars($teacher['name']); ?>
                                            <?php if ($teacher['teacher_role'] == 'HOD') echo ' (HOD)'; ?>
                                            <?php if ($is_assigned_elsewhere && !$is_selected) echo ' (Assigned to Year ' . $check_row['assigned_year'] . ')'; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td class="align-middle text-center">
                                <?php if ($assignment && $assignment['teacher_id']): ?>
                                    <button class="btn btn-sm btn-outline-danger" onclick="removeMentor('<?php echo $dept; ?>', <?php echo $year; ?>)" title="Remove mentor">
                                        <i class="fas fa-times"></i>
                                    </button>
                                <?php else: ?>
                                    <span class="text-muted">—</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endfor; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
const csrfToken = '<?php echo generate_csrf_token(); ?>';

function assignMentor(department, year, teacherId) {
    if (!teacherId) return;
    
    if (!confirm(`Assign this teacher as Class Mentor for Year ${year} in ${department}?\n\nThis will update ALL students in Year ${year}.`)) {
        document.getElementById(`mentor-${department}-year-${year}`).value = '';
        return;
    }
    
    const formData = new FormData();
    formData.append('action', 'assign_mentor');
    formData.append('department', department);
    formData.append('year', year);
    formData.append('teacher_id', teacherId);
    formData.append('csrf_token', csrfToken);
    
    fetch('admin_class_mentor_assignments.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        alert(data.message);
        if (data.success) {
            location.reload();
        }
    })
    .catch(error => {
        alert('Network error occurred');
        console.error(error);
    });
}

function removeMentor(department, year) {
    if (!confirm(`Remove Class Mentor for Year ${year} in ${department}?`)) return;
    
    const formData = new FormData();
    formData.append('action', 'remove_mentor');
    formData.append('department', department);
    formData.append('year', year);
    formData.append('csrf_token', csrfToken);
    
    fetch('admin_class_mentor_assignments.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        alert(data.message);
        if (data.success) {
            location.reload();
        }
    })
    .catch(error => {
        alert('Network error occurred');
        console.error(error);
    });
}
</script>
</body>
</html>
