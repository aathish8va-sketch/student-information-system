<?php
// admin/student_promotion.php - Student Promotion & Management
require_once '../includes/db_connect.php';
require_once '../includes/year_helpers.php';
check_login(['admin']);

$message = '';
$error = '';

// Handle Bulk Actions
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    $student_ids = $_POST['student_ids'] ?? [];
    
    if (empty($student_ids)) {
        $error = "No students selected.";
    } else {
        $ids_str = implode(',', array_map('intval', $student_ids));
        
        if ($action == 'promote') {
            // Promote to next semester (Only Active Students)
            $stmt = $conn->prepare("
                UPDATE students s 
                LEFT JOIN users u ON s.student_id = u.profile_id AND u.role = 'student'
                SET s.semester = LEAST(s.semester + 1, 6) 
                WHERE s.student_id IN ($ids_str) 
                AND (u.is_active = 1 OR u.is_active IS NULL)
            ");
            $stmt->execute();
            $affected = $stmt->affected_rows;
            $message = "$affected student(s) promoted to next semester successfully. (Debarred students were skipped)";
            
        } elseif ($action == 'debar') {
            // Mark students as inactive/debarred
            $stmt = $conn->prepare("UPDATE users u JOIN students s ON u.profile_id = s.student_id SET u.is_active = 0 WHERE s.student_id IN ($ids_str) AND u.role = 'student'");
            $stmt->execute();
            $message = count($student_ids) . " student(s) debarred successfully.";
            
        } elseif ($action == 'activate') {
            // Reactivate debarred students
            $stmt = $conn->prepare("UPDATE users u JOIN students s ON u.profile_id = s.student_id SET u.is_active = 1 WHERE s.student_id IN ($ids_str) AND u.role = 'student'");
            $stmt->execute();
            $message = count($student_ids) . " student(s) activated successfully.";

        } elseif ($action == 'assign_mentor') {
            // Assign Mentor
            $mentor_id = intval($_POST['mentor_id']);
            if ($mentor_id > 0) {
                // Verify Mentor Dept matches (optional but good) - skipping for speed/trust
                $stmt = $conn->prepare("UPDATE students SET class_teacher_id = ? WHERE student_id IN ($ids_str)");
                $stmt->bind_param("i", $mentor_id);
                $stmt->execute();
                $message = count($student_ids) . " student(s) assigned to new mentor.";
            } else {
                $error = "Invalid mentor selected.";
            }
        }
    }
}

// Filters
$filter_year = isset($_GET['year']) ? intval($_GET['year']) : 0;
$filter_dept = $_GET['dept'] ?? '';
$filter_semester = isset($_GET['semester']) ? intval($_GET['semester']) : 0;

// Build query
$where = ["1=1"];
if ($filter_year) {
    $semesters = get_semesters_for_year($filter_year);
    $where[] = "s.semester IN (" . implode(',', $semesters) . ")";
}
if ($filter_dept) {
    $where[] = "s.department = '" . $conn->real_escape_string($filter_dept) . "'";
}

// Add Status Filter
$filter_status = $_GET['status'] ?? '';
if ($filter_status == 'active') {
    $where[] = "(u.is_active = 1 OR u.is_active IS NULL)";
} elseif ($filter_status == 'debarred') {
    $where[] = "u.is_active = 0";
}

$where_clause = implode(' AND ', $where);

// Fetch students
$students = $conn->query("
    SELECT s.*, u.email, u.is_active, t.name as mentor_name
    FROM students s
    LEFT JOIN users u ON s.student_id = u.profile_id AND u.role = 'student'
    LEFT JOIN teachers t ON s.class_teacher_id = t.teacher_id
    WHERE $where_clause
    ORDER BY s.department, s.semester, s.roll_number
");

$departments = ['Civil', 'Computer', 'EEE', 'Mechanical', 'ECE', 'Textile Technology', 'Science and Humanities'];

// Fetch Teachers grouped by Department for JS (Exclude HODs + Exclude Already Assigned)
$mentors_js = [];

foreach ($departments as $dept) {
    // 1. Get IDs of teachers who already have assignments in this dept
    $assigned_ids = [];
    $check_assigned = $conn->query("SELECT DISTINCT class_teacher_id FROM students WHERE department = '$dept' AND class_teacher_id IS NOT NULL");
    while ($row = $check_assigned->fetch_assoc()) {
        $assigned_ids[] = $row['class_teacher_id'];
    }
    
    // 2. Fetch Teachers excluding HODs AND excluding assigned IDs
    $sql = "SELECT t.teacher_id, t.name 
            FROM teachers t 
            JOIN users u ON t.user_id = u.user_id 
            WHERE t.department = '$dept' 
            AND u.email NOT LIKE 'hod_%'";
            
    if (!empty($assigned_ids)) {
        $sql .= " AND t.teacher_id NOT IN (" . implode(',', $assigned_ids) . ")";
    }
    
    $sql .= " ORDER BY t.name";

    $teachers_query = $conn->query($sql);
    
    while ($teachers_query && $row = $teachers_query->fetch_assoc()) {
        $mentors_js[$dept][] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Promotion - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../includes/css/styles.css" rel="stylesheet">
</head>
<body>
<?php include '../includes/sidebar.php'; ?>

<main class="admin-main">
    <div class="page-header">
        <div>
            <h4 class="mb-1"><i class="fas fa-user-graduate me-2"></i>Student Promotion & Management</h4>
            <p class="text-muted mb-0 text-sm">Filter, select, and promote students</p>
        </div>
    </div>

    <?php if($message): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="fas fa-check-circle me-2"></i><?php echo $message; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <?php if($error): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <i class="fas fa-exclamation-circle me-2"></i><?php echo $error; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- Filters -->
    <div class="card border-0 shadow-sm mb-4">
        <div class="card-header bg-white border-bottom">
            <h6 class="fw-bold mb-0"><i class="fas fa-filter me-2"></i>Filter Students</h6>
        </div>
        <div class="card-body">
            <form method="GET" class="row g-3">
                <div class="col-md-3">
                    <label class="form-label">Year</label>
                    <select name="year" class="form-select">
                        <option value="">All Years</option>
                        <?php for($y=1; $y<=3; $y++): ?>
                            <option value="<?php echo $y; ?>" <?php if($filter_year==$y) echo 'selected'; ?>>
                                <?php echo get_year_label($y); ?>
                            </option>
                        <?php endfor; ?>
                    </select>
                </div>

                <div class="col-md-4">
                    <label class="form-label">Department</label>
                    <select name="dept" class="form-select" onchange="this.form.submit()">
                        <option value="">All Departments</option>
                        <?php foreach($departments as $d): ?>
                            <option value="<?php echo $d; ?>" <?php if($filter_dept==$d) echo 'selected'; ?>>
                                <?php echo $d; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="col-md-3">
                    <label class="form-label">Status</label>
                    <select name="status" class="form-select" onchange="this.form.submit()">
                        <option value="">All Status</option>
                        <option value="active" <?php echo ($filter_status == 'active') ? 'selected' : ''; ?>>Active Only</option>
                        <option value="debarred" <?php echo ($filter_status == 'debarred') ? 'selected' : ''; ?>>Debarred Only</option>
                    </select>
                </div>
                <div class="col-md-2 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-search me-2"></i>Filter
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Students Table with Actions -->
    <div class="card border-0 shadow-sm">
        <div class="card-header bg-white border-bottom d-flex justify-content-between align-items-center">
            <h6 class="fw-bold mb-0">
                Students 
                <?php if($students && $students->num_rows > 0): ?>
                    <span class="badge bg-primary"><?php echo $students->num_rows; ?></span>
                <?php endif; ?>
            </h6>
            <div>
                <button class="btn btn-sm btn-outline-primary" onclick="selectAll()">
                    <i class="fas fa-check-square me-1"></i>Select All
                </button>
            </div>
        </div>
        <div class="card-body p-0">
            <?php if($students && $students->num_rows > 0): ?>
            <form method="POST" id="bulkForm" onsubmit="return confirmAction()">
                <div class="table-responsive">
                    <table class="table table-hover mb-0 align-middle">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-4" style="width: 40px;">
                                    <input type="checkbox" id="selectAllCheckbox" onchange="toggleAll(this)">
                                </th>
                                <th>Roll No</th>
                                <th>Name</th>
                                <th>Department</th>
                                <th>Mentor</th>
                                <th>Current Semester</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($st = $students->fetch_assoc()): ?>
                            <tr>
                                <td class="ps-4">
                                    <input type="checkbox" name="student_ids[]" value="<?php echo $st['student_id']; ?>" class="student-checkbox" data-status="<?php echo $st['is_active'] ? 'active' : 'debarred'; ?>" data-dept="<?php echo $st['department']; ?>">
                                </td>
                                <td><?php echo $st['roll_number']; ?></td>
                                <td>
                                    <span class="fw-medium"><?php echo htmlspecialchars($st['name']); ?></span><br>
                                    <small class="text-muted"><?php echo $st['email']; ?></small>
                                </td>
                                <td><?php echo $st['department']; ?></td>
                                <td>
                                    <?php if($st['mentor_name']): ?>
                                        <span class="text-dark"><i class="fas fa-chalkboard-teacher text-muted me-1"></i><?php echo htmlspecialchars($st['mentor_name']); ?></span>
                                    <?php else: ?>
                                        <span class="badge bg-warning text-dark">Unassigned</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="badge bg-primary">
                                        <?php echo format_year_semester($st['semester']); ?>
                                    </span>
                                </td>
                                <td>
                                    <?php if($st['is_active']): ?>
                                        <span class="badge bg-success">Active</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger">Debarred</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Bulk Actions -->
                <div class="card-footer bg-light border-top">
                    <div class="d-flex gap-2">
                        <button type="submit" name="action" value="promote" class="btn btn-success">
                            <i class="fas fa-arrow-up me-2"></i>Promote to Next Semester
                        </button>
                        <button type="submit" name="action" value="debar" class="btn btn-danger" id="debarBtn" style="display: none;">
                            <i class="fas fa-ban me-2"></i>Debar Selected
                        </button>
                        <button type="submit" name="action" value="activate" class="btn btn-primary" id="activateBtn" style="display: none;">
                            <i class="fas fa-check-circle me-2"></i>Activate Selected
                        </button>
                        <button type="button" class="btn btn-info text-white" id="assignMentorBtn" style="display: none;" onclick="openMentorModal()">
                            <i class="fas fa-user-tag me-2"></i>Assign Mentor
                        </button>
                        <span class="text-muted ms-auto align-self-center" id="selectedCount">0 selected</span>
                    </div>
                </div>

                <!-- Mentor Assignment Modal -->
                <div class="modal fade" id="assignMentorModal" tabindex="-1">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Assign Class Mentor</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                            <div class="modal-body">
                                <p class="text-muted small">Assign a new class mentor to the selected students.</p>
                                <div class="mb-3">
                                    <label class="form-label">Select Mentor</label>
                                    <select name="mentor_id" id="mentorSelect" class="form-select" required>
                                        <option value="">Choose...</option>
                                    </select>
                                    <div class="form-text"> Only teachers from <span id="modalDeptName" class="fw-bold"></span> are shown. HODs are excluded.</div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                <button type="submit" name="action" value="assign_mentor" class="btn btn-primary">Save Assignment</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
            <?php else: ?>
            <div class="text-center py-5">
                <i class="fas fa-users-slash fa-3x text-muted mb-3"></i>
                <p class="text-muted">No students found. Try different filters.</p>
            </div>
            <?php endif; ?>
        </div>
    </div>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
const mentorsDB = <?php echo json_encode($mentors_js); ?>;

function openMentorModal() {
    const checked = document.querySelectorAll('.student-checkbox:checked');
    if (checked.length === 0) return;

    // 1. Enforce Single Department Selection
    let firstDept = checked[0].getAttribute('data-dept');
    let isMixed = false;
    checked.forEach(cb => {
        if (cb.getAttribute('data-dept') !== firstDept) isMixed = true;
    });

    if (isMixed) {
        alert("Action Denied: You can only assign mentors to students from the SAME department at once.\n\nPlease deselect students from other departments.");
        return;
    }

    // 2. Populate Modal with ONLY that Department's Mentors
    const select = document.getElementById('mentorSelect');
    const deptSpan = document.getElementById('modalDeptName');
    
    select.innerHTML = '<option value="">Choose Mentor...</option>';
    deptSpan.textContent = firstDept; // e.g., "Civil"

    if (mentorsDB[firstDept] && mentorsDB[firstDept].length > 0) {
        mentorsDB[firstDept].forEach(m => {
            select.innerHTML += `<option value="${m.teacher_id}">${m.name}</option>`;
        });
    } else {
        select.innerHTML += '<option disabled>All mentors in ' + firstDept + ' are already assigned/occupied.</option>';
    }

    // Show Modal
    new bootstrap.Modal(document.getElementById('assignMentorModal')).show();
}

function toggleAll(checkbox) {
    const checkboxes = document.querySelectorAll('.student-checkbox');
    checkboxes.forEach(cb => cb.checked = checkbox.checked);
    updateSelectedCount();
}

function selectAll() {
    document.getElementById('selectAllCheckbox').checked = true;
    toggleAll(document.getElementById('selectAllCheckbox'));
}

function updateSelectedCount() {
    const checked = document.querySelectorAll('.student-checkbox:checked');
    const count = checked.length;
    document.getElementById('selectedCount').textContent = count + ' selected';
    
    // Determine which button to show based on selected students' status
    const debarBtn = document.getElementById('debarBtn');
    const activateBtn = document.getElementById('activateBtn');
    const assignBtn = document.getElementById('assignMentorBtn');
    
    if (count === 0) {
        // No selection - hide all
        debarBtn.style.display = 'none';
        activateBtn.style.display = 'none';
        assignBtn.style.display = 'none';
    } else {
        assignBtn.style.display = 'inline-block'; // Always valid if count > 0
        
        // ... Logic for Debar/Activate ...
        let hasDebarred = false;
        let hasActive = false;
        
        checked.forEach(cb => {
            const status = cb.getAttribute('data-status');
            if (status === 'debarred') hasDebarred = true;
            if (status === 'active') hasActive = true;
        });
        
        // Show appropriate button
        if (hasDebarred && !hasActive) {
            // Only debarred students selected - show Activate
            debarBtn.style.display = 'none';
            activateBtn.style.display = 'inline-block';
        } else if (hasActive && !hasDebarred) {
            // Only active students selected - show Debar
            debarBtn.style.display = 'inline-block';
            activateBtn.style.display = 'none';
        } else {
            // Mixed selection - show both (or you could hide both)
            debarBtn.style.display = 'inline-block';
            activateBtn.style.display = 'inline-block';
        }
    }
}

// Update count when checkboxes change
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.student-checkbox').forEach(cb => {
        cb.addEventListener('change', updateSelectedCount);
    });
});

function confirmAction() {
    const checked = document.querySelectorAll('.student-checkbox:checked').length;
    if (checked === 0) {
        alert('Please select at least one student.');
        return false;
    }
    
    const action = document.activeElement.value;
    let message = '';
    
    if (action === 'promote') {
        message = `Promote ${checked} student(s) to the next semester?`;
    } else if (action === 'debar') {
        message = `DEBAR ${checked} student(s)? This will deactivate their accounts.`;
    } else if (action === 'activate') {
        message = `ACTIVATE ${checked} student(s)? This will reactivate their accounts.`;
    }
    
    return confirm(message);
}
</script>
</body>
</html>
