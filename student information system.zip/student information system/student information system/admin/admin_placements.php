<?php
// admin_placements.php - Unified Placements & Assignments
require_once '../includes/db_connect.php';
require_once '../includes/year_helpers.php';
check_login(['admin']);

    // Departments - GLOBAL SCOPE
    $departments = ['Civil', 'Computer', 'EEE', 'Mechanical', 'ECE', 'Textile Technology', 'Science and Humanities'];

    $tab = $_GET['tab'] ?? 'promotion';
    $message = '';
    $error = '';
    $csrf_token = generate_csrf_token();


    // ===============================================
    // LOGIC: TAB 1 - STUDENT PROMOTION
    // ===============================================
    if ($tab == 'promotion') {
        $filter_year = isset($_GET['year']) ? intval($_GET['year']) : 0;
        $filter_dept = $_GET['dept'] ?? '';
        $filter_semester = isset($_GET['semester']) ? intval($_GET['semester']) : 0;
        $filter_status = $_GET['status'] ?? '';
        
        // Handle Bulk Actions

    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action_source'] == 'promotion') {
        $action = $_POST['action'];
        $student_ids = $_POST['student_ids'] ?? [];
        
        if (empty($student_ids)) {
            $error = "No students selected.";
        } else {
            $ids_str = implode(',', array_map('intval', $student_ids));
            
            if ($action == 'promote') {
                 // Promote
                $stmt = $conn->prepare("UPDATE students s LEFT JOIN users u ON s.student_id = u.profile_id AND u.role = 'student' SET s.semester = LEAST(s.semester + 1, 6) WHERE s.student_id IN ($ids_str) AND (u.is_active = 1 OR u.is_active IS NULL)");
                $stmt->execute();
                $message = $stmt->affected_rows . " student(s) promoted.";
            } elseif ($action == 'debar') {
                $conn->query("UPDATE users u JOIN students s ON u.profile_id = s.student_id SET u.is_active = 0 WHERE s.student_id IN ($ids_str) AND u.role = 'student'");
                 $message = count($student_ids) . " student(s) debarred.";
            } elseif ($action == 'activate') {
                $conn->query("UPDATE users u JOIN students s ON u.profile_id = s.student_id SET u.is_active = 1 WHERE s.student_id IN ($ids_str) AND u.role = 'student'");
                 $message = count($student_ids) . " student(s) activated.";
            } elseif ($action == 'assign_mentor') {
                 $mentor_id = intval($_POST['mentor_id']);
                if ($mentor_id > 0) {
                    $stmt = $conn->prepare("UPDATE students SET class_teacher_id = ? WHERE student_id IN ($ids_str)");
                    $stmt->bind_param("i", $mentor_id);
                    $stmt->execute();
                    $message = count($student_ids) . " student(s) assigned to new mentor.";
                }
            }
        }
    }
    
    // Fetch Data for View
    $where = ["1=1"];
    if ($filter_year) {
        $semesters = get_semesters_for_year($filter_year);
        $where[] = "s.semester IN (" . implode(',', $semesters) . ")";
    }
    if ($filter_dept) $where[] = "s.department = '" . $conn->real_escape_string($filter_dept) . "'";
    if ($filter_status == 'active') $where[] = "(u.is_active = 1 OR u.is_active IS NULL)";
    elseif ($filter_status == 'debarred') $where[] = "u.is_active = 0";

    $where_clause = implode(' AND ', $where);
    $students = $conn->query("SELECT s.*, u.email, u.is_active, t.name as mentor_name FROM students s LEFT JOIN users u ON s.student_id = u.profile_id AND u.role = 'student' LEFT JOIN teachers t ON s.class_teacher_id = t.teacher_id WHERE $where_clause ORDER BY s.department, s.semester, s.roll_number LIMIT 200"); // Limit for performance if no filter
    
    // fetch Mentors logic... (simplified for brevity, JS handles loading per dept)
    // Actually we need the JS `mentorsDB` object.
    $mentors_js = [];
    foreach ($departments as $d) {
        $q = $conn->query("SELECT t.teacher_id, t.name FROM teachers t JOIN users u ON t.user_id=u.user_id WHERE t.department='$d' AND u.email NOT LIKE 'hod_%' ORDER BY t.name");
        while ($row = $q->fetch_assoc()) $mentors_js[$d][] = $row;
    }
}

// ===============================================
// LOGIC: TAB 2 - STAFF ROLES (Assignments)
// ===============================================
if ($tab == 'roles') {
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'update_teacher_role') {
        // AJAX handling usually, but if standard POST:
        // We will stick to the AJAX flow from original file or adapt to Standard POST? 
        // Original was AJAX. Let's keep it clean or make it standard?
        // Standard is easier to verify.
        $tid = intval($_POST['teacher_id']);
        $role = sanitize_input($_POST['role']);
        
        // Basic Validation
        $valid = true;
        if ($role == 'Principal') {
             $check = $conn->query("SELECT teacher_id FROM teachers WHERE teacher_role = 'Principal' AND teacher_id != $tid");
             if ($check->num_rows > 0) { $error = "Principal already exists."; $valid = false; }
        }
        if ($role == 'HOD' && $valid) {
             $t_dept = $conn->query("SELECT department FROM teachers WHERE teacher_id=$tid")->fetch_assoc()['department'];
             $check = $conn->query("SELECT teacher_id FROM teachers WHERE teacher_role = 'HOD' AND department='$t_dept' AND teacher_id != $tid");
             if ($check->num_rows > 0) { $error = "HOD for $t_dept already exists."; $valid = false; }
        }
        
        if ($valid) {
            $conn->query("UPDATE teachers SET teacher_role = '$role' WHERE teacher_id = $tid");
            
            // Link User Role
            $uid = $conn->query("SELECT user_id FROM teachers WHERE teacher_id=$tid")->fetch_row()[0];
            // If HOD/Principal, usually keep role='teacher' in users table but use permissions? 
            // Original code didn't change `users.role` (it's always 'teacher'). Scope is handled by `teachers.teacher_role`.
            
            $message = "Role updated successfully.";
        }
    }
    
    // Fetch Staff Logic
    $role_view = $_GET['role_category'] ?? 'Faculty'; // 'Leadership' or 'Faculty'
    $role_dept = $_GET['role_dept'] ?? ''; // Filter dept
    
    // SQL Base
    // Fix: Join users to get EMAIL
    $sql = "SELECT t.*, u.email FROM teachers t LEFT JOIN users u ON t.user_id = u.user_id WHERE 1=1";
    
    if ($role_view == 'Leadership') {
        $sql .= " AND t.teacher_role IN ('Principal', 'HOD')";
    } else {
        // Faculty view
        $sql .= " AND t.teacher_role NOT IN ('Principal', 'HOD')";
        if ($role_dept) $sql .= " AND t.department = '$role_dept'";
    }
    
    $sql .= " ORDER BY FIELD(t.teacher_role, 'Principal', 'HOD', 'Teacher'), t.name";
    
    $staff_list = $conn->query($sql);
}


// ===============================================
// LOGIC: TAB 3 - MENTOR ASSIGNMENT (Matrix)
// ===============================================
if ($tab == 'mentors') {
    // Handling assigning mentor via POST (Simple Form submission per Year/Dept)
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['assign_mentor_matrix'])) {
        $dept = sanitize_input($_POST['dept']);
        $year = intval($_POST['year']);
        $tid = intval($_POST['teacher_id']);
        
        $semesters = [];
        if ($year == 1) $semesters = [1,2];
        elseif ($year == 2) $semesters = [3,4];
        elseif ($year == 3) $semesters = [5,6];
        
        $sems_str = implode(',', $semesters);
        
        if ($tid > 0) {
            // Check formatted strict logic? 
            // "Strict Exclusive": Teacher assigned to this batch?
            // Just update for now.
             $conn->query("UPDATE students SET class_teacher_id = $tid WHERE department='$dept' AND semester IN ($sems_str)");
             $message = "Mentor assigned for Year $year ($dept).";
        } else {
             $conn->query("UPDATE students SET class_teacher_id = NULL WHERE department='$dept' AND semester IN ($sems_str)");
             $message = "Mentor unassigned.";
        }
    }
    
    // Data for Matrix
    $departments = ['Civil', 'Computer', 'EEE', 'Mechanical', 'ECE', 'Textile Technology', 'Science and Humanities'];
    // We need to fetch current assignments
    $matrix = [];
    foreach($departments as $d) {
        $matrix[$d] = [1=>null, 2=>null, 3=>null]; // Years 1,2,3
        // Fetch mentor for Year 1 (Sem 1 or 2)
        // Taking generic approach: check semester 1, 3, 5 representative
        // Or check average? Just check one student?
        // Better: Query `class_teacher_id` GROUP BY department, CEIL(semester/2)
        // Let's do a simple 3 queries or 1 loop
        for($y=1; $y<=3; $y++) {
             $s_start = ($y*2)-1; 
             $res = $conn->query("SELECT class_teacher_id, t.name FROM students s JOIN teachers t ON s.class_teacher_id = t.teacher_id WHERE s.department='$d' AND s.semester IN ($s_start, ".($s_start+1).") LIMIT 1");
             if ($res->num_rows > 0) {
                 $matrix[$d][$y] = $res->fetch_assoc();
             }
        }
    }
    
    // Teachers List for Dropdowns
    $all_teachers = [];
     $res = $conn->query("SELECT teacher_id, name, department FROM teachers ORDER BY name");
     while($r = $res->fetch_assoc()) $all_teachers[$r['department']][] = $r;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Placements & Roles - Chendhuran SIS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../includes/css/styles.css" rel="stylesheet">
    <style>
        .nav-tabs .nav-link { color: #6b7280; font-weight: 500; padding: 1rem 1.5rem; }
        .nav-tabs .nav-link.active { color: #4f46e5; border-bottom: 3px solid #4f46e5; font-weight: 600; background:none;}
        .avatar-initial { width: 32px; height: 32px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 0.8rem; color: #fff; }
    </style>
</head>
<body>
<?php include '../includes/sidebar.php'; ?>

<main class="main-content">
    
    <div class="glass-header mb-0 pb-0 rounded-bottom-0">
        <div class="d-flex justify-content-between align-items-center mb-3">
             <div>
                <h4 class="fw-bold mb-1">Placements & Assignments</h4>
                <p class="text-muted mb-0 small">Manage Promotions, Staff Roles, and Mentors.</p>
             </div>
        </div>

        <ul class="nav nav-tabs">
            <li class="nav-item"><a class="nav-link <?php echo $tab == 'promotion' ? 'active' : ''; ?>" href="?tab=promotion"><i class="fas fa-user-graduate me-2"></i>Student Promotion</a></li>
            <li class="nav-item"><a class="nav-link <?php echo $tab == 'roles' ? 'active' : ''; ?>" href="?tab=roles"><i class="fas fa-user-shield me-2"></i>Staff Roles</a></li>
            <li class="nav-item"><a class="nav-link <?php echo $tab == 'mentors' ? 'active' : ''; ?>" href="?tab=mentors"><i class="fas fa-chalkboard-teacher me-2"></i>Class Mentors</a></li>
        </ul>
    </div>

    <div class="glass-card rounded-top-0 border-top-0 p-4">
        <?php if($message): ?><div class="alert alert-success"><?php echo $message; ?></div><?php endif; ?>
        <?php if($error): ?><div class="alert alert-danger"><?php echo $error; ?></div><?php endif; ?>

        <!-- TAB 1: PROMOTION -->
        <?php if ($tab == 'promotion'): ?>
            <div class="card border-0 shadow-sm mb-3">
                <div class="card-body p-3 bg-light rounded">
                    <form method="GET" class="row g-2 align-items-end">
                        <input type="hidden" name="tab" value="promotion">
                        <div class="col-md-3">
                            <label class="small text-muted fw-bold">Year</label>
                            <select name="year" class="form-select form-select-sm">
                                <option value="">All</option>
                                <option value="1" <?php echo $filter_year==1?'selected':'';?>>Year 1</option>
                                <option value="2" <?php echo $filter_year==2?'selected':'';?>>Year 2</option>
                                <option value="3" <?php echo $filter_year==3?'selected':'';?>>Year 3</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="small text-muted fw-bold">Department</label>
                            <select name="dept" class="form-select form-select-sm">
                                <option value="">All</option>
                                <?php foreach($departments as $d) echo "<option " . ($filter_dept==$d?'selected':'') . ">$d</option>"; ?>
                            </select>
                        </div>
                        <div class="col-md-2">
                             <button type="submit" class="btn btn-primary btn-sm w-100">Filter</button>
                        </div>
                    </form>
                </div>
            </div>
            
            <?php if($students && $students->num_rows > 0): ?>
            <form method="POST">
                <input type="hidden" name="action_source" value="promotion">
                
                <div class="mb-3 d-flex gap-2">
                    <button type="submit" name="action" value="promote" class="btn btn-success btn-sm"><i class="fas fa-arrow-up me-1"></i>Promote Selected</button>
                    <button type="submit" name="action" value="debar" class="btn btn-danger btn-sm"><i class="fas fa-ban me-1"></i>Debar</button>
                </div>

                <div class="table-responsive bg-white border rounded">
                     <table class="table table-hover mb-0 small">
                         <thead class="table-light">
                             <tr>
                                 <th width="30"><input type="checkbox" onclick="toggleAll(this)"></th>
                                 <th>Roll No</th>
                                 <th>Name</th>
                                 <th>Dept / Sem</th>
                                 <th>Status</th>
                             </tr>
                         </thead>
                         <tbody>
                             <?php while($s = $students->fetch_assoc()): ?>
                             <tr>
                                 <td><input type="checkbox" name="student_ids[]" value="<?php echo $s['student_id']; ?>" class="stu-cb"></td>
                                 <td><?php echo $s['roll_number']; ?></td>
                                 <td><?php echo $s['name']; ?></td>
                                 <td><?php echo $s['department']; ?> - <span class="badge bg-light text-dark border">Sem <?php echo $s['semester']; ?></span></td>
                                 <td><?php echo $s['is_active'] ? '<span class="text-success">Active</span>' : '<span class="text-danger">Debarred</span>'; ?></td>
                             </tr>
                             <?php endwhile; ?>
                         </tbody>
                     </table>
                </div>
            </form>
            <?php else: ?>
                <div class="text-center p-4 text-muted">No students found.</div>
            <?php endif; ?>
        <?php endif; ?>


        <!-- TAB 2: STAFF ROLES -->
        <?php if ($tab == 'roles'): ?>
            <div class="card border-0 shadow-sm mb-3">
                <div class="card-body p-3 bg-light rounded">
                    <form method="GET" class="row g-2 align-items-center">
                        <input type="hidden" name="tab" value="roles">
                        <div class="col-md-3">
                            <label class="small text-muted fw-bold">View Category</label>
                            <div class="btn-group w-100" role="group">
                                <a href="?tab=roles&role_category=Leadership" class="btn btn-sm <?php echo $role_view=='Leadership'?'btn-primary':'btn-outline-secondary bg-white'; ?>">Leadership</a>
                                <a href="?tab=roles&role_category=Faculty" class="btn btn-sm <?php echo $role_view=='Faculty'?'btn-primary':'btn-outline-secondary bg-white'; ?>">Faculty</a>
                            </div>
                        </div>
                        
                        <?php if($role_view == 'Faculty'): ?>
                        <div class="col-md-4">
                            <label class="small text-muted fw-bold">Filter Department</label>
                            <select name="role_dept" class="form-select form-select-sm" onchange="this.form.submit()">
                                <option value="">All Departments</option>
                                <?php foreach($departments as $d) echo "<option ". ($role_dept==$d?'selected':'') .">$d</option>"; ?>
                            </select>
                        </div>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
            
            <div class="table-responsive">
                <table class="table table-bordered align-middle bg-white">
                    <thead class="table-light"><tr><th>Teacher</th><th>Department</th><th>Current Role</th><th>Action</th></tr></thead>
                    <tbody>
                        <?php while($t = $staff_list->fetch_assoc()): ?>
                        <tr>
                            <td>
                                <div class="d-flex align-items-center">
                                    <div class="avatar-initial bg-primary me-2"><?php echo substr($t['name'],0,1); ?></div>
                                    <div><div class="fw-bold"><?php echo $t['name']; ?></div><div class="text-xs text-muted"><?php echo $t['email']; ?></div></div>
                                </div>
                            </td>
                            <td><span class="badge bg-light text-dark border"><?php echo $t['department']; ?></span></td>
                            <td>
                                <?php 
                                    $badge = 'bg-secondary';
                                    if($t['teacher_role']=='HOD') $badge='bg-warning text-dark';
                                    if($t['teacher_role']=='Principal') $badge='bg-danger';
                                    if($t['teacher_role']=='Class Mentor') $badge='bg-info text-dark';
                                ?>
                                <span class="badge <?php echo $badge; ?>"><?php echo $t['teacher_role']; ?></span>
                            </td>
                            <td>
                                <form method="POST" class="d-flex gap-2">
                                    <input type="hidden" name="teacher_id" value="<?php echo $t['teacher_id']; ?>">
                                    <select name="role" class="form-select form-select-sm" style="width:120px;">
                                        <option value="Teacher">Teacher</option>
                                        <option value="HOD" <?php echo $t['teacher_role']=='HOD'?'selected':'';?>>HOD</option>
                                        <option value="Principal" <?php echo $t['teacher_role']=='Principal'?'selected':'';?>>Principal</option>
                                    </select>
                                    <button type="submit" name="action" value="update_teacher_role" class="btn btn-primary btn-sm">Update</button>
                                </form>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>


        <!-- TAB 3: MENTORS -->
        <?php if ($tab == 'mentors'): ?>
            <?php foreach($departments as $dept): ?>
            <div class="card mb-3 border shadow-sm">
                <div class="card-header bg-white fw-bold"><?php echo $dept; ?> Department</div>
                <div class="card-body p-0">
                    <table class="table table-sm mb-0 align-middle">
                        <thead class="table-light"><tr><th>Year</th><th>Assigned Mentor</th><th>Action</th></tr></thead>
                        <tbody>
                            <?php for($y=1; $y<=3; $y++): ?>
                            <tr>
                                <td class="fw-bold ps-3">Year <?php echo $y; ?></td>
                                <td>
                                    <?php 
                                    $assigned = $matrix[$dept][$y];
                                    if ($assigned) {
                                         echo '<span class="text-success"><i class="fas fa-check-circle me-1"></i>'.$assigned['name'].'</span>';
                                    } else {
                                         echo '<span class="text-muted italic">Unassigned</span>';
                                    }
                                    ?>
                                </td>
                                <td>
                                    <form method="POST" class="d-flex gap-2">
                                        <input type="hidden" name="assign_mentor_matrix" value="1">
                                        <input type="hidden" name="dept" value="<?php echo $dept; ?>">
                                        <input type="hidden" name="year" value="<?php echo $y; ?>">
                                        <select name="teacher_id" class="form-select form-select-sm" style="width:200px;">
                                            <option value="0">-- Select --</option>
                                            <?php 
                                            if(isset($all_teachers[$dept])) {
                                                foreach($all_teachers[$dept] as $thm) {
                                                    $sel = ($assigned && $assigned['class_teacher_id'] == $thm['teacher_id']) ? 'selected' : '';
                                                    echo "<option value='{$thm['teacher_id']}' $sel>{$thm['name']}</option>";
                                                }
                                            }
                                            ?>
                                        </select>
                                        <button type="submit" class="btn btn-outline-primary btn-sm">Save</button>
                                    </form>
                                </td>
                            </tr>
                            <?php endfor; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>

    </div>
</main>

<script>
function toggleAll(source) {
  checkboxes = document.getElementsByClassName('stu-cb');
  for(var i=0, n=checkboxes.length;i<n;i++) {
    checkboxes[i].checked = source.checked;
  }
}
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
