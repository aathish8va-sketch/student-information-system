<?php
// admin/admin_feedback_view.php - Student Feedback View
require_once '../includes/db_connect.php';
check_login(['admin']);

// Filters
$filter_semester = $_GET['semester'] ?? '';
$filter_dept = $_GET['department'] ?? '';

// Build Query
$where = [];
if ($filter_semester) $where[] = "f.semester = " . intval($filter_semester);
if ($filter_dept) $where[] = "s.department = '" . $conn->real_escape_string($filter_dept) . "'";
$where_clause = count($where) > 0 ? 'WHERE ' . implode(' AND ', $where) : '';

$sql = "SELECT f.*, s.name as student_name, s.department, s.semester as s_sem,
               sub.subject_name, t.name as teacher_name
        FROM feedback f 
        JOIN students s ON f.student_id = s.student_id
        LEFT JOIN subjects sub ON f.subject_code = sub.subject_code
        LEFT JOIN teachers t ON f.teacher_id = t.teacher_id
        $where_clause
        ORDER BY f.created_at DESC";
        
$result = $conn->query($sql);

if (!$result) {
    die("Database Error: " . $conn->error);
}

$departments = ['Civil', 'Computer', 'EEE', 'Mechanical', 'ECE', 'Textile Technology', 'Science and Humanities'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Feedback - Chendhuran SIS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="../includes/css/styles.css" rel="stylesheet">
</head>
<body>
<?php include '../includes/sidebar.php'; ?>

<main class="admin-main">
    <!-- Page Header -->
    <div class="page-header">
        <div>
            <h4 class="mb-1">Student Feedback</h4>
            <p class="text-muted mb-0 text-sm">Review student feedback on courses and teachers</p>
        </div>
    </div>

    <!-- Filter Bar -->
    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" class="row g-3 align-items-end">
                <div class="col-md-4">
                    <label class="form-label">Department</label>
                    <select name="department" class="form-select">
                        <option value="">All Departments</option>
                        <?php foreach($departments as $d): ?>
                            <option value="<?php echo $d; ?>" <?php if($filter_dept==$d) echo 'selected'; ?>><?php echo $d; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Semester</label>
                    <select name="semester" class="form-select">
                        <option value="">All Semesters</option>
                        <?php for($i=1; $i<=6; $i++): ?>
                            <option value="<?php echo $i; ?>" <?php if($filter_semester==$i) echo 'selected'; ?>>Semester <?php echo $i; ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100"><i class="fas fa-filter me-1"></i> Filter</button>
                </div>
                <div class="col-md-2">
                    <a href="admin_feedback_view.php" class="btn btn-outline-secondary w-100">Reset</a>
                </div>
            </form>
        </div>
    </div>

    <!-- Feedback Cards -->
    <div class="row g-4">
        <?php if($result && $result->num_rows > 0): ?>
            <?php while($row = $result->fetch_assoc()): 
                $stars = intval($row['rating']);
            ?>
                <div class="col-md-6 col-xl-4">
                    <div class="card h-100">
                        <div class="card-body">
                            <div class="d-flex justify-content-between mb-3">
                                <div>
                                    <?php for($i=1; $i<=5; $i++): ?>
                                        <i class="fas fa-star <?php echo $i <= $stars ? 'text-warning' : 'text-muted'; ?>"></i>
                                    <?php endfor; ?>
                                    <span class="ms-2 fw-bold"><?php echo $stars; ?>/5</span>
                                </div>
                                <small class="text-muted"><?php echo date('M d, Y', strtotime($row['created_at'])); ?></small>
                            </div>
                            
                            <h6 class="fw-bold mb-2">
                                <?php if($row['subject_name']): ?>
                                    <i class="fas fa-book me-1 text-primary"></i> <?php echo htmlspecialchars($row['subject_name']); ?>
                                <?php else: ?>
                                    <i class="fas fa-comment me-1 text-info"></i> General Feedback
                                <?php endif; ?>
                            </h6>
                            
                            <?php if($row['teacher_name']): ?>
                                <p class="text-sm text-muted mb-2">
                                    <i class="fas fa-chalkboard-teacher me-1"></i> <?php echo htmlspecialchars($row['teacher_name']); ?>
                                </p>
                            <?php endif; ?>
                            
                            <?php if($row['comments']): ?>
                                <p class="text-muted text-sm mb-3 border-start border-3 ps-3">
                                    "<?php echo htmlspecialchars($row['comments']); ?>"
                                </p>
                            <?php endif; ?>
                            
                            <div class="d-flex align-items-center border-top pt-3 mt-3">
                                <div class="avatar-circle me-2 bg-primary text-white">
                                    <?php echo strtoupper(substr($row['student_name'],0,1)); ?>
                                </div>
                                <div>
                                    <div class="fw-medium text-sm"><?php echo htmlspecialchars($row['student_name']); ?></div>
                                    <div class="text-xs text-muted"><?php echo $row['department']; ?> • Sem <?php echo $row['s_sem']; ?></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="col-12">
                <div class="empty-state">
                    <i class="fas fa-comment-slash"></i>
                    <p>No feedback found</p>
                </div>
            </div>
        <?php endif; ?>
    </div>

</main>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
