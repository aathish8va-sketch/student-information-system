<?php
// admin/admin_dashboard.php - Simplified Admin Dashboard
require_once '../includes/db_connect.php';
check_login(['admin']);

// Set timezone to IST (Indian Standard Time)
date_default_timezone_set('Asia/Kolkata');

// ============ ADMIN-RELEVANT METRICS ============

// 1. Pending Grievances (requires action)
$rs_g = $conn->query("SELECT COUNT(*) FROM grievances WHERE status='Pending'");
$pending_grievances = $rs_g ? $rs_g->fetch_row()[0] : 0;

// 2. Students Requiring Attention (Poor/Disruptive behavior)
$rs_behavior = $conn->query("SELECT COUNT(DISTINCT student_id) FROM student_behavior WHERE behavior_tag IN ('Poor', 'Disruptive') AND date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)");
$attention_needed = $rs_behavior ? $rs_behavior->fetch_row()[0] : 0;

// 3. Recent Feedback Count (admin should review)
$rs_fb = $conn->query("SELECT COUNT(*) FROM feedback WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)");
$new_feedback = $rs_fb ? $rs_fb->fetch_row()[0] : 0;

// 4. Total Active Users
$rs_active = $conn->query("SELECT COUNT(*) FROM users WHERE is_active = 1");
$active_users = $rs_active ? $rs_active->fetch_row()[0] : 0;

// ============ TEACHER ROLE ANALYTICS ============

// 5. Teacher Role Statistics
$teacher_stats = [];
$teacher_stats['total'] = $conn->query("SELECT COUNT(*) FROM teachers")->fetch_row()[0];
$teacher_stats['principal'] = $conn->query("SELECT COUNT(*) FROM teachers WHERE teacher_role = 'Principal'")->fetch_row()[0];
$teacher_stats['hods'] = $conn->query("SELECT COUNT(*) FROM teachers WHERE teacher_role = 'HOD'")->fetch_row()[0];
$teacher_stats['class_mentors'] = $conn->query("SELECT COUNT(DISTINCT class_teacher_id) FROM students WHERE class_teacher_id IS NOT NULL")->fetch_row()[0];
$teacher_stats['regular'] = $conn->query("SELECT COUNT(*) FROM teachers WHERE teacher_role = 'Teacher'")->fetch_row()[0];

// 6. HOD Coverage (how many departments have HODs)
$total_departments = 7; // Civil, Computer, EEE, Mechanical, ECE, Textile, Science & Humanities
$hods_assigned = $teacher_stats['hods'];
$hod_coverage = round(($hods_assigned / $total_departments) * 100);

// 7. Students without Class Mentors
$unassigned_students = $conn->query("SELECT COUNT(*) FROM students WHERE class_teacher_id IS NULL")->fetch_row()[0];

// 8. Class Mentor Assignments Summary
$class_mentor_summary = $conn->query("
    SELECT t.name, t.department, COUNT(s.student_id) as student_count
    FROM teachers t
    JOIN students s ON t.teacher_id = s.class_teacher_id
    GROUP BY t.teacher_id
    HAVING student_count > 0
    ORDER BY student_count DESC
    LIMIT 5
");

// 9. Recent Pending Grievances (Top 5 - requires admin attention)
$pending_issues = $conn->query("
    SELECT g.*, st.name as student_name, st.department 
    FROM grievances g 
    JOIN students st ON g.student_id = st.student_id 
    WHERE g.status = 'Pending' 
    ORDER BY g.created_at DESC 
    LIMIT 5
");

// 6. Recent User Activity (last 10)
$recent_logs = $conn->query("
    SELECT al.*, u.email 
    FROM audit_logs al 
    LEFT JOIN users u ON al.user_id = u.user_id 
    ORDER BY al.created_at DESC 
    LIMIT 10
");

// 7. Department-wise Student Count
$dept_students = $conn->query("
    SELECT department, COUNT(*) as student_count
    FROM students
    GROUP BY department
    ORDER BY student_count DESC
");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Chendhuran SIS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="../includes/css/styles.css" rel="stylesheet">
</head>
<body>
<?php include '../includes/sidebar.php'; ?>

<main class="admin-main">
    <!-- Page Header -->
    <div class="page-header">
        <div>
            <h4 class="mb-1">Admin Control Panel</h4>
            <p class="text-muted mb-0 text-sm">System overview and management</p>
        </div>
        <div class="text-end">
            <div class="fw-bold" id="liveTime"><?php echo date('h:i A'); ?></div>
            <small class="text-muted"><?php echo date('l, F j, Y'); ?></small>
        </div>
    </div>

    <!-- Key Admin Metrics -->
    <div class="row g-4 mb-4">
        <!-- Pending Grievances - Requires Action -->
        <div class="col-md-4">
            <div class="stat-card">
                <div class="stat-icon <?php echo $pending_grievances > 0 ? 'red' : 'green'; ?>">
                    <i class="fas fa-<?php echo $pending_grievances > 0 ? 'exclamation-triangle' : 'check-circle'; ?>"></i>
                </div>
                <div>
                    <div class="text-muted text-xs text-uppercase fw-bold mb-1">Pending Grievances</div>
                    <h3 class="mb-0 fw-bold"><?php echo $pending_grievances; ?></h3>
                    <small class="text-muted">Requires attention</small>
                </div>
            </div>
        </div>

        <!-- Students Requiring Attention -->
        <div class="col-md-4">
            <div class="stat-card">
                <div class="stat-icon <?php echo $attention_needed > 0 ? 'red' : 'green'; ?>">
                    <i class="fas fa-<?php echo $attention_needed > 0 ? 'user-times' : 'user-check'; ?>"></i>
                </div>
                <div>
                    <div class="text-muted text-xs text-uppercase fw-bold mb-1">Students Attention</div>
                    <h3 class="mb-0 fw-bold"><?php echo $attention_needed; ?></h3>
                    <small class="text-muted">Behavior alerts (30d)</small>
                </div>
            </div>
        </div>

        <!-- Active Users -->
        <div class="col-md-4">
            <div class="stat-card">
                <div class="stat-icon green">
                    <i class="fas fa-users"></i>
                </div>
                <div>
                    <div class="text-muted text-xs text-uppercase fw-bold mb-1">Active Users</div>
                    <h3 class="mb-0 fw-bold"><?php echo $active_users; ?></h3>
                    <small class="text-muted">System-wide</small>
                </div>
            </div>
        </div>
    </div>

    <!-- Teacher Role Analytics Row -->
    <div class="row g-4 mb-4">
        <!-- Principal Status -->
        <div class="col-md-4">
            <div class="stat-card">
                <div class="stat-icon <?php echo $teacher_stats['principal'] > 0 ? 'purple' : 'red'; ?>">
                    <i class="fas fa-crown"></i>
                </div>
                <div>
                    <div class="text-muted text-xs text-uppercase fw-bold mb-1">Principal</div>
                    <h3 class="mb-0 fw-bold">
                        <?php
                        if ($teacher_stats['principal'] > 0) {
                            $principal = $conn->query("SELECT name FROM teachers WHERE teacher_role = 'Principal'")->fetch_assoc();
                            echo htmlspecialchars($principal['name']);
                        } else {
                            echo 'Not Assigned';
                        }
                        ?>
                    </h3>
                    <small class="text-muted">Institutional Head</small>
                </div>
            </div>
        </div>

        <!-- Class Mentors -->
        <div class="col-md-4">
            <div class="stat-card">
                <div class="stat-icon blue">
                    <i class="fas fa-user-graduate"></i>
                </div>
                <div>
                    <div class="text-muted text-xs text-uppercase fw-bold mb-1">Class Mentors</div>
                    <h3 class="mb-0 fw-bold"><?php echo $teacher_stats['class_mentors']; ?></h3>
                    <small class="text-muted">
                        <?php echo $teacher_stats['total']; ?> total teachers
                    </small>
                </div>
            </div>
        </div>

        <!-- Unassigned Students Warning -->
        <div class="col-md-4">
            <div class="stat-card">
                <div class="stat-icon <?php echo $unassigned_students > 0 ? 'red' : 'green'; ?>">
                    <i class="fas fa-<?php echo $unassigned_students > 0 ? 'user-times' : 'user-check'; ?>"></i>
                </div>
                <div>
                    <div class="text-muted text-xs text-uppercase fw-bold mb-1">Unassigned Students</div>
                    <h3 class="mb-0 fw-bold"><?php echo $unassigned_students; ?></h3>
                    <small class="text-muted">
                        <?php if ($unassigned_students > 0): ?>
                            <a href="admin_class_mentor_assignments.php" class="text-danger">Assign now →</a>
                        <?php else: ?>
                            All students assigned
                        <?php endif; ?>
                    </small>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-4"
        <!-- Department-wise Student Count -->
        <div class="col-lg-7">
            <div class="card h-100">
                <div class="card-header">
                    <i class="fas fa-users me-2"></i> Students by Department
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead>
                                <tr>
                                    <th class="ps-4">Department</th>
                                    <th class="text-end pe-4">Total Students</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($dept_students && $dept_students->num_rows > 0): ?>
                                    <?php 
                                    $total = 0;
                                    $dept_data = [];
                                    while($d = $dept_students->fetch_assoc()) {
                                        $dept_data[] = $d;
                                        $total += $d['student_count'];
                                    }
                                    foreach($dept_data as $d): 
                                    ?>
                                    <tr>
                                        <td class="ps-4 fw-medium"><?php echo htmlspecialchars($d['department']); ?></td>
                                        <td class="text-end pe-4">
                                            <span class="badge bg-primary"><?php echo $d['student_count']; ?></span>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                    <tr class="table-light fw-bold">
                                        <td class="ps-4">TOTAL</td>
                                        <td class="text-end pe-4">
                                            <span class="badge bg-success"><?php echo $total; ?></span>
                                        </td>
                                    </tr>
                                <?php else: ?>
                                    <tr><td colspan="2" class="text-center text-muted py-4">No students found</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Pending Grievances - Action Required -->
        <div class="col-lg-5">
            <div class="card h-100">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <span><i class="fas fa-inbox me-2"></i> Grievance Desk</span>
                    <?php if($pending_grievances > 0): ?>
                        <span class="badge bg-danger"><?php echo $pending_grievances; ?></span>
                    <?php endif; ?>
                </div>
                <div class="card-body">
                    <?php if($pending_issues && $pending_issues->num_rows > 0): ?>
                        <?php while($issue = $pending_issues->fetch_assoc()): ?>
                        <div class="d-flex align-items-start mb-3 pb-3 border-bottom">
                            <div class="avatar-circle me-3 bg-light text-primary">
                                <?php echo strtoupper(substr($issue['student_name'], 0, 1)); ?>
                            </div>
                            <div class="flex-grow-1">
                                <div class="d-flex justify-content-between">
                                    <div class="fw-medium text-sm"><?php echo htmlspecialchars($issue['student_name']); ?></div>
                                    <small class="text-muted"><?php echo date('M d', strtotime($issue['created_at'])); ?></small>
                                </div>
                                <div class="text-xs text-muted mb-1"><?php echo htmlspecialchars($issue['department']); ?> • <?php echo htmlspecialchars($issue['subject_code'] ?? 'General'); ?></div>
                                <div class="text-sm text-dark bg-light p-2 rounded" style="max-height: 150px; overflow-y: auto; white-space: pre-wrap;">"<?php echo htmlspecialchars($issue['message']); ?>"</div>
                                
                                <!-- Dashboard Modal -->
                                <div class="modal fade" id="dashMsgModal<?php echo $issue['grievance_id']; ?>" tabindex="-1" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h6 class="modal-title fw-bold">Grievance Details</h6>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="mb-2">
                                                    <span class="badge bg-primary me-2"><?php echo htmlspecialchars($issue['department']); ?></span>
                                                    <span class="badge bg-secondary"><?php echo htmlspecialchars($issue['subject_code'] ?? 'General'); ?></span>
                                                </div>
                                                <div class="p-3 bg-light rounded border mb-2">
                                                    "<?php echo nl2br(htmlspecialchars($issue['message'])); ?>"
                                                </div>
                                                <div class="text-end text-muted small">
                                                    by <?php echo htmlspecialchars($issue['student_name']); ?> • <?php echo date('M d, h:i A', strtotime($issue['created_at'])); ?>
                                                </div>
                                            </div>
                                            <div class="modal-footer p-1">
                                                <a href="../teacher/grievance_list.php" class="btn btn-primary btn-sm w-100">
                                                    Go to Resolution Desk
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php if(!empty($issue['assigned_to'])): ?>
                                    <div class="mt-1 text-xs text-success"><i class="fas fa-check-circle me-1"></i>Assigned to: <?php echo $issue['assigned_to']; ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endwhile; ?>

                    <?php else: ?>
                        <div class="empty-state">
                            <i class="fas fa-check-circle text-success text-opacity-50" style="font-size: 3rem;"></i>
                            <p class="text-muted mt-2">No pending issues!</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent System Activity -->
    <div class="row g-4 mt-2">
        <div class="col-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <span><i class="fas fa-history me-2"></i> Recent System Activity</span>
                    <a href="admin_audit_logs.php" class="btn btn-sm btn-outline-secondary">View All</a>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead>
                                <tr>
                                    <th class="ps-4">Time</th>
                                    <th>User</th>
                                    <th>Action</th>
                                    <th>Details</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($recent_logs && $recent_logs->num_rows > 0): ?>
                                    <?php while($log = $recent_logs->fetch_assoc()): ?>
                                    <tr>
                                        <td class="ps-4 text-muted text-sm"><?php echo date('M d, h:i A', strtotime($log['created_at'])); ?></td>
                                        <td class="fw-medium"><?php echo htmlspecialchars($log['email'] ?: 'System'); ?></td>
                                        <td><span class="badge badge-soft-primary"><?php echo htmlspecialchars($log['action']); ?></span></td>
                                        <td class="text-muted text-sm"><?php echo htmlspecialchars(substr($log['details'] ?? '', 0, 50)); ?></td>
                                    </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr><td colspan="4" class="text-center text-muted py-4">No recent activity</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<script>
// Live clock
function updateTime() {
    const now = new Date();
    document.getElementById('liveTime').textContent = now.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
}
setInterval(updateTime, 1000);
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
