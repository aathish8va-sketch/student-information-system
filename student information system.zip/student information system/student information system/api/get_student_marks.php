<?php
// api/get_student_marks.php
require_once '../db_connect.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

$student_id = $_SESSION['profile_id'];

// Fetch marks for top 3 subjects (or all)
// Group by subject to get trend over time? Or just average?
// User asked for "Marks Progression over time". 
// That implies we need data points like Test 1, Test 2, etc. for specific subjects.

$query = "
    SELECT 
        s.subject_name, 
        sc.assessment_type, 
        (sc.marks_obtained / sc.max_marks) * 100 as percentage
    FROM scores sc
    JOIN subjects s ON sc.subject_code = s.subject_code
    WHERE sc.student_id = ?
    ORDER BY s.subject_name, sc.assessment_type
";

$stmt = $conn->prepare($query);
$stmt->bind_param("i", $student_id);
$stmt->execute();
$result = $stmt->get_result();

$data = [];
while($row = $result->fetch_assoc()) {
    $data[] = $row;
}

echo json_encode($data);
?>
