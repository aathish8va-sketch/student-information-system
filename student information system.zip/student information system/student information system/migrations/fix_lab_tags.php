<?php
require_once '../includes/db_connect.php';

// Update Logic
$sql = "UPDATE subjects 
        SET subject_type = 'Practical' 
        WHERE (subject_type IS NULL OR subject_type = '' OR subject_type = 'Theory') 
        AND (subject_name LIKE '%Lab%' OR subject_name LIKE '%Practical%')";

if ($conn->query($sql) === TRUE) {
    echo "Successfully updated " . $conn->affected_rows . " subjects to 'Practical' type.\n";
} else {
    echo "Error updating records: " . $conn->error . "\n";
}

// Verification
$check = $conn->query("SELECT subject_code, subject_name, subject_type FROM subjects WHERE subject_type = 'Practical'");
echo "\nVerifying Practical Subjects:\n";
while($row = $check->fetch_assoc()) {
    echo "[{$row['subject_type']}] {$row['subject_code']} - {$row['subject_name']}\n";
}
?>
