-- ##########################################################################
-- # SPTC Performance Tracker: DATABASE INITIALIZATION
-- ##########################################################################

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

-- CREATE AND USE DATABASE
-- The IF NOT EXISTS prevents errors if the database already exists.
CREATE DATABASE IF NOT EXISTS `chendhuran_sis` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `chendhuran_sis`;

-- ##########################################################################
-- # 1. TABLE STRUCTURE DEFINITION
-- ##########################################################################

-- Users Table: Central Authentication Layer
CREATE TABLE `users` (
  `user_id` INT(11) NOT NULL AUTO_INCREMENT,
  `email` VARCHAR(255) NOT NULL,
  `password_hash` VARCHAR(255) NOT NULL,
  `role` ENUM('student', 'teacher', 'admin') NOT NULL,
  `profile_id` INT(11) DEFAULT NULL COMMENT 'Links to student_id or teacher_id (depending on role)',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP(),
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Teachers Table: Stores Teacher Profiles
CREATE TABLE `teachers` (
  `teacher_id` INT(11) NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(100) NOT NULL,
  `department` ENUM('Civil', 'EEE', 'Mechanical', 'Computer', 'ECE', 'Textile Technology', 'Administration') NOT NULL,
  `user_id` INT(11) DEFAULT NULL,
  PRIMARY KEY (`teacher_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Students Table: Stores Student Profiles
CREATE TABLE `students` (
  `student_id` INT(11) NOT NULL AUTO_INCREMENT,
  `roll_number` VARCHAR(20) NOT NULL,
  `name` VARCHAR(100) NOT NULL,
  `department` ENUM('Civil', 'EEE', 'Mechanical', 'Computer', 'ECE', 'Textile Technology') NOT NULL,
  `semester` INT(11) NOT NULL,
  `user_id` INT(11) DEFAULT NULL,
  PRIMARY KEY (`student_id`),
  UNIQUE KEY `roll_number` (`roll_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Subjects Table: Stores Course Details
CREATE TABLE `subjects` (
  `subject_code` VARCHAR(20) NOT NULL,
  `subject_name` VARCHAR(100) NOT NULL,
  `department` ENUM('Civil', 'EEE', 'Mechanical', 'Computer', 'ECE', 'Textile Technology') NOT NULL,
  `semester` INT(11) NOT NULL,
  `teacher_id` INT(11) DEFAULT NULL,
  PRIMARY KEY (`subject_code`),
  KEY `teacher_id` (`teacher_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Scores Table: Stores Assessment Results
CREATE TABLE `scores` (
  `score_id` INT(11) NOT NULL AUTO_INCREMENT,
  `student_id` INT(11) NOT NULL,
  `subject_code` VARCHAR(20) NOT NULL,
  `assessment_type` ENUM('Test 1', 'Test 2', 'Assignment', 'Practical', 'Final Exam') NOT NULL,
  `marks_obtained` FLOAT NOT NULL,
  `max_marks` FLOAT NOT NULL DEFAULT 100,
  `recorded_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP(),
  PRIMARY KEY (`score_id`),
  KEY `student_id` (`student_id`),
  KEY `subject_code` (`subject_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Attendance Table: Stores Daily/Lecture Attendance
CREATE TABLE `attendance` (
  `attendance_id` INT(11) NOT NULL AUTO_INCREMENT,
  `student_id` INT(11) NOT NULL,
  `subject_code` VARCHAR(20) NOT NULL,
  `date` DATE NOT NULL,
  `status` ENUM('P', 'A', 'L') NOT NULL COMMENT 'P=Present, A=Absent, L=Leave',
  PRIMARY KEY (`attendance_id`),
  UNIQUE KEY `unique_attendance` (`student_id`, `subject_code`, `date`),
  KEY `student_id` (`student_id`),
  KEY `subject_code` (`subject_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- Student Behavior Table: Stores Behavioral Metrics
CREATE TABLE `student_behavior` (
  `behavior_id` INT(11) NOT NULL AUTO_INCREMENT,
  `student_id` INT(11) NOT NULL,
  `teacher_id` INT(11) NOT NULL,
  `date` DATE NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `behavior_tag` ENUM('Excellent', 'Good', 'Average', 'Poor', 'Disruptive', 'Improved') NOT NULL,
  `comments` TEXT,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`behavior_id`),
  KEY `student_id` (`student_id`),
  KEY `teacher_id` (`teacher_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ##########################################################################
-- # 2. CONSTRAINTS (FOREIGN KEYS)
-- ##########################################################################

ALTER TABLE `students`
  ADD CONSTRAINT `fk_student_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

ALTER TABLE `teachers`
  ADD CONSTRAINT `fk_teacher_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

ALTER TABLE `subjects`
  ADD CONSTRAINT `subjects_ibfk_1` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`teacher_id`) ON DELETE SET NULL;

ALTER TABLE `scores`
  ADD CONSTRAINT `scores_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `scores_ibfk_2` FOREIGN KEY (`subject_code`) REFERENCES `subjects` (`subject_code`) ON DELETE CASCADE;

ALTER TABLE `attendance`
  ADD CONSTRAINT `attendance_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `attendance_ibfk_2` FOREIGN KEY (`subject_code`) REFERENCES `subjects` (`subject_code`) ON DELETE CASCADE;

ALTER TABLE `feedback`
  ADD CONSTRAINT `fk_feedback_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`) ON DELETE CASCADE;

ALTER TABLE `student_behavior`
  ADD CONSTRAINT `behavior_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `behavior_ibfk_2` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`teacher_id`) ON DELETE CASCADE;



-- ##########################################################################
-- # 3. SAMPLE DATA FOR TESTING
-- ##########################################################################

-- NOTE: The password hash below corresponds to '123456'. 
-- If login fails, manually re-hash 'password123' and update the users table.
-- Hash: $2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi (for '123456' - Standard bcrypt test hash)
-- Ideally update this with a hash you generate locally if the above fails across versions, 
-- but this specific hash is widely used as the default for 'password' or '123456' in Laravel/factory defaults and usually works.
-- If it failed, we will use a fresh one generated by PHP 8.2+:
-- Hash found in diagnosis was wrong, replacing with a fresh standard hash for '123456'
-- $2y$10$TuPMddMlHfSF8O1xK9ktl.TOusgnPR5VLA7WqQMPvFF5Sh4gO3iIW

-- 1. Create Users
INSERT INTO `users` (`user_id`, `email`, `password_hash`, `role`, `profile_id`) VALUES
(1, 'admin@sptc.edu', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 1),
(2, 'teacher@sptc.edu', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'teacher', 2),
(3, 'student@sptc.edu', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'student', 1);

-- 2. Create Profiles
INSERT INTO `teachers` (`teacher_id`, `name`, `department`, `user_id`) VALUES
(1, 'Ms. Admin', 'Administration', 1),
(2, 'Mr. Sharma', 'Computer', 2);

INSERT INTO `students` (`student_id`, `roll_number`, `name`, `department`, `semester`, `user_id`) VALUES
(1, 'CS2023001', 'Vinith', 'Computer', 3, 3);

-- 3. Create Subjects (FIXED: Includes CS303 now)
INSERT INTO `subjects` (`subject_code`, `subject_name`, `department`, `semester`, `teacher_id`) VALUES
('CS301', 'Data Structures', 'Computer', 3, 2),
('CS302', 'Web Tech', 'Computer', 3, 2),
('CS303', 'Database Systems', 'Computer', 3, 2), -- The previously missing subject
('CE301', 'Structural Mechanics', 'Civil', 3, NULL);

-- 4. Create Scores for Student Vinith
INSERT INTO `scores` (`student_id`, `subject_code`, `assessment_type`, `marks_obtained`, `max_marks`) VALUES
(1, 'CS301', 'Test 1', 85, 100),
(1, 'CS302', 'Test 1', 92, 100),
(1, 'CS302', 'Assignment', 18, 20),
(1, 'CS303', 'Test 1', 78, 100); -- This insert will now work!

-- 5. Create Attendance for Student Vinith
INSERT INTO `attendance` (`student_id`, `subject_code`, `date`, `status`) VALUES
(1, 'CS301', CURDATE(), 'P'),
(1, 'CS302', CURDATE(), 'P'),
(1, 'CS303', CURDATE(), 'A');

COMMIT;