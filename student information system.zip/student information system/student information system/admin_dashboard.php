<?php
// Redirect old path to new path
header("Location: admin/admin_dashboard.php");
exit();
?>
