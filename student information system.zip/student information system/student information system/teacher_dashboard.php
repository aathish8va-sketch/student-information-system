<?php
// Redirect old path to new path
header("Location: teacher/teacher_dashboard.php");
exit();
?>
