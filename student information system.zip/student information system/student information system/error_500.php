<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>500 Internal Error - Chendhuran SIS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>body { background:#f8f9fa; height:100vh; display:flex; align-items:center; justify-content:center; }</style>
</head>
<body>
    <div class="text-center">
        <h1 class="display-1 fw-bold text-warning">500</h1>
        <p class="fs-3">Internal Server Error</p>
        <p class="lead">Something went wrong on our end. Please try again later.</p>
        <a href="index.php" class="btn btn-primary">Go Home</a>
    </div>
</body>
</html>
